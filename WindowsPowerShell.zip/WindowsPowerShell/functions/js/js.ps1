
function Remove-ConsoleLogLines1 {
    param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$Path
    )

    if (-not (Test-Path $Path)) {
        throw "File not found: $Path"
    }

    # Read all lines, filter out ones containing 'console.log', and overwrite
    Get-Content -Path $Path |
        Where-Object { $_ -notmatch 'console\.log' } |
        Set-Content -Path $Path

    Write-Host "Removed all lines containing 'console.log' from $Path"
}
