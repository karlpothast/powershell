
function Open_WindowsAppsFolder {
  explorer.exe shell:AppsFolder;
}

function WindowsPowershellObjects_Workspace {
    param(
        [string]$workspace
    )
    $workspacePath = "C:\Users\KarlPothast\Documents\WindowsPowerShell\WindowsPowerShell.code-workspace"
    if (Test-Path $workspacePath) {
        code $workspacePath
    } else {
        Write-Host "Workspace not found: $workspacePath"
    }
}

function vscode {
    param(
        [string]$workspace
    )
    $workspacePath = "C:\Path\To\Workspaces\$workspace.code-workspace"
    if (Test-Path $workspacePath) {
        code $workspacePath
    } else {
        Write-Host "Workspace not found: $workspacePath"
    }
}


