

function GitStageLocalFiles {
  git add .;
}