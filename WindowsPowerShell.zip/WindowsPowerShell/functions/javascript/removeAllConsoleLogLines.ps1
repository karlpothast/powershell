function Remove-ConsoleLogLines {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [Alias('FullName')]
        [string]$Path,

        [switch]$CaseSensitive,
        [switch]$Backup
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "File not found: $Path"
    }

    $pattern = 'console\.log\s*\('
    if (-not $CaseSensitive) { $pattern = "(?i)$pattern" }  # case-insensitive

    # Read whole file so we can preserve newline style (CRLF vs LF)
    $text = Get-Content -LiteralPath $Path -Raw
    $newline = if ($text -match "`r`n") { "`r`n" } else { "`n" }

    $kept = ($text -split "`r?`n") | Where-Object { $_ -notmatch $pattern }

    if ($PSCmdlet.ShouldProcess($Path, "Remove lines matching '$pattern'")) {
        if ($Backup) { Copy-Item -LiteralPath $Path -Destination "$Path.bak" -Force }
        $new = [string]::Join($newline, $kept)
        Set-Content -LiteralPath $Path -Value $new -Encoding utf8
    }
}
