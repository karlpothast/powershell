function Invoke-PublishBat {
    param (
        [string]$FileName = "Publish.bat"
    )

    $fullPath = Join-Path -Path (Get-Location) -ChildPath $FileName

    if (Test-Path $fullPath) {
        Write-Host "Found $FileName in $(Get-Location). Running..."
        & $fullPath
    }
    else {
        Write-Host "$FileName not found in $(Get-Location)."
    }
}


function PublishIntegrationTests {
    [CmdletBinding()]
    param (
        [string]$ProjectPath = "RealCloud.API.IntegrationTests.csproj",
        [string]$PublishDir = "..\bin\API.Tests",
        [string]$Configuration = "Release",
        [string]$Platform = "AnyCPU"
    )

    Write-Host "Cleaning publish directory: $PublishDir" -ForegroundColor Yellow
    Remove-Item $PublishDir -Recurse -Force -ErrorAction SilentlyContinue

    Write-Host "Building and publishing project: $ProjectPath" -ForegroundColor Cyan
    msbuild $ProjectPath `
        /p:Configuration=$Configuration `
        /p:Platform=$Platform `
        /p:PublishDir=$PublishDir `
        /p:SelfContained=false `
        /p:PublishWithTestRunner=true `
        /r `
        /t:Build;Publish `
        /v:m
}
