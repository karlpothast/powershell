#C:\Users\KarlPothast\tools\resharper_cli\inspectcode.exe

function RunResharperOnPrjAndOutputToHtml {
    param (
        [string]$Path = (Get-Location)  # default: current directory
    )

    # Find the first .csproj in the given path
    $csproj = Get-ChildItem -Path $Path -Filter *.csproj -File |
              Select-Object -First 1

    if ($null -ne $csproj) {
        # Assign to a global variable so you can use it outside the function
        $Global:CsprojPath = $csproj.FullName
        Write-Host "Found csproj: $Global:CsprojPath"
    }
    else {
        Write-Warning "No .csproj file found in $Path"
    }
}
