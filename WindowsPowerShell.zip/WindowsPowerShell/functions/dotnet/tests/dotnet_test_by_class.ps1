function Invoke-TestsByClass {
    param(
        [Parameter(Mandatory=$true, Position=0)]
        [string]$ClassName,

        # Default your root test namespace here (override if needed).
        [string]$Namespace = "RealCloud.API.IntegrationTests",

        # Optional: explicitly point to a DLL if you want to override detection.
        [string]$DllPath
    )

    $filter = "FullyQualifiedName~$Namespace.$ClassName."
    $cwd    = (Get-Location).Path

    function Find-Up([string[]]$patterns) {
        $dir = Get-Item $cwd
        while ($null -ne $dir) {
            foreach ($p in $patterns) {
                $hit = Get-ChildItem -Path $dir.FullName -Filter $p -File -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($hit) { return $hit.FullName }
            }
            $parent = $dir.Parent
            if ($null -eq $parent) { break }
            $dir = $parent
        }
        return $null
    }

    function Find-TestDll([string]$start) {
        Get-ChildItem -Path $start -Recurse -Filter "*Tests*.dll" -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -notmatch '\.ref\.' -and
                $_.DirectoryName -notmatch '\\ref(\\|$)' -and
                $_.Name -notmatch '\.resources\.dll$'
            } |
            Sort-Object LastWriteTimeUtc -Descending |
            Select-Object -First 1
    }

    # Explicit DLL beats auto-detect
    if ($DllPath) {
        if (-not (Test-Path $DllPath)) { throw "DLL not found: $DllPath" }
        Write-Host "Running vstest on: $DllPath"
        dotnet vstest "$DllPath" --TestCaseFilter:"$filter"
        return
    }

    # Heuristic: Are we in a publish/bin output (no projects nearby, DLLs present)?
    $looksLikePublish =
        ($cwd -match "\\publish(\\|$)") -or
        ((Get-ChildItem -Path $cwd -Filter "*.deps.json" -File -ErrorAction SilentlyContinue | Measure-Object).Count -gt 0) -and
        ((Get-ChildItem -Path $cwd -Recurse -Filter "*.csproj" -File -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0)

    # If we're clearly in repo/IDE context, prefer dotnet test
    $nearCsproj = Find-Up @("*Tests*.csproj")
    $nearSln    = if (-not $nearCsproj) { Find-Up @("*.sln") } else { $null }

    if ($nearCsproj -and -not $looksLikePublish) {
        Write-Host "Detected project context:`n  $nearCsproj"
        dotnet test "$nearCsproj" --filter "$filter"
        return
    }
    if ($nearSln -and -not $looksLikePublish) {
        Write-Host "Detected solution context:`n  $nearSln"
        dotnet test "$nearSln" --filter "$filter"
        return
    }

    # Otherwise try to find a test DLL and use vstest
    $dll = Find-TestDll $cwd
    if (-not $dll) {
        # If none in CWD, try typical build output roots
        $binCandidates = @(
            Join-Path $cwd "bin",
            Join-Path $cwd "..\bin",
            Join-Path $cwd "..\..\bin"
        ) | ForEach-Object { Resolve-Path $_ -ErrorAction SilentlyContinue } | Select-Object -ExpandProperty Path -ErrorAction SilentlyContinue

        foreach ($b in $binCandidates) {
            $dll = Find-TestDll $b
            if ($dll) { break }
        }
    }

    if ($dll) {
        Write-Host "Detected compiled test assembly:`n  $dll"
        dotnet vstest "$dll" --TestCaseFilter:"$filter"
    } else {
        throw "Could not locate a test project/solution or a compiled *Tests*.dll from '$cwd'. Try running from your repo root, a test project directory, or pass -DllPath."
    }
}
