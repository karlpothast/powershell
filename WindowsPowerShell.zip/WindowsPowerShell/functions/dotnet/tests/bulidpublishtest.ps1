
function buildpublishtest {
  delete_bin_and_object_directories_recursively;
  dotnet build;
  Invoke-PublishBat;
  copyappsettings;
  C:\Users\KarlPothast\source\repos\RealCloud-Imaging\RealCloud\RealCloud.API.IntegrationTests\1_RunIntegrationTests.bat;
}

function buildpublish {
  delete_bin_and_object_directories_recursively;
  dotnet build;
  Invoke-PublishBat;  
}