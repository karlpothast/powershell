function tests_menu_prj_directory {

    # 1) Run dotnet to list tests (skip build for speed)
    $raw = & dotnet test --list-tests --no-build 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Error "dotnet test failed. Output:`n$($raw -join [Environment]::NewLine)"
        return
    }

    # 2) Noise patterns (regex). ' -> ' drops lines like 'API -> C:\'
    $noise = @(
        '^The following Tests are available',
        '^Microsoft \(R\)',
        '^Starting test execution',
        '^Attachments:',
        '^VSTest',
        '^\s*$',
        '^All projects',
        '^Determining projects',
        '^Workload updates',
        '^Test run for',
        ' -> '
    )
    $noisePattern = '(?:' + ($noise -join '|') + ')'

    # Filter once, reuse
    $filtered = $raw | Where-Object {
        $line = $_.Trim()
        -not ($line -match $noisePattern)
    }

    # Extract unique class names
    
    # $classes = $filtered |
    #     ForEach-Object {
    #         $line = $_.Trim()
    #         if ($line -match '::') {
    #             ($line -split '::')[0]
    #         } else {
    #             $line -replace '\.[^\.]+$',''
    #         }
    #     } |
    #     Where-Object { $_ } |
    #     Sort-Object -Unique
    
    $classes = @(
    $filtered |
    ForEach-Object {
      $line = $_.Trim()
      if ($line -match '::') { ($line -split '::')[0] }
      else { $line -replace '\.[^\.]+$','' }
    } |
    Where-Object { $_ } |
    Sort-Object -Unique
)



    if (-not $classes) {
        Write-Warning "No test classes discovered."
        return
    }

    # Map: Class -> [FQN methods], and Class -> [Method names]
    $testMap     = @{}  # class -> string[] (FQN methods)
    $testNameMap = @{}  # class -> string[] (method names only)

    foreach ($t in $filtered) {
        $t2 = $t.Trim()
        if (-not $t2) { continue }

        # Normalize FQN to dot form
        if ($t2 -match '::') { $t2 = ($t2 -replace '::','.') }

        # class is everything before the last '.'
        if ($t2 -notmatch '\.') { continue }
        $lastDot = $t2.LastIndexOf('.')
        if ($lastDot -lt 1) { continue }

        $cls = $t2.Substring(0, $lastDot)
        $mth = $t2.Substring($lastDot + 1)

        if (-not $testMap.ContainsKey($cls))     { $testMap[$cls] = @() }
        if (-not $testNameMap.ContainsKey($cls)) { $testNameMap[$cls] = @() }

        if (-not ($testMap[$cls] -contains $t2))     { $testMap[$cls]     += $t2 }
        if (-not ($testNameMap[$cls] -contains $mth)) { $testNameMap[$cls] += $mth }
    }

    # 3) Menu
    Write-Host "Select test class(es) by number or range (e.g. 1-3,7,10,all)" -ForegroundColor Cyan
    for ($i = 0; $i -lt $classes.Count; $i++) {
        "{0,4}) {1}" -f ($i+1), $classes[$i]
    }

    $input1 = Read-Host "Enter selection"
    if ($input1 -match '^(?i)all$') {
        Write-Host ("Executing ALL {0} test class(es)..." -f $classes.Count) -ForegroundColor Yellow
        foreach ($c in $classes) {
            Write-Host "$c" -ForegroundColor Cyan
            & dotnet test --logger "console;verbosity=detailed" --filter:"FullyQualifiedName~$c"
        }
        return $classes
    }

    $chosen = New-Object System.Collections.Generic.List[string]
    foreach ($token in $input1 -split ',') {
        $t = $token.Trim()
        if ($t -match '^\d+-\d+$') {
            $lo,$hi = $t -split '-'
            $lo = [int]$lo; $hi = [int]$hi
            if ($lo -gt $hi) { $tmp=$lo; $lo=$hi; $hi=$tmp }
            for ($k = $lo; $k -le $hi; $k++) {
                if ($k -ge 1 -and $k -le $classes.Count) {
                    $chosen.Add($classes[$k-1])
                }
            }
        } elseif ($t -match '^\d+$') {
            $idx = [int]$t
            if ($idx -ge 1 -and $idx -le $classes.Count) {
                $chosen.Add($classes[$idx-1])
            }
        }
    }

    $selected = ($chosen | Sort-Object -Unique)
    if ($selected.Count -gt 0) {
        foreach ($c in $selected) {
            Write-Host ""
            Write-Host ("Class: {0}" -f $c) -ForegroundColor Green
            $choice = Read-Host "[R]un entire class, [D]rill down to method(s), [S]kip  (default: R)"

            if ($choice -match '^(?i)s$') {
                continue
            } elseif ($choice -match '^(?i)d$') {
                if (-not $testNameMap.ContainsKey($c) -or $testNameMap[$c].Count -eq 0) {
                    Write-Warning "No test methods found for class: $c"
                    continue
                }

                $methods = $testNameMap[$c]
                Write-Host ("Select method(s) in {0} by number/range (e.g. 1-3,7,10,all)" -f $c) -ForegroundColor Cyan
                for ($i = 0; $i -lt $methods.Count; $i++) {
                    "{0,4}) {1}" -f ($i+1), $methods[$i]
                }
                $minput = Read-Host "Enter selection"

                $selectedMethods = @()
                if ($minput -match '^(?i)all$') {
                    $selectedMethods = $methods
                } else {
                    foreach ($tok in $minput -split ',') {
                        $tt = $tok.Trim()
                        if ($tt -match '^\d+-\d+$') {
                            $lo,$hi = $tt -split '-'
                            $lo = [int]$lo; $hi = [int]$hi
                            if ($lo -gt $hi) { $tmp=$lo; $lo=$hi; $hi=$tmp }
                            for ($k = $lo; $k -le $hi; $k++) {
                                if ($k -ge 1 -and $k -le $methods.Count) {
                                    $selectedMethods += $methods[$k-1]
                                }
                            }
                        } elseif ($tt -match '^\d+$') {
                            $idx = [int]$tt
                            if ($idx -ge 1 -and $idx -le $methods.Count) {
                                $selectedMethods += $methods[$idx-1]
                            }
                        }
                    }
                    $selectedMethods = $selectedMethods | Sort-Object -Unique
                }

                if ($selectedMethods.Count -eq 0) {
                    Write-Host "No methods selected; skipping $c." -ForegroundColor DarkYellow
                    continue
                }

                # Find corresponding FQNs and run each
                $fqns = @()
                foreach ($m in $selectedMethods) {
                    $match = $testMap[$c] | Where-Object { $_.EndsWith(".$m") }
                    if ($match) { $fqns += $match }
                }

                foreach ($fq in $fqns) {
                    Write-Host ("{0}" -f $fq) -ForegroundColor Cyan
                    & dotnet test --logger "console;verbosity=detailed" --filter:"FullyQualifiedName=$fq"
                }

            } else {
                # Default: run entire class
                Write-Host ("{0}" -f $c) -ForegroundColor Cyan
                & dotnet test --logger "console;verbosity=detailed" --filter:"FullyQualifiedName~$c"
            }
        }
    }

    return ($chosen | Sort-Object -Unique)
}
