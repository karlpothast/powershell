function tests_menu_pub_directory {   

    [CmdletBinding()]
    param()

    $dlls = Get-ChildItem -Path (Get-Location) -Filter *.dll |
        Where-Object {
            $_.Name -match 'Test(s)?' -and
            $_.Name -notmatch '^(Microsoft|System|xunit)\.' -and
            $_.Name -notmatch '^testhost\.dll$'
        }

    $testDll=$null;
    $found = @()
    foreach ($dll in $dlls) {        
        $result = dotnet test $dll.FullName --list-tests --no-build 2>&1

        if ($result -notmatch "No test is available") {
            #Write-Host "Found test dll : $($dll.Name)" -ForegroundColor Green            
            $found += $dll.FullName
            $testDll = $dll;
            break;
        }
    }

    if ($found.Count -eq 0) {
        "No xunit test DLL found in directory."
        return $null
    } else {

      Write-Host("Test dll found : " + $testDll) -ForegroundColor Green;

    }

   # 1) Run vstest to list all tests
    $raw = & dotnet vstest $TestDll /ListTests 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Error "dotnet vstest failed. Output:`n$($raw -join [Environment]::NewLine)"
        return
    }

    # 2) Extract unique class names
    $noise = @(
        '^The following Tests are available',
        '^Microsoft \(R\)',
        '^Starting test execution',
        '^Attachments:',
        '^VSTest',
        '^\s*$'
    )

    $classes = $raw |
        Where-Object {
            $line = $_.Trim()
            -not ($noise | ForEach-Object { $line -match $_ } | Where-Object { $_ })
        } |
        ForEach-Object {
            $line = $_.Trim()
            if ($line -match '::') {
                ($line -split '::')[0]
            } else {
                $line -replace '\.[^\.]+$',''
            }
        } |
        Where-Object { $_ } |
        Sort-Object -Unique

    if (-not $classes) {
        Write-Warning "No test classes discovered in: $TestDll"
        return
    }

    # ADDED: Build a map of ClassName -> List of FullyQualifiedMethodNames
    #        and a per-class simple MethodName list for display.
    $testLines = $raw | Where-Object {
        $line = $_.Trim()
        -not ($noise | ForEach-Object { $line -match $_ } | Where-Object { $_ })
    }

    # ADDED: Normalize FQN to dot form and group by class
    $testMap = @{}       # class -> string[] (FQN methods)
    $testNameMap = @{}   # class -> string[] (Method names only, for menus)

    
    foreach ($t in $testLines) {
        $t2 = $t.Trim()
        if (-not $t2) { continue }
        # dot form FQN (Namespace.Class.Method)
        if ($t2 -match '::') { $t2 = ($t2 -replace '::','.') }

        # class is everything before the last '.'
        if ($t2 -notmatch '\.') { continue }
        $lastDot = $t2.LastIndexOf('.')
        if ($lastDot -lt 1) { continue }

        $cls = $t2.Substring(0, $lastDot)
        $mth = $t2.Substring($lastDot + 1)

        if (-not $testMap.ContainsKey($cls)) { $testMap[$cls] = @() }
        if (-not $testNameMap.ContainsKey($cls)) { $testNameMap[$cls] = @() }

        # Avoid duplicates
        if (-not ($testMap[$cls] -contains $t2))       { $testMap[$cls] += $t2 }
        if (-not ($testNameMap[$cls] -contains $mth))  { $testNameMap[$cls] += $mth }
    }
    # /ADDED

    # 3) Show menu
    Write-Host "Select test class(es) by number or range (e.g. 1-3,7,10,all)" -ForegroundColor Cyan
    for ($i = 0; $i -lt $classes.Count; $i++) {
        "{0,4}) {1}" -f ($i+1), $classes[$i]
    }

    $input1 = Read-Host "Enter selection"
    if ($input1 -match '^(?i)all$') {
        # ADDED: Run all classes, then return
        Write-Host ("Executing ALL {0} test class(es)..." -f $classes.Count) -ForegroundColor Yellow
        foreach ($c in $classes) {
            Write-Host "$c" -ForegroundColor Cyan
            & dotnet vstest $TestDll /TestCaseFilter:"FullyQualifiedName~$c"
        }
        return $classes
    }

    $chosen = New-Object System.Collections.Generic.List[string]
    foreach ($token in $input1 -split ',') {
        $t = $token.Trim()
        if ($t -match '^\d+-\d+$') {
            $lo,$hi = $t -split '-'
            $lo = [int]$lo; $hi = [int]$hi
            if ($lo -gt $hi) { $tmp=$lo; $lo=$hi; $hi=$tmp }
            for ($k = $lo; $k -le $hi; $k++) {
                if ($k -ge 1 -and $k -le $classes.Count) {
                    $chosen.Add($classes[$k-1])
                }
            }
        } elseif ($t -match '^\d+$') {
            $idx = [int]$t
            if ($idx -ge 1 -and $idx -le $classes.Count) {
                $chosen.Add($classes[$idx-1])
            }
        }
    }

    # ADDED: Drill-down or run per selected class
    $selected = ($chosen | Sort-Object -Unique)
    if ($selected.Count -gt 0) {
        foreach ($c in $selected) {
            Write-Host ""
            Write-Host ("Class: {0}" -f $c) -ForegroundColor Green
            $choice = Read-Host "[R]un entire class, [D]rill down to method(s), [S]kip  (default: R)"

            if ($choice -match '^(?i)s$') {
                continue
            } elseif ($choice -match '^(?i)d$') {
                # Show methods in class and pick
                if (-not $testNameMap.ContainsKey($c) -or $testNameMap[$c].Count -eq 0) {
                    Write-Warning "No test methods found for class: $c"
                    continue
                }

                $methods = $testNameMap[$c]
                Write-Host ("Select method(s) in {0} by number/range (e.g. 1-3,7,10,all)" -f $c) -ForegroundColor Cyan
                for ($i = 0; $i -lt $methods.Count; $i++) {
                    "{0,4}) {1}" -f ($i+1), $methods[$i]
                }
                $minput = Read-Host "Enter selection"

                $selectedMethods = @()
                if ($minput -match '^(?i)all$') {
                    $selectedMethods = $methods
                } else {
                    foreach ($tok in $minput -split ',') {
                        $tt = $tok.Trim()
                        if ($tt -match '^\d+-\d+$') {
                            $lo,$hi = $tt -split '-'
                            $lo = [int]$lo; $hi = [int]$hi
                            if ($lo -gt $hi) { $tmp=$lo; $lo=$hi; $hi=$tmp }
                            for ($k = $lo; $k -le $hi; $k++) {
                                if ($k -ge 1 -and $k -le $methods.Count) {
                                    $selectedMethods += $methods[$k-1]
                                }
                            }
                        } elseif ($tt -match '^\d+$') {
                            $idx = [int]$tt
                            if ($idx -ge 1 -and $idx -le $methods.Count) {
                                $selectedMethods += $methods[$idx-1]
                            }
                        }
                    }
                    $selectedMethods = $selectedMethods | Sort-Object -Unique
                }

                if ($selectedMethods.Count -eq 0) {
                    Write-Host "No methods selected; skipping $c." -ForegroundColor DarkYellow
                    continue
                }

                # Convert selected method *names* back to FQNs and run each
                $fqns = @()
                foreach ($m in $selectedMethods) {
                    # find the corresponding FQN in $testMap
                    $match = $testMap[$c] | Where-Object { $_.EndsWith(".$m") }
                    if ($match) { $fqns += $match }
                }

                foreach ($fq in $fqns) {
                    Write-Host ("{0}" -f $fq) -ForegroundColor Cyan
                    & dotnet vstest $TestDll --logger "console;verbosity=detailed" /TestCaseFilter:"FullyQualifiedName=$fq"
                }

            } else {
                # Default: run entire class
                Write-Host ("{0}" -f $c) -ForegroundColor Cyan
                & dotnet vstest $TestDll --logger "console;verbosity=detailed" /TestCaseFilter:"FullyQualifiedName~$c"
            }
        }
    }

    return ($chosen | Sort-Object -Unique);

}
