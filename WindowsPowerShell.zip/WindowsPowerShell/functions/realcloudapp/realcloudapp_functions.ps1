function cd_realcloud_api_directory
{
  $realCloudApiDirectory="$HOME\source\repos\RealCloud-Imaging\RealCloud\RealCloud.API\";  Clear-Host; Set-Location $realCloudApiDirectory;
}


function New-SandBox {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory, Position = 0)]
        [ValidateNotNullOrEmpty()]
        [string]$SourcePath,

        [Parameter(Mandatory, Position = 1)]
        [ValidateNotNullOrEmpty()]
        [string]$DestinationPath,

        # Also remove .github/ (workflows, issue templates, etc.)
        [switch]$RemoveGithubFolder
    )

    try {
        $src = (Resolve-Path -LiteralPath $SourcePath -ErrorAction Stop).Path
        $dst = [System.IO.Path]::GetFullPath($DestinationPath)

        if (-not (Test-Path -LiteralPath $src)) {
            throw "Source path not found: $SourcePath"
        }

        # Prevent copying into itself or inside the source
        if ($dst.StartsWith($src, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "Destination cannot be inside Source. Choose a different DestinationPath."
        }

        # Create destination if missing
        if (-not (Test-Path -LiteralPath $dst)) {
            if ($PSCmdlet.ShouldProcess($dst, "Create directory")) {
                New-Item -ItemType Directory -Path $dst | Out-Null
            }
        }

        # Copy everything over first (includes hidden items due to -Force)
        if ($PSCmdlet.ShouldProcess("$src -> $dst", "Copy recursive")) {
            Copy-Item -LiteralPath (Join-Path $src '*') -Destination $dst -Recurse -Force -Container -ErrorAction Stop
        }

        # Remove all .git directories (including submodules)
        $gitDirs = Get-ChildItem -LiteralPath $dst -Force -Recurse -Directory -Filter '.git' -ErrorAction SilentlyContinue
        foreach ($d in $gitDirs) {
            if ($PSCmdlet.ShouldProcess($d.FullName, "Remove .git directory")) {
                Remove-Item -LiteralPath $d.FullName -Recurse -Force -ErrorAction SilentlyContinue
            }
        }

        # Remove common git metadata files
        $gitFiles = @('.gitignore', '.gitattributes', '.gitmodules')
        foreach ($pattern in $gitFiles) {
            Get-ChildItem -LiteralPath $dst -Force -Recurse -File -Filter $pattern -ErrorAction SilentlyContinue |
                ForEach-Object {
                    if ($PSCmdlet.ShouldProcess($_.FullName, "Remove $pattern")) {
                        Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
                    }
                }
        }

        if ($RemoveGithubFolder) {
            # Remove any .github directories (CI workflows, templates)
            $ghDirs = Get-ChildItem -LiteralPath $dst -Force -Recurse -Directory -Filter '.github' -ErrorAction SilentlyContinue
            foreach ($d in $ghDirs) {
                if ($PSCmdlet.ShouldProcess($d.FullName, "Remove .github directory")) {
                    Remove-Item -LiteralPath $d.FullName -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
        }

        Write-Verbose "Copy complete. Git artifacts removed from: $dst"
        return $dst
    }
    catch {
        Write-Error $_.Exception.Message
    }
}
