function Stop-ProcessByPort {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory, Position=0)]
        [ValidateRange(1,65535)]
        [int]$Port,
        [ValidateSet('TCP','UDP')]
        [string]$Protocol = 'TCP',
        [switch]$AllMatches,
        [switch]$PassThru
    )

    $onWindows = ($PSVersionTable.PSEdition -eq 'Desktop') -or $IsWindows -or ($env:OS -eq 'Windows_NT')
    $procIds = @()

    if ($onWindows) {
        try {
            if ($Protocol -eq 'TCP' -and (Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue)) {
                $procIds = Get-NetTCPConnection -LocalPort $Port -ErrorAction Stop |
                           Select-Object -ExpandProperty OwningProcess -Unique
            } elseif ($Protocol -eq 'UDP' -and (Get-Command Get-NetUDPEndpoint -ErrorAction SilentlyContinue)) {
                $procIds = Get-NetUDPEndpoint -LocalPort $Port -ErrorAction Stop |
                           Select-Object -ExpandProperty OwningProcess -Unique
            }
        } catch {}

        if (-not $procIds) {
            $lines = netstat -ano | Select-String "[:\.]$Port\s"
            foreach ($line in $lines) {
                $parts = ($line.ToString().Trim() -split '\s+')
                $proto = $parts[0]
                if ($Protocol -eq 'TCP' -and $proto -ne 'TCP') { continue }
                if ($Protocol -eq 'UDP' -and $proto -ne 'UDP') { continue }
                $procIds += [int]$parts[-1]
            }
            $procIds = $procIds | Sort-Object -Unique
        }
    } else {
        if (Get-Command lsof -ErrorAction SilentlyContinue) {
            $arg = if ($Protocol -eq 'TCP') { "-iTCP:$Port" } else { "-iUDP:$Port" }
            $out = & lsof -n -P $arg -sTCP:LISTEN -t 2>$null
            if (-not $out) { $out = & lsof -n -P -i :$Port -t 2>$null }
            $procIds = $out | ForEach-Object { [int]$_ } | Sort-Object -Unique
        }
        if (-not $procIds -and (Get-Command ss -ErrorAction SilentlyContinue)) {
            $out = & ss -lpn "( sport = :$Port )" 2>$null
            foreach ($line in $out) {
                if ($Protocol -eq 'TCP' -and $line -notmatch '\btcp\b') { continue }
                if ($Protocol -eq 'UDP' -and $line -notmatch '\budp\b') { continue }
                if ($line -match 'pid=(\d+)') { $procIds += [int]$matches[1] }
            }
            $procIds = $procIds | Sort-Object -Unique
        }
    }

    if (-not $procIds) {
        Write-Verbose "No processes found using port $Port ($Protocol)."
        return
    }

    $killed = @()
    foreach ($procId in $procIds) {
        try {
            $proc = Get-Process -Id $procId -ErrorAction Stop
            if ($PSCmdlet.ShouldProcess("$($proc.ProcessName) (PID $procId)", "Kill")) {
                Stop-Process -Id $procId -Force -ErrorAction Stop
                Write-Host "Killed PID $procId ($($proc.ProcessName)) on port $Port ($Protocol)."
                $killed += $proc
            }
        } catch {
            Write-Warning "Failed to stop PID $($_.Exception.Message)"
        }
        if (-not $AllMatches) { break }
    }

    if ($PassThru) { return $killed }
}
