
function Docker_ListAllContainers {
  docker ps -a;
}

function Docker_ListAllImages {
  docker images -a;
}

function Docker_ListAllContainers_w_Networking {
  docker ps -a --format "table {{.ID}}\t{{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}\t{{.Networks}}";
}

function Docker_StopAllContainers {
  docker stop $(docker ps -aq)
}

function Docker_DeleteAllContainers {
  docker rm $(docker ps -aq)
}

function Docker_StopAndDeleteAllContainers {
  Docker_StopAllContainers;
  Docker_DeleteAllContainers;
}
