

#$PSVersionTable.PSVersion;


if ($PSVersionTable.PSVersion.ToString().Contains("5.1"))
{
  "Powershell 5.1"
}