:: File: aliases.bat
@echo off

:: Define aliases using doskey
doskey gs=git status
doskey ga=git add .
doskey gc=git commit -m $*
doskey ll=dir /B
doskey c=cls
doskey ls=dir
doskey la=dir /a
doskey b=cd ..
doskey pwd=cd
doskey grep=findstr
doskey shell="C:\Users\KarlPothast\Documents\WindowsPowerShell\cmd\getshell.cmd"
doskey home=cd %USERPROFILE%
doskey p=cmd

:: Show that the aliases are sourced then clear
cls
echo "Windows CMD aliases sourced"
timeout 1 >nul
cls

