@echo off
<nul set /p=cmd