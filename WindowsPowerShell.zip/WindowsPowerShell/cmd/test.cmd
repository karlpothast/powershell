@echo off
echo testing cmd function call from doskey
echo Done
