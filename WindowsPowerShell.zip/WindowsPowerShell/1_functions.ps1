function cd_realcloud_sln_directory
{
  $realCloudSlnDirectory="$HOME\source\repos\RealCloud-Imaging\RealCloud\";  Clear-Host; Set-Location $realCloudSlnDirectory;
}

function searchRealCloudCode {
    param(
        [Parameter(Mandatory = $true)]
        [string]$pattern
    )

    rg $pattern `
       --files-with-matches `
       --iglob '!C:\Users\KarlPothast\source\repos\RealCloud-Imaging\RealCloud\Desktop\wwwroot\cassette-cache\**' `
       --iglob '!C:\Users\KarlPothast\source\repos\RealCloud-Imaging\RealCloud\Offline\wwwroot\cassette-cache\**' `
       --iglob '!C:\Users\KarlPothast\source\repos\RealCloud-Imaging\RealCloud\RealCloud.Core\**' `
       -i
}

function getRealCloudSolutionDirectory()
{
  Write-Host $Env:RCI_SLN_PATH;
}

function la {
    eza --all --icons --group-directories-first --classify --grid    
}

function nj {
 node .\app.js;
}

function web {  
  live-server;f
}

function dev {  
  Set-Location "$env:USERPROFILE\source\workspaces\javascript\apps"
  #Start-Process "npx" -ArgumentList "live-server --port=8079" -NoNewWindow
  #Start-Process "npx.cmd" -ArgumentList "live-server --port=8079" -NoNewWindow
  Start-Process "cmd.exe" -ArgumentList "/c live-server --port=8079" -NoNewWindow
  #Start-Process "live-server" -ArgumentList "/c --port=8079" -NoNewWindow
  Write-Host "Dev apps started"
  Set-Location $HOME;
}

function navigate_to_jsapps_dir {
 Set-Location C:\Users\KarlPothast\source\workspaces\javascript\apps;
}

function downloads {
 Set-Location C:\Users\KarlPothast\Downloads;
}

function upDirectory {
  Set-Location ..
}

function real_cloud_app_scenarios {
  C:\Users\KarlPothast\source\workspaces\javascript\node-js\launchers\choose_app_scenario.ps1;
}

function kill_nodejs_puppeteer {
  C:\Users\KarlPothast\source\workspaces\javascript\node-js\launchers\kill_nodejs_puppeteer.ps1
}

function create_web_app {
  C:\Users\KarlPothast\source\workspaces\javascript\apps\codegenerator\cli\createWebApp.ps1
}

function open_rci_test_site() {
	node "C:\Users\KarlPothast\source\workspaces\javascript\node-js\launchers\actions\rci-test.js" --tag=puppeteer-run;
}

function get_alias_origin() {
  param(
          [Parameter(Mandatory = $true)]
          [string]$aliasname
      )

  Write-Host($aliasname);    
  $alias = Get-Alias $aliasname
  if ($alias) {
    $target = $alias.Definition
    if ($target -like "*\\*") {
        $location = Split-Path $target -Parent
        Write-Host "Alias '$aliasName' points to: '$target'"
        Write-Host "Location: '$location'"
      } else {
        Write-Host "Alias '$aliasName' points to: '$target'"
    }
  } else {
        Write-Host "Alias '$aliasName' not found."
  }
}

function navigate_to_home_directory {
    Set-Location $HOME;    
}

function navigate_to_powershell_home_directory {
    Set-Location $HOME;   
}

$global:LastDir = $PWD
function cd_last_directory {
    param($path)
    if ($path -eq '-') {
        Set-Location $global:LastDir
    } else {
        $global:LastDir = $PWD
        Set-Location $path
    }
}

function forward {
    param($path)
    if ($path -eq '-') {
        Set-Location $global:LastDir
    } else {
        $global:LastDir = $PWD
        Set-Location $path
    }
}

function copy_working_directory() {
  $CurrentPath = (Get-Location).Path;
  Set-Clipboard -Value $CurrentPath;
}

function check_running_as_admin {
  # Check if running as Administrator
  $isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()
  ).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)

  # Output result
  if ($isAdmin) {
      return "True"
  } else {
      return "False"
  }
}

function isAdmin {
  # This returns True if you are admin
  ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}


function startAspNetWebApp {
      param (        
        [string]$directory,
        [int]$port
    )
  Stop-Process -Name "iisexpress.exe" -Force
  & "C:\Program Files (x86)\IIS Express\iisexpress.exe" --% /path:$directory /port:$port
}


function Start-IISExpressOnAvailablePort {
    param (
        [string]$PathToSite = "C:\inetpub\wwwroot",
        [int]$StartPort = 8080,
        [int]$MaxPort = 8100
    )

    # Function to check if a port is in use
    function Test-PortInUse {
        param([int]$Port)
        return (Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue) -ne $null
    }

    # Find first available port
    $SelectedPort = $null
    for ($port = $StartPort; $port -le $MaxPort; $port++) {
        if (-not (Test-PortInUse -Port $port)) {
            $SelectedPort = $port
            break
        }
    }

    if (-not $SelectedPort) {
        Write-Error "No available port found between $StartPort and $MaxPort."
        return
    }

    Write-Host "Using port $SelectedPort for IIS Express..."

    # Path to IIS Express
    $iisExpressPath = "${env:ProgramFiles(x86)}\IIS Express\iisexpress.exe"

    if (-not (Test-Path $iisExpressPath)) {
        Write-Error "IIS Express not found at '$iisExpressPath'"
        return
    }

    # Start IIS Express
    Start-Process -FilePath $iisExpressPath -ArgumentList "/path:$PathToSite /port:$SelectedPort" -NoNewWindow

    Write-Host "IIS Express started at http://localhost:$SelectedPort"
}

function SleepMs {
  param (                
      [int]$ms
    )
  Start-Sleep -Milliseconds $ms;
}

function start-powershell-nologo {
  PowerShell -nologo;
}

function show_current_profile {
  $PROFILE;
}

function dotnet_run {
  dotnet run;
}

function dotnet_run_verbose {
  dotnet run -v diag;
}

function dotnet_test {
  #dotnet test --no-build --no-restore
  dotnet test;
}

function dotnet_test_with_logging {
  dotnet test --logger "console;verbosity=detailed"
}

function dotnet_test_with_coverlet {
  dotnet test --collect:"XPlat Code Coverage"
}

function dotnet_build {
  dotnet build;
}

function dotnet_build_verbose {
  dotnet build -v diag;
}

function dotnet_clean {
  dotnet clean;
  dotnet_clear_all_bin_and_obj_folders;
  Clear-Host;
  "dotnet clean completed, bin & obj directories deleted"; 
}

function dotnet_clear_all_bin_and_obj_folders {
  C:\Users\KarlPothast\source\workspaces\dotnet\utilities\delete_all_bin_and_obj_dirs.ps1;
  Clear-Host;
}

function delete_bin_and_object_directories_recursively {
 & "$env:USERPROFILE\source\workspaces\dotnet\utilities\delete_all_bin_and_obj_dirs.ps1"
}

function get_current_shell {  
  if ($PSVersionTable.PSVersion.ToString().Contains("5.1"))
  {
    "Powershell 5.1"
  }
}



# function getAllLines2 {
#     param (
#         [Parameter(Mandatory = $true)]
#         [string]$directory
#     )

#     Write-Host $directory

# }

function getAllConsoleLogLines {
    param (
        [Parameter(Mandatory = $true)]
        [string]$directory
    )

   "Searching directory : $directory";
   $rootDir = $directory;

  # Recursively search for 'console.log' in files
  Get-ChildItem -Path $rootDir -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
      $file = $_.FullName
      try {
          Select-String -Path $file -Pattern 'console' -SimpleMatch | ForEach-Object {
              # Output the file path in clickable format (if supported by terminal)
              Write-Host "Found in: " -NoNewline
              Write-Host $file -ForegroundColor Cyan
          }
      } catch {
          # Handle any access/encoding errors silently
      }
  }

}

# function removeAllConsoleLogLines {
#     param (
#         [Parameter(Mandatory = $true)]
#         [string]$ProjectDirectory
#     )

#     # Get all JavaScript files recursively
#     Get-ChildItem -Path $ProjectDirectory -Recurse -Include *.js | ForEach-Object {
#       $file = $_.FullName

#       # Read all lines and filter out any that contain 'console.log'
#       $filteredLines = Get-Content -Path $file | Where-Object { $_ -notmatch 'console\.log' }

#       # Write the filtered lines back to the file
#       Set-Content -Path $file -Value $filteredLines
#    }
# }

function get_working_directory {
  $PWD.Path
}

function start_ocr_webapp {
  #Stop-Process -Name "iisexpress.exe" -Force
  & "C:\Program Files (x86)\IIS Express\iisexpress.exe" --% /path:"C:\Users\KarlPothast\source\repos\ASPNET_OCR2\ASPNET_OCR2" /port:8081
}


function GoToSystem32 {
  Set-Location -Path C:\Windows\System32;  	
}

#function Set-Location {
#  param(
#   [string]$Path
#  )
#  Write-Host "Changing location to: $Path (Custom override)"
#  Microsoft.PowerShell.Management\Set-Location -Path $Path
#}

function get_remotes {
  git fetch --prune
}

function edit_aliases_with_notepad {
  notepad "C:\Users\KarlPothast\Documents\WindowsPowerShell\2_aliases.ps1";
}

function edit_functions_with_notepad {
  notepad "C:\Users\KarlPothast\Documents\WindowsPowerShell\1_functions.ps1"
}

function start_windows_api {
  $winApiPath = "C:\Users\KarlPothast\source\repos\WindowsAPI";
  Set-Location $winApiPath;
  #Start-Process "dotnet" -ArgumentList "run" -RedirectStandardOutput "output.log" -RedirectStandardError "error.log" -NoNewWindow;
  $proc = Start-Process "dotnet" -ArgumentList "run" -NoNewWindow -PassThru
  Write-Host "Windows API starting.."
  Start-Sleep -Seconds 2
  Write-Host "Dev API started with PID $($proc.Id)"
}

function get_ports_listening {
  C:\Users\KarlPothast\source\workspaces\powershell\network\ports.ps1
}

function stop_teams {
  C:\Users\KarlPothast\source\workspaces\powershell\utilities\teams\stopTeams.ps1;
}

function get_env_var_paths_formatted {
  C:\Users\KarlPothast\source\workspaces\powershell\env_vars\getPaths.ps1;
}

function simulate_pullrequest_from_staged {
 $summaryDiffFilePath="C:\Users\KarlPothast\source\workspaces\javascript\apps\simulatepr\staged-summary.diff";
 if (Test-Path $summaryDiffFilePath) { 
	"summary file deleted 1";
	Remove-Item $summaryDiffFilePath;
 }

 $stagedDiffFilePath="C:\Users\KarlPothast\source\workspaces\javascript\apps\simulatepr\staged.diff";
 if (Test-Path $stagedDiffFilePath) { 
	"diffs file deleted 2";
	Remove-Item $stagedDiffFilePath;
 }

 $realCloudSlnDirectory="$HOME\source\repos\RealCloud-Imaging\RealCloud\";  
 #Clear-Host; 
 Set-Location $realCloudSlnDirectory;
 
 git diff --cached > $stagedDiffFilePath;
 "diff file created";
 git diff --cached --numstat --name-status > $summaryDiffFilePath;
 "diff summary file created";
 Set-Location "C:\Users\KarlPothast\source\workspaces\javascript\apps\simulatepr";
 
 live-server;
}

function vscode_keybindings {
  $vsCodeUserDir=$env:APPDATA + "\Code\User\";
  $vsCodeKeyBindingsFilePath = $vsCodeUserDir + "keybindings.json";
  code $vsCodeKeyBindingsFilePath;
}

# function grep {
#     param(
#         [Parameter(Position = 0, Mandatory = $true)]
#         [string]$Pattern,
#         [switch]$IgnoreCase,
#         [switch]$InvertMatch
#     )

#     $regexOptions = if ($IgnoreCase) { 'IgnoreCase' } else { 'None' }

#     process {
#         foreach ($line in $_) {
#             $isMatch = [regex]::IsMatch($line, $Pattern, $regexOptions)
#             if ($InvertMatch) {
#                 if (-not $isMatch) { $line }
#             } else {
#                 if ($isMatch) { $line }
#             }
#         }
#     }
# }

function Analyze-CSharpFileWithRoslynator {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [string]$MsBuildPath = $null
    )

    $resolvedPath = Resolve-Path $Path -ErrorAction Stop

    if (-not (Test-Path $resolvedPath)) {
        Write-Error "Path not found: $Path"
        return
    }

    # Choose a .cs file
    if ((Get-Item $resolvedPath).PSIsContainer) {
        $csFile = Get-ChildItem -Path $resolvedPath -Recurse -Filter *.cs | Select-Object -First 1
        if (-not $csFile) { Write-Error "No .cs files found in $resolvedPath"; return }
    } else {
        $csFile = Get-Item $resolvedPath
        if ($csFile.Extension -ne ".cs") { Write-Error "Not a .cs file: $Path"; return }
    }

    # Find nearest .csproj
    $searchDir = Split-Path $csFile.FullName -Parent
    $projectFile = $null
    while ($searchDir -and -not $projectFile) {
        $projectFile = Get-ChildItem -Path $searchDir -Filter *.csproj -ErrorAction SilentlyContinue | Select-Object -First 1
        $searchDir   = Split-Path $searchDir -Parent
    }
    if (-not $projectFile) { Write-Error "No .csproj found above '$($csFile.FullName)'"; return }

    # Make include path relative to project directory and normalized to forward slashes (glob friendly)
    $projDir = Split-Path $projectFile.FullName -Parent
    $rel = Resolve-Path $csFile.FullName | ForEach-Object {
        [System.IO.Path]::GetRelativePath($projDir, $_)
    }
    $include = $rel -replace '\\','/'  # e.g., "Src/Foo/Bar.cs"

    $args = @(
        'analyze', $projectFile.FullName,
        '--include', $include,               # relative include
        '--severity-level', 'info',          # show suggestions/info
        '--verbosity', 'detailed'
    )

    if ($MsBuildPath) {
        $args += @('--msbuild-path', $MsBuildPath)
    }

    Write-Host "Project: $($projectFile.FullName)"
    Write-Host "File:    $($csFile.FullName)"
    Write-Host "Include: $include"
    Write-Host "Running: roslynator $($args -join ' ')"

    roslynator @args
}



function edit_postgres_config {
  notepad "C:\Program Files\PostgreSQL\16\data\postgresql.conf";
}


function Remove-BOM {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$FilePath
    )

    if (-not (Test-Path $FilePath)) {
        Write-Error "File not found: $FilePath"
        return
    }

    # Read file as raw bytes
    $bytes = [System.IO.File]::ReadAllBytes($FilePath)

    # UTF-8 BOM = 0xEF 0xBB 0xBF
    if ($bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        Write-Host "BOM found. Removing from: $FilePath"
        $utf8Text = [System.Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3)
    }
    else {
        Write-Host "No BOM found. Rewriting as UTF-8 without BOM: $FilePath"
        $utf8Text = [System.Text.Encoding]::UTF8.GetString($bytes)
    }

    # Re-save as UTF-8 without BOM
    [System.IO.File]::WriteAllText($FilePath, $utf8Text, [System.Text.UTF8Encoding]::new($false))
}

function Import_API_TestingFiles_ToCurrentDir {
    $appSettings_sourcePath = "C:\Users\KarlPothast\source\repos\RealCloudAPITestingFiles\*"
    $destinationPath = Get-Location  # current working directory

    if (Test-Path $appSettings_sourcePath) {
        Copy-Item -Path $appSettings_sourcePath -Destination $destinationPath -Recurse -Force
        Write-Host "Copied files from $appSettings_sourcePath to $destinationPath"
    } else {
        Write-Warning "Source path not found: $appSettings_sourcePath"
    }
}

function RemoveBOMFromFileForReal {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory, Position = 0)]
        [string]$Path
    )

    if (-not (Test-Path $Path)) {
        throw "File not found: $Path"
    }

    # Read raw bytes
    $bytes = [System.IO.File]::ReadAllBytes($Path)

    # Detect UTF-8 BOM
    if ($bytes.Length -ge 3 -and 
        $bytes[0] -eq 0xEF -and 
        $bytes[1] -eq 0xBB -and 
        $bytes[2] -eq 0xBF) {
        
        Write-Verbose "UTF-8 BOM detected in $Path"
        $bytes = $bytes[3..($bytes.Length - 1)]
    }

    # Detect UTF-16 LE BOM
    elseif ($bytes.Length -ge 2 -and 
        $bytes[0] -eq 0xFF -and 
        $bytes[1] -eq 0xFE) {

        Write-Verbose "UTF-16 LE BOM detected in $Path"
        $bytes = $bytes[2..($bytes.Length - 1)]
    }

    # Detect UTF-16 BE BOM
    elseif ($bytes.Length -ge 2 -and 
        $bytes[0] -eq 0xFE -and 
        $bytes[1] -eq 0xFF) {

        Write-Verbose "UTF-16 BE BOM detected in $Path"
        $bytes = $bytes[2..($bytes.Length - 1)]
    }

    # Detect UTF-32 LE BOM
    elseif ($bytes.Length -ge 4 -and 
        $bytes[0] -eq 0xFF -and 
        $bytes[1] -eq 0xFE -and 
        $bytes[2] -eq 0x00 -and 
        $bytes[3] -eq 0x00) {

        Write-Verbose "UTF-32 LE BOM detected in $Path"
        $bytes = $bytes[4..($bytes.Length - 1)]
    }

    # Detect UTF-32 BE BOM
    elseif ($bytes.Length -ge 4 -and 
        $bytes[0] -eq 0x00 -and 
        $bytes[1] -eq 0x00 -and 
        $bytes[2] -eq 0xFE -and 
        $bytes[3] -eq 0xFF) {

        Write-Verbose "UTF-32 BE BOM detected in $Path"
        $bytes = $bytes[4..($bytes.Length - 1)]
    }
    else {
        Write-Verbose "No BOM found in $Path"
        return
    }

    # Write back without BOM
    [System.IO.File]::WriteAllBytes($Path, $bytes)
    Write-Verbose "Removed BOM from $Path"
}


function dirs{
    [CmdletBinding()]
    param(
        [switch]$FullPath,   # show full paths instead of names
        [switch]$Recurse     # include subdirectories recursively
    )

    $path = $PWD.Path  # current directory
    $items = Get-ChildItem -Path $path -Directory -Force -Recurse:$Recurse
    if ($FullPath) {
        $items | ForEach-Object { $_.FullName.TrimEnd('\') + '\' }
    } else {
        $items | ForEach-Object { $_.Name.TrimEnd('\') + '\' }
    }
}

function ConvertToUtf8RmBomRecursively {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param(
        [Parameter(Mandatory, Position=0)]
        [string]$Path,

        # Only process files with these extensions (leave empty to process all)
        [string[]]$Extensions = @(),   # e.g. @('.ps1','.cs','.json','.txt')

        # Include hidden/system files too
        [switch]$IncludeHidden
    )

    if (-not (Test-Path $Path)) { throw "Path not found: $Path" }

    # Simple binary sniff: if the first 8KB has NULs or lots of non-text chars, skip.
    function Test-IsBinary([string]$File) {
        try {
            $fs = [System.IO.File]::Open($File, 'Open', 'Read', 'ReadWrite')
            try {
                $len = [Math]::Min(8192, [int]$fs.Length)
                $buf = New-Object byte[] $len
                [void]$fs.Read($buf, 0, $len)
            } finally { $fs.Dispose() }
        } catch { return $true }

        if ($buf -contains 0x00) { return $true }
        $textish = ($buf | Where-Object {
            ($_ -ge 9 -and $_ -le 13) -or ($_ -ge 32 -and $_ -le 126) -or ($_ -ge 160)
        }).Count
        return ($textish / [Math]::Max(1,$buf.Length)) -lt 0.85
    }

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    $items =
        if (Test-Path $Path -PathType Container) {
            $gciParams = @{ Recurse = $true; File = $true }
            if (-not $IncludeHidden) { $gciParams['Attributes'] = '!Hidden, !System' }
            Get-ChildItem -LiteralPath $Path @gciParams
        } else {
            Get-Item -LiteralPath $Path
        }

    $processed = 0; $skipped = 0
    foreach ($f in $items) {
        if ($Extensions.Count -gt 0 -and ($Extensions -notcontains $f.Extension)) { $skipped++; continue }
        if (Test-IsBinary $f.FullName) { Write-Verbose "Skipping binary: $($f.FullName)"; $skipped++; continue }

        # Let StreamReader auto-detect BOMs/encodings, then re-save as UTF-8 (no BOM)
        try {
            $text = [System.IO.File]::ReadAllText($f.FullName)  # BOM-aware reader
        } catch {
            Write-Verbose "Skipping unreadable file: $($f.FullName) ($_ )"
            $skipped++; continue
        }

        # Only write if needed (different encoding or has BOM). Quick check: does file start with a known BOM?
        $needsWrite = $true
        try {
            $first4 = [System.IO.File]::OpenRead($f.FullName)
            $buf4 = New-Object byte[] 4
            [void]$first4.Read($buf4,0,4); $first4.Dispose()
            $hasBom =
                ($buf4[0..2] -join ',') -eq '239,187,191' -or    # UTF-8 BOM
                ($buf4[0..1] -join ',') -eq '255,254'    -or     # UTF-16 LE
                ($buf4[0..1] -join ',') -eq '254,255'    -or     # UTF-16 BE
                ($buf4 -join ',')       -eq '255,254,0,0' -or    # UTF-32 LE
                ($buf4 -join ',')       -eq '0,0,254,255'        # UTF-32 BE
            # If no BOM and already valid UTF-8, re-saving would produce identical bytes.
            if (-not $hasBom) {
                # Try reading bytes and checking if they’re valid UTF-8 by re-encoding
                $raw = [System.IO.File]::ReadAllBytes($f.FullName)
                try {
                    $str = [System.Text.Encoding]::UTF8.GetString($raw)
                    $roundtrip = [System.Text.Encoding]::UTF8.GetBytes($str)
                    $needsWrite = -not ($raw.Length -eq $roundtrip.Length -and
                                        [System.Linq.Enumerable]::SequenceEqual($raw, $roundtrip))
                } catch { $needsWrite = $true }
            }
        } catch { $needsWrite = $true }

        if ($needsWrite -and $PSCmdlet.ShouldProcess($f.FullName, "Save as UTF-8 (no BOM)")) {
            [System.IO.File]::WriteAllText($f.FullName, $text, $utf8NoBom)
            Write-Verbose "Converted to UTF-8 (no BOM): $($f.FullName)"
            $processed++
        } else {
            $skipped++
        }
    }

    [pscustomobject]@{
        Path      = (Resolve-Path $Path).Path
        Processed = $processed
        Skipped   = $skipped
    }
}

function git-phantom-files {
  C:\Users\KarlPothast\source\workspaces\git\pull_requests\phantom_files\all_phantoms.ps1;
}

function copypath_picklist {
  C:\Users\KarlPothast\source\workspaces\powershell\files_directories\copypath.ps1;
}

function Get-FileEncodingReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory, Position=0)]
        [string]$Path,

        [Parameter(Position=1)]
        [bool]$BomOnly = $false
    )

    if (-not (Test-Path -LiteralPath $Path)) { throw "Path not found: $Path" }

    function Test-IsBinary([string]$FilePath) {
        try {
            $fs = [System.IO.File]::Open($FilePath,'Open','Read','ReadWrite')
            try {
                $len = [Math]::Min(8192, [int]$fs.Length)
                $buf = New-Object byte[] $len
                [void]$fs.Read($buf,0,$len)
            } finally { $fs.Dispose() }
        } catch { return $true }

        if ($buf -contains 0x00) { return $true }
        $textish = ($buf | Where-Object {
            ($_ -ge 9 -and $_ -le 13) -or ($_ -ge 32 -and $_ -le 126) -or ($_ -ge 160)
        }).Count
        return ($textish / [Math]::Max(1,$buf.Length)) -lt 0.85
    }

    function Get-BomInfo([byte[]]$First4) {
        $sig3 = ($First4[0..2] -join ',') 2>$null
        $sig2 = ($First4[0..1] -join ',') 2>$null
        $sig4 = ($First4 -join ',')        2>$null

        switch ($true) {
            { $sig3 -eq '239,187,191' } { return @{ HasBOM=$true; BomType='UTF-8 BOM'   } }
            { $sig2 -eq '255,254'     } { return @{ HasBOM=$true; BomType='UTF-16 LE BOM'} }
            { $sig2 -eq '254,255'     } { return @{ HasBOM=$true; BomType='UTF-16 BE BOM'} }
            { $sig4 -eq '255,254,0,0' } { return @{ HasBOM=$true; BomType='UTF-32 LE BOM'} }
            { $sig4 -eq '0,0,254,255' } { return @{ HasBOM=$true; BomType='UTF-32 BE BOM'} }
            default                     { return @{ HasBOM=$false; BomType='None'       } }
        }
    }

    function Detect-Encoding([string]$FilePath, [byte[]]$Raw) {
        try {
            $sr = New-Object System.IO.StreamReader($FilePath, $true)
            try { [void]$sr.ReadToEnd(); $enc = $sr.CurrentEncoding } finally { $sr.Dispose() }
        } catch { $enc = $null }

        if ($enc -ne $null) { return $enc.WebName }

        try {
            $str = [System.Text.Encoding]::UTF8.GetString($Raw)
            $round = [System.Text.Encoding]::UTF8.GetBytes($str)
            if ($round.Length -eq $Raw.Length -and
               [System.Linq.Enumerable]::SequenceEqual($round,$Raw)) {
                return 'utf-8'
            }
        } catch {}

        return 'windows-1252'
    }

    # Gather files (include hidden/system by default)
    $items =
        if (Test-Path $Path -PathType Container) {
            Get-ChildItem -LiteralPath $Path -File -Recurse -Force
        } else {
            Get-Item -LiteralPath $Path
        }

    # Build rows
    $rows = foreach ($f in $items) {
        $isBinary = Test-IsBinary $f.FullName
        $first4   = New-Object byte[] 4
        try {
            $fs = [System.IO.File]::OpenRead($f.FullName)
            try { [void]$fs.Read($first4,0,4) } finally { $fs.Dispose() }
        } catch {
            [pscustomobject]@{
                Path      = $f.FullName
                SizeBytes = $f.Length
                IsBinary  = $true
                Encoding  = 'unreadable'
                HasBOM    = $null
                BomType   = 'unreadable'
            }
            continue
        }

        $bom = Get-BomInfo $first4

        $raw = $null
        if (-not $isBinary) {
            try {
                if ($f.Length -le 5MB) { $raw = [System.IO.File]::ReadAllBytes($f.FullName) }
                else {
                    $fs = [System.IO.File]::OpenRead($f.FullName)
                    try {
                        $len = [Math]::Min(1MB, [int]$fs.Length)
                        $raw = New-Object byte[] $len
                        [void]$fs.Read($raw,0,$len)
                    } finally { $fs.Dispose() }
                }
            } catch {}
        }

        $encodingName =
            if ($isBinary) { 'binary' }
            elseif ($raw -ne $null) { Detect-Encoding $f.FullName $raw }
            else { 'unknown' }

        [pscustomobject]@{
            Path      = $f.FullName
            SizeBytes = $f.Length
            IsBinary  = $isBinary
            Encoding  = $encodingName
            HasBOM    = $bom.HasBOM
            BomType   = $bom.BomType
        }
    }

    # Summary (computed on full set)
    $totalFiles = $rows.Count
    $totalText  = ($rows | Where-Object { -not $_.IsBinary }).Count
    $totalBin   = ($rows | Where-Object { $_.IsBinary }).Count
    $withBOM    = ($rows | Where-Object { $_.HasBOM }).Count
    $withoutBOM = ($rows | Where-Object { (-not $_.HasBOM) -and (-not $_.IsBinary) }).Count

    # Print summary first
    Write-Host "=== File Encoding Report Summary ==="
    Write-Host ("Root path:       {0}" -f (Resolve-Path $Path).Path)
    Write-Host ("Total files:     {0}" -f $totalFiles)
    Write-Host ("Text files:      {0}" -f $totalText)
    Write-Host ("Binary files:    {0}" -f $totalBin)
    Write-Host ("With BOM:        {0}" -f $withBOM)
    Write-Host ("Without BOM:     {0}" -f $withoutBOM)
    if ($BomOnly) { Write-Host "Filter:          BOM ONLY (table shows only files that contain a BOM)" }
    Write-Host "===================================="
    Write-Host ""

    # Optional filter for table
    $tableRows = if ($BomOnly) {
        $rows | Where-Object { $_.HasBOM }
    } else {
        $rows
    }

    # Table
    $tableRows | Sort-Object IsBinary, Encoding, BomType, Path | Format-Table -AutoSize
}


function cd_integration_project {
  cd C:\Users\KarlPothast\source\repos\RealCloud-Imaging\RealCloud\RealCloud.API.IntegrationTests;
}

function cd_apitests {
  cd C:\Users\KarlPothast\source\repos\RealCloud-Imaging\RealCloud\bin\API.Tests;
}

function dotnet_new_console_app {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$AppName
    )
    dotnet new console -n $AppName
}

function dotnet_new_console_app_with_main {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$AppName
    )
    dotnet new console -n $AppName --use-program-main
}

function Get-JsonEscapedPath {
    param(
        [Parameter(Position = 0, Mandatory = $true)]
        [string]$Path
    )

    # Normalize to a full path
    $resolved = Resolve-Path $Path | Select-Object -ExpandProperty Path

    # Convert to JSON string (adds escaping as needed)
    $jsonEscaped = $resolved | ConvertTo-Json -Compress
    Set-Clipboard $jsonEscaped
    Write-Host($jsonEscaped + " copied to clipboard")

    return $jsonEscaped
}

function Get-PathFromJsonEscaped {
    param(
        [Parameter(Position = 0, Mandatory = $true)]
        [string]$JsonEscapedPath
    )

    try {
        # Ensure it's wrapped in quotes so ConvertFrom-Json works
        if ($JsonEscapedPath[0] -ne '"') {
            $JsonEscapedPath = '"' + $JsonEscapedPath + '"'
        }

        # Parse the JSON string, which unescapes it
        $path = $JsonEscapedPath | ConvertFrom-Json
        Set-Clipboard $path
        Write-Host($path + " copied to clipboard")
        return $path
    }
    catch {
        Write-Error "Invalid JSON escaped path: $JsonEscapedPath"
    }
}

function Invoke-ResetTestDataPS {
    param (
        [string]$Directory = (Get-Location)
    )

    $scriptPath = Join-Path -Path $Directory -ChildPath "ResetTestData.ps1"

    if (Test-Path $scriptPath) {
        Write-Host "Running $scriptPath ..."
        & $scriptPath
    }
    else {
        Write-Host "No ResetTestData.ps1 found in $Directory. Skipping."
    }
}

