@echo off
 tools.bat

if %~1== (
    echo Available commands greet, showdate
    goto EOF
)

set CMD=%~1
shift

if i %CMD%==greet    call greet %
if i %CMD%==showdate call showdate %
goto EOF

greet
echo Hello, %1!
goto EOF

showdate
echo Today is %DATE%
goto EOF
