# Path to your aliases.txt
$aliasFile="$HOME\ps\powershell_aliases.ps1"

if (Test-Path $aliasFile) {
    Get-Content $aliasFile | ForEach-Object {
        if ($_ -match "^([^=]+)=(.+)$") {
            $alias = $matches[1].Trim()
            $command = $matches[2].Trim()

            # If it's just a simple alias, use Set-Alias
            if ($command -notmatch "\s") {
                Set-Alias -Name $alias -Value $command -Force
            }
            else {
                # For more complex commands, wrap in a function
               # Set-Item "function:$alias" -Value $command
            }
        }
    }
}


$aliasFile = "$HOME\\OneDrive\Documents\\WindowsPowerShell\\aliases.ps1"
if (Test-Path $aliasFile) {
  . $aliasFile
} else {
  Write-Host "Aliases file not found";
}



