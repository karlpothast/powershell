@echo off
doskey c=cls

cls
echo Cmd aliases sourced
@timeout 1 > NUL
cls
