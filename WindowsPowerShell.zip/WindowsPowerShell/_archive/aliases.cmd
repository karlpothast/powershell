doskey gs=git status
doskey gc=git commit
doskey ll=dir
