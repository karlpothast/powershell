
cd C:\Users\KarlPothast\source\repos\WindowsAPI
dotnet run