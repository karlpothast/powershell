# remove any aliases already taken with built-in aliases
if (Test-Path Alias:h) { Remove-Item Alias:h }

# windows/navigation
Set-Alias h navigate_to_home_directory;
Set-Alias c Clear-Host;
Set-Alias p start-powershell-nologo;
Set-Alias l less;
Set-Alias pro show_current_profile;
Set-Alias b upDirectory
Set-Alias getalias get_alias_origin;
Set-Alias ph navigate_to_powershell_home_directory;
Set-Alias cpwd copy_working_directory;
Set-Alias cwd copy_working_directory;
Set-Alias isadmin check_running_as_admin;
Set-Alias shell get_current_shell;
Set-Alias wd get_working_directory;
Set-Alias n notepad;
Set-Alias reg regedit;
Set-Alias sys32 GoToSystem32;
Set-Alias ae edit_aliases_with_notepad
Set-Alias fe edit_functions_with_notepad
Set-Alias ff WindowsPowershellObjects_Workspace;
Set-Alias devapi start_windows_api;
Set-Alias paths get_env_var_paths_formatted;
Set-Alias win11apps Open_WindowsAppsFolder;
Set-Alias grep Select-String;
Set-Alias closeteams stop_teams;
Set-Alias down downloads;
Set-Alias files C:\Users\KarlPothast\source\workspaces\powershell\windows11\filefolderstructure.ps1;

# dotnet
Set-Alias .r dotnet_run;
Set-Alias .rv dotnet_run_verbose;
Set-Alias .bv dotnet_build_verbose;
Set-Alias .t dotnet_test;
Set-Alias .tcov dotnet_test_with_coverlet;
Set-Alias .tc Invoke-TestsByClass;
Set-Alias .tl dotnet_test_with_logging;
Set-Alias .tv dotnet_test_with_logging;
Set-Alias .b dotnet_build;
Set-Alias .c dotnet_clean;
Set-Alias .nc dotnet_new_console_app;
Set-Alias .ncm dotnet_new_console_app_with_main;
Set-Alias .bp buildpublish;
Set-Alias .bpt buildpublishtest;
Set-Alias .d dotnet_clear_all_bin_and_obj_folders;
Set-Alias pub Invoke-PublishBat;
Set-Alias .p PublishIntegrationTests;
Set-Alias re RunResharperOnPrjAndOutputToHtml;


# javascript
Set-Alias cweb create_web_app;
Set-Alias web live-server;
Set-Alias jsapps navigate_to_jsapps_dir;
Set-Alias rmlogs Remove-ConsoleLogLines;

# realcloud app
Set-Alias rc cd_realcloud_sln_directory;
Set-Alias rcapi cd_realcloud_api_directory;
Set-Alias api cd_realcloud_api_directory;
Set-Alias rctest cd_integration_project;
Set-Alias rctests cd_integration_project;
Set-Alias rcapitests cd_integration_project;
Set-Alias int cd_integration_project;
Set-Alias testproj cd_integration_project;

# git
Set-Alias main C:\Users\KarlPothast\source\workspaces\git\branches\mergeMainIntoMyFeatureBranch_pickList.ps1
Set-Alias cd_git_root cd_realcloud_sln_directory;
Set-Alias gitdir cd_realcloud_sln_directory;
Set-Alias untracked C:\Users\KarlPothast\source\workspaces\git\untrack-ignore\0-list_all_untracked.ps1
Set-Alias rcdir cd_realcloud_sln_directory;
Set-Alias refresh C:\Users\KarlPothast\source\workspaces\git\branches\mergeLatestReleaseIntoLocalBranches_pickList.ps1;
Set-Alias remotes get_remotes
Set-Alias simpr simulate_pullrequest_from_staged;
Set-Alias branches C:\Users\KarlPothast\source\workspaces\git\branches\1_getLocalBranches.ps1;
Set-Alias phantoms git-phantom-files;
Set-Alias stg GitStageLocalFiles;
Set-Alias pushed C:\Users\KarlPothast\source\workspaces\git\push\hasBranchBeenPushed.ps1;

# real cloud app
Set-Alias search searchRealCloudCode;
Set-Alias rcweb C:\Users\KarlPothast\source\workspaces\development\visual_studio\aspNetWebForms\startRealCloud.ps1
Set-Alias sandbox New-SandBox;

# real cloud node.js
Set-Alias automagic real_cloud_app_scenarios
Set-Alias actions real_cloud_app_scenarios
Set-Alias stop_actions kill_nodejs_puppeteer
#Set-Alias test open_rci_test_site

# asp.net
Set-Alias asp Start-IISExpressOnAvailablePort;
Set-Alias ocr start_ocr_webapp;
Set-Alias delbinobj dotnet_clear_all_bin_and_obj_folders;
Set-Alias delbin dotnet_clear_all_bin_and_obj_folders;
Set-Alias delbo dotnet_clear_all_bin_and_obj_folders;

# networking
Set-Alias ports get_ports_listening;
Set-Alias killport Stop-ProcessByPort;

# tests
Set-Alias testdata Invoke-ResetTestDataPS;
Set-Alias tests C:\Users\KarlPothast\Documents\WindowsPowerShell\Scripts\dotnet\tests\tests_main_menu.ps1;
Set-Alias t C:\Users\KarlPothast\Documents\WindowsPowerShell\Scripts\dotnet\tests\tests_main_menu.ps1;
Set-Alias apitests cd_apitests;

Set-Alias resetdb C:\Users\KarlPothast\source\repos\RealCloudPowershell\reset_db.ps1;
Set-Alias saveimg C:\Users\KarlPothast\source\workspaces\powershell\imaging\saveClipboardImgDataToFile.ps1;
Set-Alias colors C:\Users\KarlPothast\source\workspaces\powershell\utilities\terminal\Show-PowerShellColors.ps1;
Set-Alias png2ico C:\Users\KarlPothast\source\workspaces\powershell\imaging\convertPngToIco.ps1;
Set-Alias ros Analyze-CSharpFileWithRoslynator;
Set-Alias enc C:\Users\KarlPothast\source\workspaces\powershell\files_directories\getFileEncoding.ps1;
Set-Alias encdir C:\Users\KarlPothast\source\workspaces\powershell\files_directories\getFilesInDirectoryEncoding.ps1;
Set-Alias pgcfg edit_postgres_config;
Set-Alias gitready C:\Users\KarlPothast\source\workspaces\git\validate\git_ready.ps1;
Set-Alias utfdir C:\Users\KarlPothast\source\workspaces\powershell\files_directories\utfdir.ps1;
Set-Alias isutf C:\Users\KarlPothast\source\workspaces\powershell\files_directories\isutf.ps1;
Set-Alias rmbom RemoveBOMFromFileForReal;
Set-Alias rmbomall ConvertToUtf8RmBomRecursively;
Set-Alias cpath copypath_picklist;
Set-Alias rptbom Get-FileEncodingReport;
Set-Alias copyappsettings C:\Users\KarlPothast\source\repos\RealCloudAPITestingFiles_Examples\import_test_settings.bat;
Set-Alias cptestsettings C:\Users\KarlPothast\source\repos\RealCloudAPITestingFiles_Examples\import_test_settings.bat;
Set-Alias merge C:\Users\KarlPothast\source\workspaces\git\branches\mergeUpdatesFrom_refresh\mergeUpdates_FromAny_ToAny.ps1;
Set-Alias branchu C:\Users\KarlPothast\source\workspaces\git\branches\mergeUpdatesFrom_refresh\mergeUpdates_FromAny_ToAny.ps1;
Set-Alias dir2json Get-JsonEscapedPath;
Set-Alias json2dir Get-PathFromJsonEscaped;
Set-Alias appsettings Import_API_TestingFiles_ToCurrentDir;
Set-Alias tcfg Import_API_TestingFiles_ToCurrentDir;
Set-Alias testcls Run-TestClass;
Set-Alias vstcls Invoke-TestsByClass;

# docker
Set-Alias dl Docker_ListAllContainers;
Set-Alias d docker;
Set-Alias di Docker_ListAllImages;
Set-Alias dln Docker_ListAllContainers_w_Networking;
Set-Alias dstopall Docker_StopAllContainers;
Set-Alias ddelall Docker_DeleteAllContainers;
Set-Alias dstopdel Docker_StopAndDeleteAllContainers;















