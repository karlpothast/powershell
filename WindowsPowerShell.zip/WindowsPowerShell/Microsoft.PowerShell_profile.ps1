
            
$sourceFile = "$HOME\Documents\WindowsPowerShell\0_source_files.ps1";
Write-Host "source file is : $sourceFile";

if (Test-Path $sourceFile) {

  try {
      . $sourceFile
       Write-Host "Source WindowsPowershell Success"  
       #sleepMs 300;
       Clear-Host;
  }
  catch {    
    Write-Error("Error sourcing powershell aliases");
  }



} else {
   Write-Host "WindowsPowershell profile source file not found";
}
