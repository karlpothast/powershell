Clear-Host;

# $promptFile = "$HOME\\Documents\\WindowsPowerShell\\prompt.ps1"
# if (Test-Path $promptFile) {
#   . $promptFile
# } else {
#   Write-Host "Prompt file not found";
# }

$VerbosePreference = 'SilentlyContinue';

$functionsFile = "$HOME\\Documents\\WindowsPowerShell\\1_functions.ps1"
if (Test-Path $functionsFile) {
  . $functionsFile
} else {
  Write-Host "Functions file not found";
}

$functionsPath = "$HOME\\Documents\\WindowsPowerShell\\\functions"
Get-ChildItem -Path $functionsPath -Filter *.ps1 -Recurse | ForEach-Object {
    Write-Host "Importing $($_.FullName)..."
    . $_.FullName
}

$aliasFile = "$HOME\\Documents\\WindowsPowerShell\\2_aliases.ps1"
if (Test-Path $aliasFile) {
  . $aliasFile
} else {
  Write-Host "Aliases file not found";
}

$envFile = "$HOME\\Documents\\WindowsPowerShell\\3_env.ps1"
if (Test-Path $envFile) {
  . $envFile
} else {
  Write-Host "Env file not found";
}

$global:__SuppressStartupBanner = $true;

Clear-Host;
$msg="PS prompt, env, function & alias files sourced";

Write-Host  -NoNewline $msg " >";
Start-Sleep -Milliseconds 100;
Write-Host  -NoNewline " >";
Start-Sleep -Milliseconds 100;
Write-Host  -NoNewline " >";
Start-Sleep -Milliseconds 100;

Clear-Host;
$global:RedactPreviousLine = $True;
Clear-Host;
