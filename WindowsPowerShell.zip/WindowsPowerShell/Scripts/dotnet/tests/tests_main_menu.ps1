# Visual Studio Project directory - use dotnet test
if (Get-ChildItem *.csproj -ErrorAction SilentlyContinue) {
  "Visual Studio Project Directory";
  tests_menu_prj_directory;  
} else {
  Import_API_TestingFiles_ToCurrentDir;
  tests_menu_pub_directory;
}
