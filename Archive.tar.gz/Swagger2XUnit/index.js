
window.onload = function () {
  loadTestConfig();
};

function loadTestConfig() {
  divResults.style.visibility = "hidden";
  getEndpoint();
  clearCodeWindow();
  generateCode();  
}

function generateCode() {
  setTimeout(() => {
    genTests();
    
    if (scrollToBottomOnLoad) {
      //console.log('scroll to bottom');
      //let scrollTo = document.body.scrollHeight;

      //console.log('document.body.scrollHeight type: ', getTypeOf(document.body.scrollHeight));

      //scrollTo = scrollTo - 1000;
      //console.log('scrollTo :', scrollTo);
      //window.scrollTo(0, scrollTo);

      // Scroll to near the bottom, leaving 400px above the end
      window.scrollTo({
        top: document.body.scrollHeight,
        behavior: "smooth"  
      });

    }
    //determineTestTemplate();
  }, 100);  
  setTimeout(() => {
      applyCodeHighlighting()
    }, 200);  
}

function refreshCodeWindow() {
  clearCodeWindow();
  generateCode();
}

btnGen.addEventListener('click', () => {
  loadTestConfig();
});

function genTests() {
  let testTemplate = determineTestTemplate();  
  let cSharpXunitTestClass = "";

  switch (testTemplate) {
    case "total":
      cSharpXunitTestClass = generateTotalTests();      
      code1.innerText = cSharpXunitTestClass;
      break;
    default:

      cSharpXunitTestClass = genJsonArrayTests();          
      code1.innerText = cSharpXunitTestClass.cSharpClassString;      
      code2.innerText = cSharpXunitTestClass.constantVarsString;      

      // cSharpXunitTestClass = generateTotalTests();   
      //  code1.innerText = cSharpXunitTestClass;   

      //constantVarsString
      break;
  }
}

function determineTestTemplate() {  
  const table = document.getElementById("tblParams");
  if (endpoint.toLowerCase().includes("total")) {
    return "total"
  }
}

btnClear.addEventListener('click', () => {
  //pre1.innerText = "";
  clearCodeWindow();
});

function clearCodeWindow(){
  code1.innerText = "";
  code2.innerText = "";
}

btnCopy.addEventListener('click', () => {
  
  let text = pre1.innerText;
  if (text.trim() != "") {
    navigator.clipboard.writeText(text)
      .then(() => {
        spanMsg.innerText = "Copied to clipboard";
        $('#spanMsg').fadeIn(500)        // Fade in over 400ms
        .delay(1200)        // Stay visible for 2 seconds
        .fadeOut(500);      // Fade out over 400ms

        //console.log('✅ Text copied to clipboard:', text);
      })
      .catch(err => {
        //console.error('❌ Failed to copy text:', err);    
      });
  }
});

selectEndpoint.addEventListener("change", function () {
  setEndpointCookie();
  getEndpoint();
  clearCodeWindow();
});

txtApiDefinition.addEventListener("change", function () {  
  if (txtApiDefinition.value) {
    apiDefinitionFilePath = txtApiDefinition.value;
    setEndpointCookie();
  }
});

function getEndpoint() {  
  parseCookie(); 
  getApiParams();
}

function parseCookie() {  
  let cookieValue = getCookie("endpoint");

  if (cookieValue) {
    let cookieValueArray = cookieValue.split(";");

    let selectedEndpointCookieString = cookieValueArray[0];
    let selectedEndpointCookieStringArr = selectedEndpointCookieString.split(":");
    let selectedEndpointCookieVal = selectedEndpointCookieStringArr[1];  
    selectedEndpointVal = selectedEndpointCookieVal;
    
    let endpointCookieString = cookieValueArray[1];
    let endpointCookieStringArr = endpointCookieString.split(":");
    let endpointCookieVal = endpointCookieStringArr[1];

    let apiDefinitionFilePathString = cookieValueArray[1];
    let apiDefinitionFilePathStringArr = splitAtFirstChar(apiDefinitionFilePathString,':');
    apiDefinitionFilePath = apiDefinitionFilePathStringArr[1];

    txtApiDefinition.value = apiDefinitionFilePath;
    
    if (endpointCookieVal) {
      let endpointStringArray  = endpointCookieVal.split("/");
      let ctr=0;
      for (let i = 0; i < endpointStringArray.length; i++) {
        let item = endpointStringArray[i];
        //console.log('endpoint piece : ' + item);
        if (ctr==0) {
          //blank (before first "/"")
        }
        if (ctr==1) {
          //blank (before first "/"")
          //txtEndpoint.value = item;
          //txtEntity.value = item.toUpperCase().replace("TOTAL","").replace("AUDIT","").toLowerCase();
          //console.log('');
        }
        if (item.includes("{") && item.includes("}")) {
          txtInputVarName.value = caps(item.replace("{","").replace("}",""));
          txtInvalidInputVarName.value = "Invalid" + caps(item.replace("{","").replace("}",""));
        }
        ctr+=1;
      }
    }


  }
}

function getApiParams() {

    if (apiDefinitionFilePath) {
      
      (async () => {
        try {
          const apiFileContent = await getFileContent(apiDefinitionFilePath);
          
          let jsonObjApiFileContent = JSON.parse(apiFileContent);
        
          buildSelect(jsonObjApiFileContent);
        
          if (apiFileContent) {
            const jsonFormatted = JSON.stringify(jsonObjApiFileContent, null, 2); // 2 = indentation spaces
            preApiDefinition.innerText = jsonFormatted;

            (async () => {
            try {
              //selectEndpoint
              let selectedEndpoint = selectEndpoint.options[selectEndpoint.selectedIndex]?.text; 
              //console.log('selectedEndpoint', selectedEndpoint);
              
              let endpointUriArray  = selectedEndpoint.split("/");
              //console.log('endpointUriArray: ', endpointUriArray);
              if (endpointUriArray.length > 1) {
                endpoint = endpointUriArray[1];
                txtEntity.value = endpoint;
              }
              //let path = pathMethodArray[0].trim();
                            
              if(selectedEndpoint != "0") {
                const selectEndpointText = selectEndpoint.options[selectEndpoint.selectedIndex]?.text; 
                //console.log('selectEndpointText: '+ selectEndpointText);
                //apiFileParams = await getEndpointParameters("swagger.json", selectEndpointText, "request");

                console.log("txtApiDefinition", txtApiDefinition.value);
                let path = txtApiDefinition.value;
                const apiDefFileName = path.split(/[/\\]/).pop();

                let swaggerFileName = apiDefFileName;
                console.log('swaggerFileName :', swaggerFileName);

                apiFileParams = await getEndpointParameters(apiDefFileName, selectEndpointText, "request");
                
                //console.log('apiFileParams', apiFileParams);
              }
              else
              {
                console.log('Choose endpoint');
                //return;
              }
              
              //console.log('apiFileParams before create tbl ', apiFileParams);

              const tblParams  = document.createElement("table");
              tblParams.innerHTML = "";
              tblParams.id = "tblParams";
              tblParams.className = "tbl-params";
              tblParams.style.borderCollapse = "collapse";
              tblParams.style.width = "100%";
              let thead = document.createElement("thead");
              let trHead = document.createElement("tr");

              //console.log('apiFileParams before addParamsTableHeader ', apiFileParams);

              addParamsTableHeader(trHead, apiFileParams);
              thead.appendChild(trHead);
              let tbody = document.createElement("tbody");

              addParamsTableRows(tbody, apiFileParams);
              tblParams.appendChild(thead);
              tblParams.appendChild(tbody);
              divParams.innerHTML = "";
              //console.log('appending tblParams: ', tblParams);
              divParams.appendChild(tblParams);

            } catch (err) {
              console.error("Error:", err);
            }
          })();

          } else {
            console.log("No content returned");
            txtApiDefinition.style.color = "gray";
            btnApiDefinitionFile.enabled = false;
          }
        } catch (err) {
          console.error("Error:", err);
          txtApiDefinition.style.color = "gray";
          btnApiDefinitionFile.enabled = false;
        }
      })();
    }

  
}

function addParamsTableHeader(trHead, apiFileParams) {
  
  let th1 = document.createElement("th");
  th1.textContent = "Name";
  trHead.appendChild(th1);

  let th2 = document.createElement("th");
  th2.textContent = "Type";
  trHead.appendChild(th2);

  let th3 = document.createElement("th");
  th3.textContent = "Format";
  trHead.appendChild(th3);

  let th4 = document.createElement("th");
  th4.textContent = "Required";
  trHead.appendChild(th4);

  let th5 = document.createElement("th");
  th5.textContent = "In";
  trHead.appendChild(th5);

  let th6 = document.createElement("th");
  th6.textContent = "Description";
  trHead.appendChild(th6);
}

function addParamsTableRows(tbody, apiFileParams) {
    let paramName = paramDescription = paramRequired = paramIn = paramSchema = paramType = paramFormat = "";

    if (apiFileParams) {

      apiFileParams.forEach(param => {
        let tr = document.createElement("tr");
        paramName = paramDescription = paramRequired = paramIn = paramSchema = paramType = paramFormat = "";
        
        const td1 = document.createElement("td");
        paramName = param.name;
        td1.textContent = paramName;
      
        const td6 = document.createElement("td");
        paramDescription = param.description;
        td6.textContent = paramDescription;
      
        const td4 = document.createElement("td");
        paramRequired = param.required;
        td4.textContent = paramRequired;

        const td5 = document.createElement("td");
        paramIn = param.in
        td5.textContent = paramIn;

        const td2 = document.createElement("td");
        const td3 = document.createElement("td");
        paramSchema = param.schema;
        if (paramSchema) {
            paramType = paramSchema.type;
            td2.textContent = paramType;

            paramFormat = paramSchema.format;
            td3.textContent = paramFormat;
        }
        tr.appendChild(td1);
        tr.appendChild(td2);
        tr.appendChild(td3);
        tr.appendChild(td4);
        tr.appendChild(td5);
        tr.appendChild(td6);

        tbody.appendChild(tr);
    
      })

    }
    else
    {
      console.log('no apiFileParams');
    }
 

}

function caps(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function lcase(str) {
  if (!str) return '';
  return str.toLowerCase();
}

function lowerFirst(str) {
  if (!str) return '';
  return str.charAt(0).toLowerCase() + str.slice(1);
}

function plural(str) {
  let returnVal;
  if (!str) return '';

  returnVal = str + 's';

  return returnVal;
}

function setEndpointCookie() {

  let selectedEndpoint = selectEndpoint.value;
  let pathMethodArray  = selectedEndpoint.split("-");
  let path = "";
  let method = "";

  if (pathMethodArray.length > 1) {
    path = pathMethodArray[0].trim();

    method = pathMethodArray[1].trim();
  }
  else {
    console.log('path-method array blank');
  }      
  
  //let httpMethod = selectHttpMethods.value;  
  let httpMethod = "";
  //let apiUri = txtEndpointUri.value;
  let definitionFilePath = txtApiDefinition.value;
  let cookieValue = "selectedEndpoint:"+selectedEndpoint+";definitionFilePath:"+definitionFilePath;
      
  if (httpMethod != "0") {
    console.log('actually set cookie');
    setCookie("endpoint", cookieValue);
  }
  else if (httpMethod == "0") { 
    console.log('delete cookie');
    deleteCookie("endpoint");
  }




}

function splitAtFirstChar(str, char) {
  const index = str.indexOf(char);
  
  if (index === -1) {
    // character not found → return whole string as first part, empty second part
    return [str, ""];
  }

  return [str.slice(0, index), str.slice(index + 1)];
}

async function getFileContent(filePath) {
  try {
    const response = await fetch("http://localhost:8078/Windows/GetFileContent", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ filePath })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    //const data = await response.json(); // assuming your API returns JSON
    const data = await response.text();
    return data;
  } catch (err) {
    console.error("Error fetching file content:", err);
  }
}

btnApiDefinitionFile.addEventListener("click", (e) => {
  //console.log('make button visible');
  //divApiDefinition.style.visibility = "visible";

   if (divApiDefinition.style.visibility === "hidden" || divApiDefinition.style.visibility === "") {
      //console.log('hidden - make visible');
      divApiDefinition.style.visibility = "visible";
   } else {
      //console.log('visible - hide');
      divApiDefinition.style.visibility = "hidden";
   }
});

document.addEventListener("click", (event) => {
    //console.log("Page was clicked!", event);

    // Example: log where it was clicked
    //console.log("Clicked element:", event.target);
    let clickedElement = event.target;
    //console.log("Coordinates:", event.clientX, event.clientY);
});

async function getEndpointParameters(specUrl, pathMethod, kind = "request") {

  let pathMethodArray  = pathMethod.split("-");
  //console.log('pathMethodArray', pathMethodArray);
  let path = pathMethodArray[0].trim();
  let method = pathMethodArray[1].trim();
  
  const spec = await fetch(specUrl).then(r => r.json());
  const op = spec.paths?.[path]?.[method.toLowerCase()];

  if (!op) throw new Error("Path/method not found");

  if (kind === "request") {
    if (op.requestBody) {
      // POST/PUT/PATCH
      return op.requestBody.content?.["application/json"]?.schema;
    } else if (op.parameters) {
      // GET, DELETE, etc → use parameters instead of body
      return op.parameters;
    }
  } else {
    // responses
    return op.responses?.["200"]?.content?.["application/json"]?.schema;
  }
}

function getSuccessCaseConstantName(paramName, inlineParam) {

  let returnVarName = "";
  switch (paramName.toLowerCase()) {
    case "organizationid":
      returnVarName = "Constants.InternalOrganizationId";
      break;
    case "patientid":
      returnVarName = "Constants.InternalPatientId";
      break;
    case "onlineuserid":     
      returnVarName = "Constants.InternalOnlineUserId";
      break;
    case "locationid":     
      returnVarName = "Constants.InternalLocationId";
      break;
    case "providerid":     
      returnVarName = "Constants.InternalProviderId";
      break;
    case "ishidden":     
      returnVarName = "Constants.BooleanFalseString";
      break;   
    case "isdeleted":     
      returnVarName = "Constants.BooleanFalseString";
      break;    
    case "examid":     
      returnVarName = "Constants.ExamId";
      break;
    case "minimumdate":     
      returnVarName = `Uri.EscapeDataString(Constants.${caps(endpoint)}MinimumDate)`;
      break;
    case "maximumdate":     
      returnVarName = `Uri.EscapeDataString(Constants.${caps(endpoint)}MaximumDate)`;
      break;  
    case "justification":     
      returnVarName = "Constants.NullString";
      break;
    case "grade":     
      returnVarName = "Constants.NullString";
      break;
    case "pagesize":     
      returnVarName = "Constants.PageSize";
      break;        
    case "pagenumber":     
      returnVarName = "Constants.PageNumber";
      break;   
    case "auditaction":     
      returnVarName = `Constants.${caps(endpoint.replace("Audit",""))}AuditAction`;
      break;      
    default:
      returnVarName = `Constants.${caps(paramName)}`;
      break;
  }

  if (inlineParam) {
    returnVarName = returnVarName.replace("Constants.","");
    returnVarName = returnVarName.replace("Uri.EscapeDataString(","").replace(")","");

  }

  return returnVarName;
}

function getSuccessCaseConstantName2(paramName, inlineParam) {
  
  let returnVarName = "";
  switch (paramName.toLowerCase()) {
    case "organizationid":
      returnVarName = "organizationId";
      break;
    case "patientid":
      returnVarName = "patientId";
      break;
    case "providerid":
      returnVarName = "providerId";
      break;
    case "onlineuserid":     
      returnVarName = "onlineUserId";
      break;
    case "locationid":     
      returnVarName = "locationId";
      break;
    case "ishidden":     
      returnVarName = "isHidden";
      break;   
    case "isdeleted":     
      returnVarName = "isDeleted";
      break;         
    case "examid":     
      returnVarName = "examId";
      break;
    case "minimumdate":     
      returnVarName = "minimumDate";
      break;
    case "maximumdate":     
      returnVarName = "maximumDate";
      break;
    case "justification":     
      returnVarName = "justification";
      break;                          
    case "pagesize":     
      returnVarName = "pagesize";
      break;        
    case "pagenumber":     
      returnVarName = "pagesize";
      break;                
    default:
      returnVarName = "  <!ConstantNotDefined>  ";
      break;
  }
  return returnVarName;
}

function getFailCaseConstantName(paramName, inlineParam) {

  let returnVarName = "";
  switch (paramName.toLowerCase()) {
    case "organizationid":
      returnVarName = "Constants.InvalidInternalOrganizationId";
      break;
    case "patientid":     
      returnVarName = "Constants.InvalidInternalPatientId";
      break;
    case "providerid":     
      returnVarName = "Constants.InvalidInternalProviderId";
      break;
    case "onlineuserid":     
      returnVarName = "Constants.InvalidInternalOnlineUserId";
      break;
    case "locationid":     
      returnVarName = "Constants.InvalidInternalLocationId";
      break;          
    case "ishidden":     
      returnVarName = "Constants.InvalidBooleanString";
      break;   
    case "isdeleted":     
      returnVarName = "Constants.InvalidBooleanString";
      break;   
    case "examid":     
      returnVarName = "Constants.InvalidExamId";
      break;
    case "minimumdate":     
      returnVarName = "Constants.InvalidDateString";
      break;
    case "maximumdate":     
      returnVarName = "Constants.InvalidDateString";
      break;             
    case "justification":     
      returnVarName = "Constants.NonStringType";
      break;
    case "pagesize":     
      returnVarName = "Constants.InvalidNumericString";
      break;      
    case "pagenumber":     
      returnVarName = "Constants.InvalidNumericString";
      break;        
    default:
      returnVarName = "  <!ConstantNotDefined>  ";
      break;
  }
  
  if (inlineParam) {
    returnVarName = returnVarName.replace("Constants.","");
  }
  
  return returnVarName;
}

function parseBool(str) {
  return String(str).toLowerCase() === "true";
}

function getJsAssignWrapStart(apiParamType) {

  let retVal = "";

  switch (apiParamType) {
    case "string":
      cSharpType = "string";
      retVal = "GetConst(";
      break;
    case "integer":
      cSharpType = "string";
      retVal = "GetConst(";
      break;          
    case "boolean":
      cSharpType = "string";
      retVal = "GetConst(";
      break;              
    case "date":
      cSharpType = "string";
      retVal = "Uri.EscapeDataString(";
      break;           
    default:
    break;
  }
   
  return retVal;
}

function getJsAssignWrapEnd(apiParamType) {

  let retVal = "";

  switch (apiParamType) {
    case "string":
      cSharpType = "string";
      retVal = ")";
      break;
    case "integer":
      cSharpType = "string";
      retVal = ")";
      break;          
    case "boolean":
      cSharpType = "string";
      retVal = ")";
      break;              
    case "date":
      cSharpType = "string";
      retVal = ")";
      break;           
    default:
    break;
  }
   
  return retVal;
}

function spaces(numOfSpaces) {
  return " ".repeat(numOfSpaces);
}

function buildSelect(openApiJson) {
  
  const paths = Object.keys(openApiJson.paths || {}).sort((a, b) => a.localeCompare(b));

  let ctr = 1;
  for (const p of paths) {
    // loop through operations (get, post, put, etc.)
    const operations = Object.keys(openApiJson.paths[p]);
    
    for (const op of operations) {
      const opt = document.createElement('option');
      //opt.value = `${p} - ${op.toUpperCase()}`;
      opt.value = `${ctr}`;
      opt.textContent = `${p} - ${op.toUpperCase()}`;
      selectEndpoint.appendChild(opt);
      ctr+=1;
    }
  }

  if (selectedEndpointVal) {
    selectEndpoint.value = selectedEndpointVal;
  }

}

function getInvalidInlineParamHttpsErrorCode(paramName) {

  let retVal = "";
  
  switch (paramName) {
    // case "organizationId":
    //   cSharpType = "string";
    //   retVal = "500";
    //   break;
    // case "locationId":
    //   cSharpType = "string";
    //   retVal = ")";
    //   break;          
    // case "onlineUserId":
    //   cSharpType = "string";
    //   retVal = ")";
    //   break;    
    case "boolean":  //any boolean intentional fail
      cSharpType = "string";
      retVal = "400";
      break;    
    case "invalidboolean":  //any boolean intentional fail
      cSharpType = "string";
      retVal = "400";
      break;                     
    case "isHidden":  //any boolean intentional fail
      cSharpType = "string";
      retVal = "400";
      break;   
    case "isDeleted":  //any boolean intentional fail
      cSharpType = "string";
      retVal = "400";
      break;          
    default:
      retVal = "400";
    break;
  }
   
  return retVal;
  
}

// add Constants
// CustomProcedureTotalRequiredParamOnlyTotal

function logBlack(msg) {
  console.log('%c' + msg, 'color:black; font-weight:bold');
}

function logBlue(msg) {
  console.log('%c' + msg, 'color:blue; font-weight:bold');
}

function rmLastChar(str, lastChar) {
  let returnVal = "";
  if (str.endsWith(lastChar)) {
    returnVal = str.slice(0, -1);
  }
  return returnVal;
}

function getTypeOf(variable) {  
  return typeof variable;  
}