﻿
function genJsonArrayTests() {

  let requiredPathVars = "";
  let required = false;
  let requiredCtr = 0;
  let paramName = "";
  let paramIn = "";
  let paramType = "";
  let successCaseReqPathVarsString = "";
  let successCaseQueryStringVarsString = "";
  let successCaseReqPathVarsString2 = "";
  let successCaseQueryStringVarsString2 = "";
  let paramNames = "";
  let firstQueryStringParamSet = false;
  let reqFailedCaseString = "";
  let failCaseReqPathVarsString = "";
  let failCaseCtr = 0;
  let inlineDataStartCaseNum = 0;
  let inlineDataEndCaseNum = 0;
  let queryStringParamCount = 0;
  let theoryInlineDataString = "";
  let theoryInlineDataDefaultLineString = "";
  let theoryAllParams = "";
  let theoryReqParams = "";
  let theoryOptionalParams = "";

  let allParams = "";
  let requiredParams = "";
  let optionalQueryStringParams = "";

  let theoryReqParamgArr;
  let theoryReqParamString = "";
  let inlineParm1 = "";
  let inlineParm2 = "";
  let inlineParm3 = "";
  let inlineParm4 = "";
  let inlineParm5 = "";
  let inlineParm6 = "";
  let inlineParm7 = "";
  let inlineParm8 = "";
  let inlineParm9 = "";
  let inlineParm10 = "";
  let inlineParm11 = "";
  let inlineParm12 = "";
  let inlineParm13 = "";
  let inlineParm14 = "";
  let inlineParm15 = "";
  let theoryReqParamsArray;
  let theoryOptParamsArray;
  let paramNameValueArr = [];
  let paramNameValueObj;
  let inner = "";
  let params = "";
  let index = "";
  let jsonArrayName = "";
  
  table = document.getElementById("tblParams");
  if (table) {

    console.log('%c' + "***** START of param loop *****", 'color:blue; font-weight:bold');
    
    for (let i = 0; i < table.rows.length; i++) {
      if (i == 0) {
        continue;
      }
      else
      {
        const row = table.rows[i];
        required = false;
        //#region forloop
        for (let j = 0; j < row.cells.length; j++) {
          const cell = row.cells[j];      
          switch (j) {
            case 0:
              paramName = cell.textContent;          
              break;
            case 1:
              paramType = cell.textContent;    
              break;
            case 2:
              
              break;
            case 3:
              required = parseBool(cell.textContent);          
              break;
            case 4:
              paramIn = cell.textContent;
              break;
            case 5:
              //description
              break;
            default:
              break;
            }

            paramNameValueObj = { paramName: paramName, paramType: paramType };
          }  
          paramNameValueArr.push(paramNameValueObj);
      }

      if (paramName != "") {
        allParams += paramName + ";";
        theoryAllParams += paramName + ";";
      }
      else {
        continue;
      }
      

      if (required) {
        requiredCtr+=1;      
        if (paramName != "") {
          paramNames += paramName + ",";
        }
        if (paramName != "") {
          theoryReqParams += paramName + ";";
          requiredParams += paramName + ";";
        }
        
        if (paramIn == "path") {     
          requiredPathVars += "{" + paramName + "}";
          successCaseReqPathVarsString += "/{" + getSuccessCaseConstantName(paramName) + "}";          
          successCaseReqPathVarsString2 += "/{" + getSuccessCaseConstantName2(paramName) + "}";
          failCaseReqPathVarsString += "/{" + getFailCaseConstantName(paramName) + "}";
        }
        
        // [Fact] // Success Case 1 : Required param(s) (${paramNames}) return Ok                       
        // public async Task Get${caps(endpoint)}_ValidRequiredParams_ReturnsSuccessAndExpectedData()

        failCaseCtr+=1;

        reqFailedCaseString += 
      `[Fact] // Error Case ${failCaseCtr}: Invalid ${caps(paramName)} returns 400
        public async Task ${caps(endpoint)}_Invalid${caps(paramName)}_Returns400()
        {
            var url = $"/{_endpoint}${failCaseReqPathVarsString}";
            var response = await _client.GetAsync(url);
            Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        }`;

        failCaseCtr+=1;

        reqFailedCaseString += `\n
        [Fact] // Error Case ${failCaseCtr}: Empty ${caps(paramName)} returns 404
        public async Task ${caps(endpoint)}_Empty${caps(paramName)}_Returns404()
        {
            var url = $"/{_endpoint}/{Constants.EmptyString}";
            var response = await _client.GetAsync(url);
            Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        }`;

        inlineDataStartCaseNum = (failCaseCtr+1);
      }
      else {
        if (paramName != "") { 
          theoryOptionalParams += paramName + ";";
          optionalQueryStringParams += paramName + ";";
        }        
      }

      if (paramIn == "query") {
     
        queryStringParamCount+=1;

        if (firstQueryStringParamSet == false) {
          successCaseQueryStringVarsString += `  + $"?`;
          successCaseQueryStringVarsString2 += `  + $"?`;
          firstQueryStringParamSet=true;
        }
        else {
          successCaseQueryStringVarsString += `\n ${spaces(12)} + $"&`;
          successCaseQueryStringVarsString2 += `\n ${spaces(12)} + $"&`;
        }

        successCaseQueryStringVarsString += `${paramName}=`;
        successCaseQueryStringVarsString2 += `${paramName}=`;

        switch (paramType) {
          case "integer":
            successCaseQueryStringVarsString += `{${getSuccessCaseConstantName(paramName, false)}}"`;
            successCaseQueryStringVarsString2 += `{${paramName}}"`;
            break;
          case "date":
            //successCaseQueryStringVarsString += `"{Constants.${caps(paramName)}}"`;
            successCaseQueryStringVarsString += `{${getSuccessCaseConstantName(paramName, false)}}"`;
            successCaseQueryStringVarsString2 += `{${paramName}}"`;
            break;     
          case "string":
            //successCaseQueryStringVarsString += `"{Constants.${caps(paramName)}}"`;
            successCaseQueryStringVarsString += `{${getSuccessCaseConstantName(paramName, false)}}"`;
            successCaseQueryStringVarsString2 += `{${paramName}}"`;
            break;                    
          case "boolean":
            //successCaseQueryStringVarsString += `"{Constants.${caps(paramName)}}"`;
            successCaseQueryStringVarsString += `{${getSuccessCaseConstantName(paramName, false)}}"`;
            successCaseQueryStringVarsString2 += `{${paramName}}"`;
            break;        
          default:
            break;
        }
        //queryStringParamCount      
        
      } 
      
    }

    console.log('%c' + "***** END of param loop *****", 'color:blue; font-weight:bold');

  }

        let invalidInlineParamName = "";
        let invalidInlineParamName2 = "";
        let str = "";
        let invalidParamMatchText = "";

        let finalInvalidParam = "";
        theoryInlineDataString="";                        
        
        //---------------------------------------------before inline param loop-----------------------------------------------
        theoryAllParamsArray  = theoryAllParams.split(";").filter(Boolean);      
        for (let p = 0; p < theoryAllParamsArray.length; p++) {

          theoryInlineDataDefaultLineString += "[InlineData(";


          let currentInvalidParam = "";
          let param = theoryAllParamsArray[p];
          let paramNumber = p + 1;
          if (param != "") {
          }      
          //----------------------------------        
          let innerParamLoopCtr = 0;
          theoryReqParamsArray = theoryReqParams.split(";").filter(Boolean);          
          
          for (let r = 0; r < theoryReqParamsArray.length; r++) {
            innerParamLoopCtr+=1;
            let reqParam = theoryReqParamsArray[r];
            if (reqParam != "") {
              if (reqParam == param) {
                currentInvalidParam = reqParam;                
                theoryInlineDataDefaultLineString += '"' + getFailCaseConstantName(currentInvalidParam, true) + '"';        
                if (innerParamLoopCtr < theoryAllParamsArray.length) {
                  theoryInlineDataDefaultLineString += ", ";
                }
              }
              else
              {
                currentInvalidParam = reqParam;
                theoryInlineDataDefaultLineString += '"' + getSuccessCaseConstantName(currentInvalidParam, true) + '"';
                if (innerParamLoopCtr < theoryAllParamsArray.length) {
                  theoryInlineDataDefaultLineString += ", ";
                }                                     
                
              }
            }            
          }

          theoryOptParamsArray  = theoryOptionalParams.split(";").filter(Boolean);
          for (let o = 0; o < theoryOptParamsArray.length; o++) {
            innerParamLoopCtr+=1;
            
            let optParam = theoryOptParamsArray[o];
            if (optParam != "") {
              if (optParam == param) {
              currentInvalidParam = optParam;
                theoryInlineDataDefaultLineString += '"' + getFailCaseConstantName(currentInvalidParam, true) + '"';
                if (innerParamLoopCtr < theoryAllParamsArray.length) {
                  theoryInlineDataDefaultLineString += ", ";
                }                
              }
              else {
                currentInvalidParam = optParam;
                theoryInlineDataDefaultLineString += '"' +  getSuccessCaseConstantName(currentInvalidParam, true) + '"';
                if (innerParamLoopCtr < theoryAllParamsArray.length) {
                  theoryInlineDataDefaultLineString += ", ";
                }
              }
            }
          }
          
          str = theoryInlineDataDefaultLineString;
          const invalidParamMatchText = str.match(/invalid([^"]*)/);

          if (invalidParamMatchText) {
            invalidInlineParamName = invalidParamMatchText[1];

          }
          else {

          }

          //invalidInlineParamName2
          if (invalidInlineParamName == "") {
            //look for other params with invalid like text
            // false
            
            // 1. Extract everything inside the parentheses
            let inner = null;
            if (str) {
              const match = str.match(/\((.*)\)/);
              if (match && match[1]) {
                inner = match[1];
                // 2. Split by comma, trim, and strip quotes
                params = inner.split(",").map(p => p.trim().replace(/^"|"$/g, ""));

                // 3. Find index of the one containing "false" (case-insensitive)
                index = params.findIndex(p => p.toLowerCase().includes("false"));


                invalidInlineParamName2 = theoryAllParamsArray[0];
              }
            }
          }          

          //add error code and which param is 

          let finalInvalidParamName = "";
          if (invalidInlineParamName.trim() != "") {
            finalInvalidParamName = invalidInlineParamName;
          }
          else
          {
            finalInvalidParamName = invalidInlineParamName2;
          }

          let finalErrorCode = "404";
          theoryInlineDataDefaultLineString += ", " + getInvalidInlineParamHttpsErrorCode(param) + ", \"" + caps(param) + "\"";         

          theoryInlineDataDefaultLineString += ")]\n        ";
    
          theoryInlineDataString += theoryInlineDataDefaultLineString;
          theoryInlineDataDefaultLineString = "";
                    
        }
        //---------------------------------------------after inline param for loop-----------------------------------------------        
        
  inlineDataEndCaseNum = inlineDataStartCaseNum + queryStringParamCount;



         
let cSharpQueryStringCode = getCSharpQueryStringParamCode(optionalQueryStringParams);
let cSharpJSONFirstRecordValidate = buildCSharpJSONRecordAssertion(optionalQueryStringParams);

let theoryCode = getTheoryString(inlineDataStartCaseNum, inlineDataEndCaseNum, paramNameValueArr, successCaseReqPathVarsString2, successCaseQueryStringVarsString2, theoryInlineDataString);

paramNames = paramNames.slice(0, -1); 
jsonArrayName = lowerFirst(plural(endpoint));
  
let cSharpClassString = 
`using RealCloud.API.Models.v2;
using System.Net;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace RealCloud.API.IntegrationTests
{
    public class ${endpoint}Tests : TestBase
    {
        private const string _endpoint = "${caps(endpoint)}";
        public ${caps(endpoint)}Tests(ApiFactory factory, ITestOutputHelper output)
            : base(factory, output) { }

        private readonly JsonSerializerOptions jsonOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow
        };
        
        #region "Endpoint : GET /${caps(endpoint)}/${requiredPathVars}"
      
        [Fact] // Success Case 1 : Required param(s) only return successfully
        public async Task Get${caps(endpoint)}_ValidRequiredParams_ReturnsSuccessAndExpectedArray()
        {
            var url = $"/{_endpoint}${successCaseReqPathVarsString}";
            var response = await _client.GetAsync(url);
            response.EnsureSuccessStatusCode();
            var jsonString = await response.Content.ReadAsStringAsync();

            try
            {
                var ${jsonArrayName} = JsonSerializer.Deserialize<List<${caps(endpoint)}>>(jsonString, jsonOptions);
                Assert.True(true, "Valid ${caps(endpoint)} response returned");
                if (${jsonArrayName} != null && ${(jsonArrayName)}.Count > 0)
                {
                    AssertRecordMatchesExpectedData(${jsonArrayName}[0]);
                }
            }
            catch (JsonException jsonEx)
            {
                Assert.Fail($"Invalid ${caps(endpoint)} response returned");
                _factory.Log("JsonException: " + jsonEx.Message);
            }
        }

        [Fact] // Success Case 2: All parameters passed with all valid values returns ok and valid json array
        public async Task Get${caps(endpoint)}_AllValidParamsPassed_ReturnsSuccessAndExpectedData()
        {
            var url = $"/{_endpoint}${successCaseReqPathVarsString}"
            ${cSharpQueryStringCode};
            
            var response = await _client.GetAsync(url);
            response.EnsureSuccessStatusCode();
            var jsonString = await response.Content.ReadAsStringAsync();

            try
            {
                var ${jsonArrayName} = JsonSerializer.Deserialize<List<${caps(endpoint)}>>(jsonString, jsonOptions);
                Assert.True(true, "Valid ${endpoint} response returned");
                if (${jsonArrayName} != null && ${jsonArrayName}.Count > 0)
                {
                    AssertRecordMatchesExpectedData(${jsonArrayName}[0]);
                }
            }
            catch (JsonException jsonEx)
            {
                Assert.Fail($"Invalid PatientAudit response returned");
                _factory.Log("JsonException: " + jsonEx.Message);
            }
        }

        ${reqFailedCaseString}

    ${theoryCode}

        #endregion

        private static void AssertRecordMatchesExpectedData(${caps(endpoint)} ${lowerFirst(endpoint)}Record)
        {${cSharpJSONFirstRecordValidate}
        }
    }
}
`;
         
      
  const returnObj = { cSharpClassString, constantVarsString };
  return returnObj;
}


function getCSharpQueryStringParamCode(queryStringParams) {  
  queryStringParams = rmLastChar(queryStringParams,";");
    
  let returnVal = "";
  let queryStringParamsArray  = queryStringParams.split(";");

  let strCode = "";
  for (let i = 0; i < queryStringParamsArray.length; i++) {
    let item = queryStringParamsArray[i];
    //console.log(' item: ' + item);
    if (i == 0) {
      strCode += "  + $\"?"+ item + "=";      
    }
    else
    {
      strCode += "\n" + spaces(14) + "+ $\"&"+ item + "=";
    }    
    strCode += "{" + getSuccessCaseConstantName(item, false) + "}\"";
  }

  returnVal = strCode;
  return returnVal;
}

function buildCSharpJSONRecordAssertion(queryStringParams) {

  queryStringParams = rmLastChar(queryStringParams,";");
  //constantVarsString = "";

  let returnVal = "";
  let queryStringParamsArray  = queryStringParams.split(";");

  let strCode = "";
  constantVarsString = "";
  for (let i = 0; i < queryStringParamsArray.length; i++) {
    let item = queryStringParamsArray[i];    

    strCode += "\n" + spaces(12) + `Assert.Equal(Constants.${caps(endpoint)}_FirstRecord_${caps(item)}, ${endpoint}.${caps(item)});`;
    constantVarsString += "\n" + spaces(8) + `public const string ${caps(endpoint)}_FirstRecord_${caps(item)} = "";`;
  }

  returnVal = strCode;
  return returnVal;
}
    
function getTheoryString(inlineDataStartCaseNum, inlineDataEndCaseNum, paramNameValueArr, successCaseReqPathVarsString2, successCaseQueryStringVarsString2, theoryInlineDataString) {

  let theoryString = `// [Theory] treats each [InlineData] attribute like an individual test [Fact]
        [Theory] //Error Cases ${inlineDataStartCaseNum}-${inlineDataEndCaseNum}: All valid parameters except one for each [InlineData] parameter set
        ${theoryInlineDataString}
  `;
  theoryString = theoryString.trim();
  if (theoryString.endsWith(",")) {
    theoryString = theoryString.slice(0, -1);
  }
  theoryString = spaces(4) + theoryString;         

  let theoryCallParamsIn = "";
  let cSharpType = "";
  let theoryJsVarsAssign = "";

  for (let r = 0; r < theoryAllParamsArray.length; r++) {        
    let rp = theoryAllParamsArray[r];
    //console.log('');
    for (let pn = 0; pn < paramNameValueArr.length; pn++) {       
      let pv = paramNameValueArr[pn];          
      
      let apiParamType = pv.paramType;          

      switch (apiParamType) {
        case "string":
          cSharpType = "string";
          break;
        case "integer":
          cSharpType = "string";
          break;          
        case "boolean":
          cSharpType = "string";
          break;              
        default:
          break;
      }                  
    }         
      
      theoryCallParamsIn += cSharpType + " " + rp + "Key, ";
      if (r == 1 || r == 7) {
        theoryCallParamsIn = theoryCallParamsIn.trimEnd();
        theoryCallParamsIn += "\n" + spaces(12);
      } 
      theoryJsVarsAssign += `var ${rp} = ${getJsAssignWrapStart(cSharpType)}${rp}Key${getJsAssignWrapEnd(cSharpType)};\n${spaces(12)}`;
      //console.log("theoryJsVarsAssign: ", theoryJsVarsAssign);
      // end of inner loop
    }

    theoryCallParamsIn += "int expectedStatusCode, string invalidParamName";
        //console.log('    theoryReqParamsArray: ', theoryReqParamsArray);
        //console.log('theoryString: ', theoryString);
        //console.log('theoryCallParamsIn : ', theoryCallParamsIn);

  let theoryContent =
  `      {
            static string GetConst(string name)
                => typeof(Constants).GetField(name)?.GetValue(null)?.ToString() ?? throw new ArgumentException($"Missing constant: {name}");

            ${theoryJsVarsAssign}
            _factory.Log("Test Case : Get${endpoint}_AllValidParams_Except" + invalidParamName + "_Returns" + expectedStatusCode.ToString());

            var url = $"/{_endpoint}${successCaseReqPathVarsString2}"
            ${successCaseQueryStringVarsString2};

            var response = await _client.GetAsync(url);
            Assert.Equal((HttpStatusCode)expectedStatusCode, response.StatusCode);
        }`



  let theoryMethodCall = 
  `        public async Task Get${endpoint}_WithInvalidParameterCombination_ReturnsExpectedStatus(${theoryCallParamsIn})
  `;

      theoryString += "\n" + theoryMethodCall;
    theoryString += theoryContent;

  return theoryString;
}