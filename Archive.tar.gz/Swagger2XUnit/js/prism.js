  
  
  function applyCodeHighlighting() {
    if (window.Prism && Prism.highlightElement) {
      //console.log('code1: ', code1);
      //Prism.highlightElement(code1);
      //console.log('prism style applied');
    }
  }
