
function generateTotalTests() {
  
  let requiredPathVars = "";
  let paramRequired = false;
  let requiredCtr = 0;
  let paramName = "";
  let paramIn = "";
  let paramType = "";
  let successCaseReqPathVarsString = "";
  let successCaseQueryStringVarsString = "";
  let successCaseReqPathVarsString2 = "";
  let successCaseQueryStringVarsString2 = "";
  let paramNames = "";
  let firstQueryStringParamSet = false;
  let reqFailedCaseString = "";
  let failCaseReqPathVarsString = "";
  let failCaseCtr = 0;
  let inlineDataStartCaseNum = 0;
  let inlineDataEndCaseNum = 0;
  let queryStringParamCount = 0;

  let paramNameValueArr = [];
  let paramNameValueObj;
  let inner = "";
  let params = "";
  let index = "";

  table = document.getElementById("tblParams");
  if (table) {
    for (let i = 0; i < table.rows.length; i++) {
      if (i == 0) {
        continue;
      }
      else
      {
        const row = table.rows[i];
        paramRequired = false;
        //#region forloop
        for (let j = 0; j < row.cells.length; j++) {
          const cell = row.cells[j];
          switch (j) {
            case 0:
              paramName = cell.textContent;          
              break;
            case 1:
              paramType = cell.textContent;    
              break;
            case 2:
              break;
            case 3:
              paramRequired = parseBool(cell.textContent);          
              break;
            case 4:
              paramIn = cell.textContent;
              break;
            case 5:
              //description
              break;
            default:
              break;
            }
            paramNameValueObj = { paramName: paramName, paramType: paramType };
        } 
        paramNameValueArr.push(paramNameValueObj);
      }

      if (paramName != "") {
        theoryAllParams += paramName + ";";
      }
      else {
        continue;
      }
      
      if (paramRequired) {
        requiredCtr+=1;      
        if (paramName != "") {
          paramNames += paramName + ",";
        }
        if (paramName != "") {
          theoryReqParams += paramName + ";";
        }
        
        if (paramIn == "path") {     
          requiredPathVars += "{" + paramName + "}";
          successCaseReqPathVarsString += "/{" + getSuccessCaseConstantName(paramName) + "}";
          successCaseReqPathVarsString2 += "/{" + getSuccessCaseConstantName2(paramName) + "}";
          failCaseReqPathVarsString += "/{" + getFailCaseConstantName(paramName) + "}";
        }
        
        failCaseCtr+=1;

        reqFailedCaseString += 
      `[Fact] // Error Case ${failCaseCtr}: Invalid ${caps(paramName)} returns 400
        public async Task ${caps(endpoint)}_Invalid${caps(paramName)}_Returns400()
        {
            var url = $"/{_endpoint}${failCaseReqPathVarsString}";
            var response = await _client.GetAsync(url);
            Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        }`;

        failCaseCtr+=1;

        reqFailedCaseString += `\n
        [Fact] // Error Case ${failCaseCtr}: Empty ${caps(paramName)} returns 404
        public async Task ${caps(endpoint)}_Empty${caps(paramName)}_Returns404()
        {
            var url = $"/{_endpoint}/{Constants.EmptyString}";
            var response = await _client.GetAsync(url);
            Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        }`;

        inlineDataStartCaseNum = (failCaseCtr+1);
      }
      else {
        if (paramName != "") { 
          theoryOptionalParams += paramName + ";";
        }        
      }

      // console.log('paramName: ' + paramName);
      // console.log('  paramType: ' + paramType);
      // console.log('  paramIn: ' + paramIn);
      // console.log('  paramRequired: ' + paramRequired);

      if (paramIn == "query") {
     
        queryStringParamCount+=1;

        if (firstQueryStringParamSet == false) {
          successCaseQueryStringVarsString += `  + $"?`;
          successCaseQueryStringVarsString2 += `  + $"?`;
          firstQueryStringParamSet=true;
        }
        else {
          successCaseQueryStringVarsString += `\n ${spaces(12)} + $"&`;
          successCaseQueryStringVarsString2 += `\n ${spaces(12)} + $"&`;
        }

        successCaseQueryStringVarsString += `${paramName}=`;
        successCaseQueryStringVarsString2 += `${paramName}=`;

        switch (paramType) {
          case "integer":
            successCaseQueryStringVarsString += `{${getSuccessCaseConstantName(paramName, false)}}"`;
            successCaseQueryStringVarsString2 += `{${paramName}}"`;
            break;
          case "date":
            //successCaseQueryStringVarsString += `"{Constants.${caps(paramName)}}"`;
            successCaseQueryStringVarsString += `{${getSuccessCaseConstantName(paramName, false)}}"`;
            successCaseQueryStringVarsString2 += `{${paramName}}"`;
            break;       
          case "string":
            //successCaseQueryStringVarsString += `"{Constants.${caps(paramName)}}"`;
            successCaseQueryStringVarsString += `{${getSuccessCaseConstantName(paramName, false)}}"`;
            successCaseQueryStringVarsString2 += `{${paramName}}"`;
            break;         
          case "boolean":
            //successCaseQueryStringVarsString += `"{Constants.${caps(paramName)}}"`;
            successCaseQueryStringVarsString += `{${getSuccessCaseConstantName(paramName, false)}}"`;
            successCaseQueryStringVarsString2 += `{${paramName}}"`;
            break;        
          default:
            break;
        }
        //queryStringParamCount         
      }       
      //console.log('successCaseQueryStringVarsString, paramName : ' + successCaseQueryStringVarsString + "\n" + paramName);     
    }
  }
  else {
    //console.log('%c  table var empty', 'color:red; font-weight: 700;');   
  }

        let invalidInlineParamName = "";
        let invalidInlineParamName2 = "";
        let str = "";
        let invalidParamMatchText = "";
   
        //console.log('%c------------------------------------------------------------------------- START --------------------------------------------------------------------------:', 'color: green; font-weight: 700;');   

        let finalInvalidParam = "";
        theoryInlineDataString="";                        
        
        //---------------------------------------------before inline param loop-----------------------------------------------
        theoryAllParamsArray  = theoryAllParams.split(";").filter(Boolean);
        //console.log('%c---------------------------------------------------------------------------------------------:', 'color: black; font-weight: 700;');
        //console.log("theoryAllParamsArray: ",theoryAllParamsArray);
        //console.log('%c---------------------------------------------------------------------------------------------:', 'color: black; font-weight: 700;');
        for (let p = 0; p < theoryAllParamsArray.length; p++) {

          theoryInlineDataDefaultLineString += "[InlineData(";

          let currentInvalidParam = "";
          let param = theoryAllParamsArray[p];
          let paramNumber = p + 1;
          if (param != "") {
            //console.log('param : ' + param);            
            //console.log('  paramNumber : ' + paramNumber);
          }      
          //----------------------------------        
          let innerParamLoopCtr = 0;
          theoryReqParamsArray = theoryReqParams.split(";").filter(Boolean);          
          
          //console.log('    theoryReqParamsArray: ', theoryReqParamsArray);
          for (let r = 0; r < theoryReqParamsArray.length; r++) {
            innerParamLoopCtr+=1;
            //console.log('      inner paramNumber : ' + innerParamLoopCtr);
            let reqParam = theoryReqParamsArray[r];
            if (reqParam != "") {
              if (reqParam == param) {
                //console.log('      reqParam : ' + reqParam);
                currentInvalidParam = reqParam;                
                theoryInlineDataDefaultLineString += '"' + getFailCaseConstantName(currentInvalidParam, true) + '"';        
                if (innerParamLoopCtr < theoryAllParamsArray.length) {
                  theoryInlineDataDefaultLineString += ", ";
                }                                 
              }
              else
              {
                currentInvalidParam = reqParam;
                theoryInlineDataDefaultLineString += '"' + getSuccessCaseConstantName(currentInvalidParam, true) + '"';
                if (innerParamLoopCtr < theoryAllParamsArray.length) {
                  theoryInlineDataDefaultLineString += ", ";
                }                                                                     
              }
            }            
          }

          theoryOptParamsArray  = theoryOptionalParams.split(";").filter(Boolean);
          //console.log('    theoryOptParamsArray: ', theoryOptParamsArray);
          for (let o = 0; o < theoryOptParamsArray.length; o++) {
            innerParamLoopCtr+=1;
            //console.log('      inner paramNumber : ' + innerParamLoopCtr);
            
            let optParam = theoryOptParamsArray[o];
            if (optParam != "") {
              if (optParam == param) {
              currentInvalidParam = optParam;
                theoryInlineDataDefaultLineString += '"' + getFailCaseConstantName(currentInvalidParam, true) + '"';
                if (innerParamLoopCtr < theoryAllParamsArray.length) {
                  theoryInlineDataDefaultLineString += ", ";
                }                
              }
              else {
                currentInvalidParam = optParam;
                theoryInlineDataDefaultLineString += '"' +  getSuccessCaseConstantName(currentInvalidParam, true) + '"';                
                if (innerParamLoopCtr < theoryAllParamsArray.length) {
                  theoryInlineDataDefaultLineString += ", ";
                }                
              }
            }
          }
          

          str = theoryInlineDataDefaultLineString;
          const invalidParamMatchText = str.match(/invalid([^"]*)/);

          //console.log('invalid param match');

          if (invalidParamMatchText) {
            //console.log("Full:", invalidParamMatchText[0]); // invalidOrganizationId
            invalidInlineParamName = invalidParamMatchText[1];

            //console.log('invalidParamMatchText : ', invalidParamMatchText);
            //console.log('invalidInlineParamName', invalidInlineParamName);
          }
          else {

            //console.log('invalidParamMatchText : ', invalidParamMatchText);
            //console.log('invalidInlineParamName', invalidInlineParamName);
          }


          //invalidInlineParamName2
          if (invalidInlineParamName == "") {
            //look for other params with invalid like text
            // false
            
            // 1. Extract everything inside the parentheses
            let inner = null;
            if (str) {
              const match = str.match(/\((.*)\)/);
              if (match && match[1]) {
                inner = match[1];
                // 2. Split by comma, trim, and strip quotes
                params = inner.split(",").map(p => p.trim().replace(/^"|"$/g, ""));

                // 3. Find index of the one containing "false" (case-insensitive)
                index = params.findIndex(p => p.toLowerCase().includes("false"));

                //console.log("Parameters:", params);
                //console.log("Found at index:", index);       // 3 (zero-based)

                invalidInlineParamName2 = theoryAllParamsArray[0];
                //console.log('invalidInlineParam2 is  : ', invalidInlineParamName2);
                //console.log("Found at slot:", index + 1);    // 4 (one-based)
              }
            }



          }          

          //add error code and which param is 
          //console.log('need error code here : ');          

          let finalInvalidParamName = "";
          if (invalidInlineParamName.trim() != "") {
            finalInvalidParamName = invalidInlineParamName;
          }
          else
          {
            finalInvalidParamName = invalidInlineParamName2;
          }

          let finalErrorCode = "404";
          //console.log('before https error assign : ' + param);
          theoryInlineDataDefaultLineString += ", " + getInvalidInlineParamHttpsErrorCode(param) + ", \"" + caps(param) + "\"";         
          theoryInlineDataDefaultLineString += ")]\n        ";            
          theoryInlineDataString += theoryInlineDataDefaultLineString;
          theoryInlineDataDefaultLineString = "";
                    
          //console.log('%c------------for loop next record-------------', 'color: black; font-weight: 700;');             
          //console.log('');
        }
        //---------------------------------------------after inline param for loop-----------------------------------------------        


  // console.log('total inlineDataStartCaseNum : ' + inlineDataStartCaseNum);
  // console.log('total inlineDataEndCaseNum : ' + inlineDataEndCaseNum);
  // console.log('total paramNameValueArr : ' + paramNameValueArr);
  // console.log('total successCaseReqPathVarsString2 : ' + successCaseReqPathVarsString2);
  // console.log('total successCaseQueryStringVarsString2 : ' + successCaseQueryStringVarsString2);

  inlineDataEndCaseNum = inlineDataStartCaseNum + queryStringParamCount;

  let theoryString = `                      // [Theory] treats each [InlineData] attribute like an individual test [Fact]
        [Theory] //Error Cases ${inlineDataStartCaseNum}-${inlineDataEndCaseNum}: All valid parameters except one for each [InlineData] parameter set
        ${theoryInlineDataString}
  `;

  paramNames = paramNames.slice(0, -1); 
  
  let cSharpClassString = 
`using System.Net;

namespace RealCloud.API.IntegrationTests
{
    public class ${endpoint}Tests : TestBase
    {
        private const string _endpoint = "${caps(endpoint)}";
        public ${caps(endpoint)}Tests(ApiFactory factory, ITestOutputHelper output)
            : base(factory, output) { }
        
        #region "Endpoint : GET /${caps(endpoint)}/${requiredPathVars}"  
      
        [Fact] // Success Case 1 : Required params only return successfully
        public async Task Get${caps(endpoint)}_ValidRequiredParams_ReturnsSuccessAndExpectedData()
        {
            var url = $"/{_endpoint}${successCaseReqPathVarsString}";
            var response = await _client.GetAsync(url);
            response.EnsureSuccessStatusCode();
            var responseContent = await response.Content.ReadAsStringAsync();
            Assert.Equal(Constants.${caps(endpoint.replace("Total",""))}RequiredParamsOnlyTotal, Int32.Parse(responseContent));
        }

        [Fact] // Success Case 2: All params passed with all valid values returns successfully
        public async Task Get${caps(endpoint)}_AllValidParamsPassed_ReturnsSuccessAndExpectedData()
        {
            var url = $"/{_endpoint}${successCaseReqPathVarsString}"
            ${successCaseQueryStringVarsString};

            var response = await _client.GetAsync(url);
            response.EnsureSuccessStatusCode();
            var responseContent = await response.Content.ReadAsStringAsync();
            Assert.Equal(Constants.${endpoint.replace("Total","")}AllParamsTotal, Int32.Parse(responseContent));
        }
            
        ${reqFailedCaseString}
`;

theoryString = theoryString.trim();
  if (theoryString.endsWith(",")) {
    theoryString = theoryString.slice(0, -1);
  }

  theoryString = spaces(4) + theoryString;
                  
  let theoryCallParamsIn = "";
  let cSharpType = "";
  let theoryJsVarsAssign = "";
  
  for (let r = 0; r < theoryAllParamsArray.length; r++) {        
    let rp = theoryAllParamsArray[r];
    //console.log('');

    for (let pn = 0; pn < paramNameValueArr.length; pn++) {       
      let pv = paramNameValueArr[pn];          
      
      let apiParamType = pv.paramType;          

      switch (apiParamType) {
        case "string":
          cSharpType = "string";
          break;
        case "integer":
          cSharpType = "string";
          break;          
        case "boolean":
          cSharpType = "string";
          break;              
        default:
          break;
      }                  
    }         
      
      theoryCallParamsIn += cSharpType + " " + rp + "Key, ";
      if (r == 1 || r == 7) {
        theoryCallParamsIn = theoryCallParamsIn.trimEnd();
        theoryCallParamsIn += "\n" + spaces(12);
      } 
      theoryJsVarsAssign += `var ${rp} = ${getJsAssignWrapStart(cSharpType)}${rp}Key${getJsAssignWrapEnd(cSharpType)};\n${spaces(12)}`;
      //console.log("theoryJsVarsAssign: ", theoryJsVarsAssign);
      // end of inner loop
    }

    theoryCallParamsIn += "int expectedStatusCode, string invalidParamName";
        //console.log('    theoryReqParamsArray: ', theoryReqParamsArray);
        //console.log('theoryString: ', theoryString);
        //console.log('theoryCallParamsIn : ', theoryCallParamsIn);

let theoryContent =
`      {
            static string GetConst(string name)
                => typeof(Constants).GetField(name)?.GetValue(null)?.ToString() ?? throw new ArgumentException($"Missing constant: {name}");

            ${theoryJsVarsAssign}
            _factory.Log("Test Case : Get${endpoint}_AllValidParams_Except" + invalidParamName + "_Returns" + expectedStatusCode.ToString());

            var url = $"/{_endpoint}${successCaseReqPathVarsString2}"
            ${successCaseQueryStringVarsString2};

            var response = await _client.GetAsync(url);
            Assert.Equal((HttpStatusCode)expectedStatusCode, response.StatusCode);
       }`



  let theoryMethodCall = 
`        public async Task Get${endpoint}_WithInvalidParameterCombination_ReturnsExpectedStatus(${theoryCallParamsIn})
  `;

     let endOfCSharpString = 
 `   #endregion
    }
}`;

    theoryString += "\n" + theoryMethodCall;
    theoryString += theoryContent;

    cSharpClassString += 
    `
    ${theoryString}

    ${endOfCSharpString}
    `;

  return cSharpClassString;
}


