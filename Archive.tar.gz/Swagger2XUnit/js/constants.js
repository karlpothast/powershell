//vars
const pageTitle = "Generate XUnit Tests"
const spanPageTitle = document.getElementById("span-page-title");
spanPageTitle.innerText = pageTitle;
document.head.title = pageTitle;
const selectHttpMethods = document.getElementById("selectHttpMethods");
const txtEndpointUri = document.getElementById('txtEndpointUri');
const spanMsg = document.getElementById('spanMsg');
const btnCopy = document.getElementById('btnCopy');
const btnClear = document.getElementById('btnClear');
const pre1 = document.getElementById('pre1');
const pre2 = document.getElementById('pre2');
const divResults = document.getElementById('divResults');
const btnGen = document.getElementById('btnGen');
const btnGenTestClass = document.getElementById('btnGenTestClass');
const txtEntity = document.getElementById('txtEntity');
const txtEndpoint = document.getElementById('txtEndpoint');
const txtInputVarName = document.getElementById('txtInputVarName');
const txtInvalidInputVarName = document.getElementById('txtInvalidInputVarName');
const txtApiDefinition = document.getElementById('txtApiDefinition');
const btnApiDefinitionFile = document.getElementById("btnApiDefinitionFile"); 
const divApiDefinition = document.getElementById('divApiDefinition');
const preApiDefinition = document.getElementById('preApiDefinition');
const divParams = document.getElementById('divParams');
const selectEndpoint = document.getElementById('selectEndpoint');
let apiDefinitionFilePath;
let selectedEndpointVal;
let paramDescription = "";
let paramName = "";
let paramRequired = "";
let paramIn = "";
let paramSchema = "";
let paramType = "";
let paramFormat = "";
let endpoint = "";
let theoryAllParamsArray;
let constantVarsString = "";
const scrollToBottomOnLoad = true;
let apiFileParams;
let table = "";

const code1 = document.getElementById('code1');
const code2 = document.getElementById('code2');

