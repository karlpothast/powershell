
  
    function setExpanded(trigger, expand, acc) {
      const contentId = trigger.getAttribute('aria-controls');
      const content = document.getElementById(contentId);

      trigger.setAttribute('aria-expanded', expand);
      content.setAttribute('aria-hidden', !expand);

      if (expand) {
        content.hidden = false;
        const endHeight = content.scrollHeight;
        content.style.height = endHeight + 'px';
        content.style.opacity = '1';
        content.addEventListener('transitionend', function handler() {
          content.style.height = 'auto';
          content.removeEventListener('transitionend', handler);
        });
      } else {
        const startHeight = content.scrollHeight;
        content.style.height = startHeight + 'px';
        requestAnimationFrame(() => {
          content.style.height = '0px';
          content.style.opacity = '0';
        });
      }
    }

    document.addEventListener('DOMContentLoaded', () => {
      document.querySelectorAll('.accordion').forEach(acc => {
        acc.querySelectorAll('.accordion__trigger').forEach(trigger => {

          // expand on load if marked with data-open
          if (trigger.hasAttribute('data-open')) {
            setExpanded(trigger, true, acc);
          }

          if (trigger.hasAttribute('data-open')) {
            setExpanded(trigger, true, acc);
          }

          trigger.addEventListener('click', () => {
            const expand = trigger.getAttribute('aria-expanded') !== 'true';
            setExpanded(trigger, expand, acc);
          });
        });
      });
    });
  