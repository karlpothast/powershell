  let theoryInlineDataString = "";
  let theoryInlineDataDefaultLineString = "";
  let theoryAllParams = "";
  let theoryReqParams = "";
  let theoryOptionalParams = "";
  let theoryReqParamgArr;
  let theoryReqParamString = "";
  let theoryReqParamsArray;
  let theoryOptParamsArray;