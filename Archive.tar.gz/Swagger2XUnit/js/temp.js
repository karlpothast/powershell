






theoryString = theoryString.trim();
  if (theoryString.endsWith(",")) {
    theoryString = theoryString.slice(0, -1);
  }

  theoryString = spaces(4) + theoryString;
  
          
      let theoryCallParamsIn = "";
      let cSharpType = "";
      let theoryJsVarsAssign = "";
      
      for (let r = 0; r < theoryAllParamsArray.length; r++) {        
        let rp = theoryAllParamsArray[r];

        for (let pn = 0; pn < paramNameValueArr.length; pn++) {       
          let pv = paramNameValueArr[pn];          
          
          let apiParamType = pv.paramType;          

          switch (apiParamType) {
            case "string":
              cSharpType = "string";
              break;
            case "integer":
              cSharpType = "string";
              break;          
            case "boolean":
              cSharpType = "string";
              break;              
            default:
              break;
          }                  
        }         

// var patientId = GetConst(patientIdKey);
// var organizationId = GetConst(organizationIdKey);
// var minDate = Uri.EscapeDataString(GetConst(minDateKey));
// var maxDate = Uri.EscapeDataString(GetConst(maxDateKey));
      
        theoryCallParamsIn += cSharpType + " " + rp + "Key, ";
        if (r == 1 || r == 7) {
          theoryCallParamsIn = theoryCallParamsIn.trimEnd();
          theoryCallParamsIn += "\n" + spaces(12);
        } 
        theoryJsVarsAssign += `var ${rp} = ${getJsAssignWrapStart(cSharpType)}${rp}Key${getJsAssignWrapEnd(cSharpType)};\n${spaces(12)}`;
        // end of inner loop
      }

      theoryCallParamsIn += "int expectedStatusCode, string invalidParamName";

let theoryContent =
`      {
            static string GetConst(string name)
                => typeof(Constants).GetField(name)?.GetValue(null)?.ToString() ?? throw new ArgumentException($"Missing constant: {name}");

            ${theoryJsVarsAssign}
            _factory.Log("Test Case : Get${endpoint}_AllValidParams_Except" + invalidParamName + "_Returns" + expectedStatusCode.ToString());

            var url = $"/{_endpoint}${successCaseReqPathVarsString2}"
            ${successCaseQueryStringVarsString2};

            var response = await _client.GetAsync(url);
            Assert.Equal((HttpStatusCode)expectedStatusCode, response.StatusCode);
       }`

    let reqParamsIn = '';

  let theoryMethodCall = 
`        public async Task Get${endpoint}_WithInvalidParameterCombination_ReturnsExpectedStatus(${theoryCallParamsIn})
  `;




     let endOfCSharpString = 
 `   #endregion
    }
}`;

      theoryString += "\n" + theoryMethodCall;

      theoryString += theoryContent;


    cSharpClassString += 
    `
    ${theoryString}

    ${endOfCSharpString}
    `;
