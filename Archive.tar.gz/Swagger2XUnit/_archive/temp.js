//vars
const pageTitle = "Generate XUnit Tests"
const spanPageTitle = document.getElementById("span-page-title");
spanPageTitle.innerText = pageTitle;
document.head.title = pageTitle;
const selectHttpMethods = document.getElementById("selectHttpMethods");
const txtEndpointUri = document.getElementById('txtEndpointUri');
const spanMsg = document.getElementById('spanMsg');
const btnCopy = document.getElementById('btnCopy');
const btnClear = document.getElementById('btnClear');
const pre1 = document.getElementById('pre1');
const divResults = document.getElementById('divResults');
const btnGen = document.getElementById('btnGen');
const btnGenTestClass = document.getElementById('btnGenTestClass');
const txtEntity = document.getElementById('entity');
const txtEndpoint = document.getElementById('txtEndpoint');
const txtInputVarName = document.getElementById('txtInputVarName');
const txtInvalidInputVarName = document.getElementById('txtInvalidInputVarName');
const txtApiDefinition = document.getElementById('txtApiDefinition');
const btnApiDefinitionFile = document.getElementById("btnApiDefinitionFile"); 
const divApiDefinition = document.getElementById('divApiDefinition');
const preApiDefinition = document.getElementById('preApiDefinition');
let paramDescription = "";
let paramName = "";
let paramRequired = "";
let paramIn = "";
let paramSchema = "";
let paramType = "";
let paramFormat = "";

window.onload = function () {
  divResults.style.visibility = "hidden";
  getEndpoint();
  loadDefaultValues();
  //console.log('load');
};

btnGenTestClass.addEventListener('click', () => {

  pre1.innerText = "";
  let ControllerName = txtEndpoint.value;
  let classString = 
`
namespace RealCloud.API.IntegrationTests
{
    public class ${ControllerName}Tests : TestBase
    {        
        private const string _endpoint = "${ControllerName}";
        public ${ControllerName}Tests(ApiFactory factory, ITestOutputHelper output)
            : base(factory, output) {}
          

    }
}
`;

pre1.innerText = classString;


});

btnGen.addEventListener('click', () => {
  pre1.innerText = "";
  divResults.style.visibility = "visible";
  const endpoint = txtEndpoint.value;
  const entity = document.getElementById('entity').value;
  //const entityType = document.getElementById('entityType').value;
  const returnObj = document.getElementById('returnObj').value;

  const respVarName = document.getElementById('respVarName').value;
  const invalidInputVarName = txtInvalidInputVarName.value;
  const inputVarName = txtInputVarName.value;

  let newTestsCodeString = getXunitString(endpoint, entity, "", returnObj, inputVarName, respVarName, invalidInputVarName);
  
  divResults.style.visibility = "hidden";
  //console.log('newTestsCodeString: ', newTestsCodeString);
  pre1.innerText = newTestsCodeString;

});

btnClear.addEventListener('click', () => {
  pre1.innerText = "";
});

btnCopy.addEventListener('click', () => {
  
  let text = pre1.innerText;
  if (text.trim() != "") {
    navigator.clipboard.writeText(text)
      .then(() => {
        spanMsg.innerText = "Copied to clipboard";
        $('#spanMsg').fadeIn(500)        // Fade in over 400ms
        .delay(1200)        // Stay visible for 2 seconds
        .fadeOut(500);      // Fade out over 400ms

        //console.log('✅ Text copied to clipboard:', text);
      })
      .catch(err => {
        //console.error('❌ Failed to copy text:', err);    
      });
  }
});

selectHttpMethods.addEventListener("change", function () {
  setEndpointCookie();
  getEndpoint();
  loadDefaultValues();
});

txtEndpointUri.addEventListener("change", function () {
  setEndpointCookie();
  getEndpoint();
  loadDefaultValues();
});

function getEndpoint() {
  parseCookie(); 
}

function parseCookie() {
  let cookieValue = getCookie("endpoint");
  //console.log('cookieValue:', cookieValue);

  if (cookieValue) {
    let cookieValueArray = cookieValue.split(";");
    //console.log('cookieValueArray: ', cookieValueArray);

    let httpMethodCookieString = cookieValueArray[0];
    let httpMethodCookieStringArr = httpMethodCookieString.split(":");
    let httpMethodCookieVal = httpMethodCookieStringArr[1];
    if (httpMethodCookieVal) {
      selectHttpMethods.value = httpMethodCookieVal;
      //console.log('selectHttpMethods set to : ' + httpMethodCookieVal);
    }

    let endpointCookieString = cookieValueArray[1];
    let endpointCookieStringArr = endpointCookieString.split(":");
    let endpointCookieVal = endpointCookieStringArr[1];
    if (endpointCookieVal) {
      txtEndpointUri.value = endpointCookieVal;
      //console.log('txtEndpoint set to : ' +  endpointCookieVal);

      let endpointStringArray  = endpointCookieVal.split("/");
      let ctr=0;
      for (let i = 0; i < endpointStringArray.length; i++) {
        let item = endpointStringArray[i];
        //console.log('endpoint piece : ' + item);
        if (ctr==0) {
          //blank (before first "/"")
        }
        if (ctr==1) {
          //blank (before first "/"")
          txtEndpoint.value = item;
          txtEntity.value = item.toUpperCase().replace("TOTAL","").replace("AUDIT","").toLowerCase();
        }
        if (item.includes("{") && item.includes("}")) {
          txtInputVarName.value = capitalize(item.replace("{","").replace("}",""));
          txtInvalidInputVarName.value = "Invalid" + capitalize(item.replace("{","").replace("}",""));
        }
        ctr+=1;
      }
    }

    let apiDefinitionFilePathString = cookieValueArray[2];
    let apiDefinitionFilePathStringArr = splitAtFirstChar(apiDefinitionFilePathString,':');
    let apiDefinitionFilePath = apiDefinitionFilePathStringArr[1];
  }
}

function getApiParams() {

      if (apiDefinitionFilePath) {
      txtApiDefinition.value = apiDefinitionFilePath;
      (async () => {
        try {
          const apiFileContent = await getFileContent(apiDefinitionFilePath);
          let jsonObjApiFileContent = JSON.parse(apiFileContent);

          if (apiFileContent) {
            const jsonFormatted = JSON.stringify(jsonObjApiFileContent, null, 2); // 2 = indentation spaces
            preApiDefinition.innerText = jsonFormatted;

            (async () => {
            try {

              const apiFileParams = await getEndpointParameters("swagger.json", txtEndpointUri.value, selectHttpMethods.value, "request");
              console.log('apiFileParams', apiFileParams);

              const tblParams  = document.createElement("table");
              tblParams.style.borderCollapse = "collapse";
              tblParams.style.width = "100%";
              let thead = document.createElement("thead");
              let trHead = document.createElement("tr");
              addTableHeader(trHead, apiFileParams);
              thead.appendChild(trHead);
   
              let tbody = document.createElement("tbody");
              let tr = document.createElement("tr");

            } catch (err) {
              console.error("Error:", err);

            }
          })();

          } else {
            console.log("No content returned");
            txtApiDefinition.style.color = "gray";
            btnApiDefinitionFile.enabled = false;
          }
        } catch (err) {
          console.error("Error:", err);
          txtApiDefinition.style.color = "gray";
          btnApiDefinitionFile.enabled = false;
        }
      })();
    }

  
}

function addParamsTableHader(trHead, apiFileParams) {
  apiFileParams.forEach(param => {
    // let th = document.createElement("th");
    // th.textContent = "Name";
    // trHead.appendChild(th)
    // const td = document.createElement("td");
    // const value = row[col.key];
    // tr.appendChild(td);
    // tbody.appendChild(tr);

        // paramDescription = param.description;
    // paramRequired = param.required;
    // paramIn = param.in
    // paramSchema = param.schema;
    // if (paramSchema) {
    //   paramType = paramSchema.type;
    //   paramFormat = paramSchema.format;
    // }

    let paramName = paramDescription = paramRequired = paramIn = paramSchema = paramType = "";
    paramName = param.name;
    console.log('name: ', paramName);  
  })
}



function loadDefaultValues() {

  let endpoint = "IdLookup";
  let entity = "organization";
  let entityType = "external";
  let respEntityType = "internal";
  let returnObj = "organization";
  let inputVarName = respEntityType + capitalize("organizationId");
  let respVarName = entityType + capitalize(entity) + "Id";

  // document.getElementById('endpoint').value = endpoint;
  // document.getElementById('entity').value = entity;
  // document.getElementById('entityType').value = entityType;
  // document.getElementById('returnObj').value = returnObj;
  // document.getElementById('inputVarName').value = inputVarName;
  // document.getElementById('respVarName').value = respVarName;
  txtInvalidInputVarName.value = "Invalid";
}

function getXunitString(endpoint, entity, entityType, returnObj, inputVarName, respVarName, invalidInputVarName) {

  let xunitTestString =
  `
            #region "GET /${endpoint}/${entity}/${entityType}/{${returnObj}}"

            [Fact]  // Success Case                        
            public async Task Get${capitalize(entityType)}${capitalize(returnObj)}_Valid${capitalize(inputVarName.replace("Id",""))}_ReturnsSuccessAndExpectedData()
            {                         
                var url = $"/{_endpoint}/${entity}/${entityType}/{Constants.${capitalize(inputVarName)}}";   
                var response = await _client.GetAsync(url);                       
                response.EnsureSuccessStatusCode();                          
                var responseContent = await response.Content.ReadAsStringAsync();                
                Assert.Equal(Constants.${capitalize(respVarName)}, responseContent);                         
            }

            [Fact]  // Error Case 1: Invalid ${inputVarName}
            public async Task Get${capitalize(entityType)}${capitalize(returnObj)}_Invalid${capitalize(inputVarName.replace("Id",""))}_ReturnsEmptyResponse()
            {            
                var url = $"/{_endpoint}/${entity}/${entityType}/{Constants.Invalid${capitalize(inputVarName)}}";                        
                var response = await _client.GetAsync(url);               
                response.EnsureSuccessStatusCode();               
                var responseContent = await response.Content.ReadAsStringAsync();
                Assert.True(string.IsNullOrWhiteSpace(responseContent));
            }

              // *** OR *** 
              
            [Fact] // Error Case 1: Invalid ${inputVarName}
            public async Task Get${capitalize(entityType)}${capitalize(returnObj)}_Invalid${capitalize(inputVarName.replace("Id",""))}_ReturnsNegativeOne()
            {
                var url = $"/{_endpoint}/${entity}/${entityType}/{Constants.Invalid${capitalize(inputVarName)}}";
                var response = await _client.GetAsync(url);
                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();
                Assert.Equal(Constants.NegativeOne, responseContent);   
            }

            [Fact]  //Error Case 2: Bad Input (Empty String)
            public async Task Get${capitalize(entityType)}${capitalize(returnObj)}_EmptyString_ReturnsErrorNotFound()
            {            
                var url = $"/{_endpoint}/${entity}/${entityType}/{Constants.EmptyString}";                                   
                var response = await _client.GetAsync(url);
                Assert.Equal(HttpStatusCode.NotFound, response.StatusCode); 
            }
              
            #endregion
  `;

  return xunitTestString;
}

function capitalize(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function setEndpointCookie() {
  let httpMethod = selectHttpMethods.value;
  let apiUri = txtEndpointUri.value;
  let definitionFilePath = txtApiDefinition.value;
  let cookieValue = "httpMethod:"+httpMethod+";"+"apiUri:"+apiUri+";definitionFilePath:"+definitionFilePath;
  //console.log('cookie value :' + cookieValue);
  if (httpMethod != "0") {
    setCookie("endpoint", cookieValue);
  }
  else if (httpMethod == "0") { 
    deleteCookie("endpoint");
  }
}

function splitAtFirstChar(str, char) {
  const index = str.indexOf(char);
  
  if (index === -1) {
    // character not found → return whole string as first part, empty second part
    return [str, ""];
  }

  return [str.slice(0, index), str.slice(index + 1)];
}

async function getFileContent(filePath) {
  try {
    const response = await fetch("http://localhost:8078/Windows/GetFileContent", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ filePath })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    //const data = await response.json(); // assuming your API returns JSON
    const data = await response.text();
    return data;
  } catch (err) {
    console.error("Error fetching file content:", err);
  }
}

btnApiDefinitionFile.addEventListener("click", (e) => {
  //console.log('make button visible');
  //divApiDefinition.style.visibility = "visible";

   if (divApiDefinition.style.visibility === "hidden" || divApiDefinition.style.visibility === "") {
      //console.log('hidden - make visible');
      divApiDefinition.style.visibility = "visible";
   } else {
      //console.log('visible - hide');
      divApiDefinition.style.visibility = "hidden";
   }
});

document.addEventListener("click", (event) => {
    //console.log("Page was clicked!", event);

    // Example: log where it was clicked
    //console.log("Clicked element:", event.target);
    let clickedElement = event.target;
    //console.log("Coordinates:", event.clientX, event.clientY);
});

// async function getSchema(specUrl, path, method, kind = "request") {
//   const spec = await fetch(specUrl).then(r => r.json());
//   const op = spec.paths?.[path]?.[method.toLowerCase()];
//   if (!op) throw new Error("Path/method not found");

//   if (kind === "request") {
//     return op.requestBody?.content?.["application/json"]?.schema;
//   } else {
//     return op.responses?.["200"]?.content?.["application/json"]?.schema;
//   }
// }

async function getEndpointParameters(specUrl, path, method, kind = "request") {
  const spec = await fetch(specUrl).then(r => r.json());
  const op = spec.paths?.[path]?.[method.toLowerCase()];
  if (!op) throw new Error("Path/method not found");

  if (kind === "request") {
    if (op.requestBody) {
      // POST/PUT/PATCH
      return op.requestBody.content?.["application/json"]?.schema;
    } else if (op.parameters) {
      // GET, DELETE, etc → use parameters instead of body
      return op.parameters;
    }
  } else {
    // responses
    return op.responses?.["200"]?.content?.["application/json"]?.schema;
  }
}


// // Example:
// getSchema("/swagger/v1/swagger.json", "/Windows/GetFileContent", "post", "request")
//   .then(console.log);

// getEndpointParameters("swagger.json", "/ExamTotal/v2/{organizationId}/{patientId}", "get", "request")
//   .then(console.log);

