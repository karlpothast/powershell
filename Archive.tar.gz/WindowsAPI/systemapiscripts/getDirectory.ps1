


param (
    [string]$Path = ""
)

if (-not (Test-Path -Path $Path)) {
    Write-Error "The path '$Path' does not exist."
    exit 1
}

$items = Get-ChildItem -Path $Path |
    Sort-Object { if ($_.PSIsContainer) { 0 } else { 1 } }, Name |
    Select-Object Name, @{Name="Type";Expression={if ($_.PSIsContainer){"Directory"}else{"File"}}}, Length, LastWriteTime

$items | ConvertTo-Json -Depth 2
