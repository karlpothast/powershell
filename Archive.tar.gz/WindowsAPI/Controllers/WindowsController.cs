using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace WindowsAPI.Controllers;

[ApiController]
[Route("[controller]")]
public class WindowsController : ControllerBase
{
    [HttpPost("GetDirectoryContents")]
    public IActionResult RunScript([FromBody] string path)
    {
        try
        {
          //only allow predefined scripts - not any command text     
          using var ps = new Process();
          ps.StartInfo.FileName = "powershell";
          //ps.StartInfo.Arguments = $"-NoProfile -ExecutionPolicy Bypass -Command \"{script}\"";
          //ps.StartInfo.Arguments = $"-NoProfile -ExecutionPolicy Bypass -Command \"{C:\Users\KarlPothast\source\repos\WindowsAPI\systemapiscripts\getDirectory.ps1}\"";
          //ps.StartInfo.Arguments = $@"-NoProfile -ExecutionPolicy Bypass -Command  @"C:\Users\KarlPothast\source\repos\WindowsAPI\systemapiscripts\getDirectory.ps1";;
          
      //  using var ps = new Process();
      //         ps.StartInfo.FileName = "powershell";
              // ps.StartInfo.Arguments = $"-NoProfile -ExecutionPolicy Bypass -File \"C:\\Users\\KarlPothast\\source\\repos\\WindowsAPI\\systemapiscripts\\getDirectory.ps1\" \"{path}\"";

              ps.StartInfo.Arguments = $"-NoProfile -ExecutionPolicy Bypass -File \"C:\\Users\\KarlPothast\\source\\repos\\WindowsAPI\\systemapiscripts\\getDirectory.ps1\" \"{path}\"";

      //         ps.StartInfo.RedirectStandardOutput = true;
      //         ps.StartInfo.RedirectStandardError = true;
      //         ps.StartInfo.UseShellExecute = false;
      //         ps.StartInfo.CreateNoWindow = true;


          ps.StartInfo.RedirectStandardOutput = true;
          ps.StartInfo.RedirectStandardError = true;
          ps.StartInfo.UseShellExecute = false;
          ps.StartInfo.CreateNoWindow = true;
          

          ps.Start();
          string output = ps.StandardOutput.ReadToEnd();
          string error = ps.StandardError.ReadToEnd();
          ps.WaitForExit();

          if (!string.IsNullOrWhiteSpace(error))
              return BadRequest(error);

          return Ok(output);
        }
        catch (Exception ex)
        {
            return StatusCode(500, ex.Message);
        }
    }

    public class FileRequest
    {
        public string FilePath { get; set; }
    }

    [HttpPost("GetFileContent")]
    public IActionResult ReadFile([FromBody] FileRequest request)
    {
        if (string.IsNullOrWhiteSpace(request?.FilePath))
            return BadRequest("File path is required.");

        try
        {
            if (!System.IO.File.Exists(request.FilePath))
                return NotFound("File not found.");

            string content = System.IO.File.ReadAllText(request.FilePath);
            return Ok(content);
        }
        catch (UnauthorizedAccessException)
        {
            return StatusCode(403, "Access to the file is denied.");
        }
        catch (IOException ex)
        {
            return StatusCode(500, $"IO error: {ex.Message}");
        }
    }

}



