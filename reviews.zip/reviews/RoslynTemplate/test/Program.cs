﻿namespace test;

class Program
{
    static void Main(string[] args)
    {
        Int32 number1 = 1;
        Console.WriteLine("Hello, World!");
    }
}
