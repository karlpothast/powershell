using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using Automator.Connector;
using Automator.Properties;
using Automator.Utility;
using Automator.Videa;
using Patient = Automator.Dentrix.Patient;

namespace Automator.Controls
{
    /// <summary>
    /// Implementation of the Preview Panel.
    /// </summary>
    /// <seealso cref="System.Windows.Forms.UserControl" />
    public partial class PreviewPanel : UserControl
    {
        /// <summary>
        /// Gets the patient.
        /// </summary>
        /// <value>
        /// The patient.
        /// </value>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Patient Patient { get; set; }

        /// <summary>
        /// Gets the uncached previews visible in the preview panel.
        /// </summary>
        /// <value>
        /// The uncached previews.
        /// </value>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ConnectorAssetPair[] UncachedPreviews
        {
            get
            {
                ConnectorMetadata[] filteredMetadata = FilteredMetadata;    // Get the filtered metadata

                // Get a list of previews needed to update the current preview page
                List<ConnectorAssetPair> requestPairs = new List<ConnectorAssetPair>();

                if (IsModalityViewFilter)
                {
                    // Sync selected stack selected index
                    Stack selectedStack = GetSelectedStack();
                    if(selectedStack != null) selectedStack.SelectedIndex = PreviewPage - 1;

                    foreach (Stack stack in _stacks)
                    {
                        ConnectorMetadata metadata = stack.Metadata[stack.SelectedIndex];
                        var requestPair = new ConnectorAssetPair(metadata.ConnectorGuid, metadata.Guid);

                        if (!ConnectorManager.HasCachedPreview(requestPair)) requestPairs.Add(requestPair);
                    }
                }
                else
                    for (int i = (PreviewPage - 1) * ThumbsPerPage; i < Math.Min(PreviewPage * ThumbsPerPage, filteredMetadata.Length + _videaThumbnails.Length); i++)
                    {
                        if (i < _videaThumbnails.Length) continue;  // Nothing needed for a videa thumbnail

                        // Determine if the required preview has been cached - cached previews are retrieved on paint
                        int metadataIndex = i - _videaThumbnails.Length;
                        var requestPair = new ConnectorAssetPair(filteredMetadata[metadataIndex].ConnectorGuid, filteredMetadata[metadataIndex].Guid);

                        if (!ConnectorManager.HasCachedPreview(requestPair)) requestPairs.Add(requestPair);
                    }

                return requestPairs.ToArray();
            }
        }

        /// <summary>
        /// Gets the selected previews.
        /// </summary>
        /// <value>
        /// The selected previews.
        /// </value>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ConnectorAssetPair[] SelectedPreviews => _selectedPreviews.ToArray();

        /// <summary>
        /// Gets or sets a value indicating whether to use modality view.
        /// </summary>
        /// <value>
        ///   <c>true</c> to display images in modality view; otherwise, <c>false</c>.
        /// </value>
        public bool UseModalityView { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether to allow preview selection.
        /// </summary>
        /// <value>
        ///   <c>true</c> to allow preview selection; otherwise, <c>false</c>.
        /// </value>
        public bool AllowPreviewSelection { get; set; }

        /// <summary>
        /// Gets or sets the license manager.
        /// </summary>
        /// <value>
        /// The license manager.
        /// </value>
        private LicenseManager LicenseManager { get; set; }

        /// <summary>
        /// Gets or sets the connector manager.
        /// </summary>
        /// <value>
        /// The connector manager.
        /// </value>
        private ConnectorManager ConnectorManager { get; set; }

        /// <summary>
        /// Gets or sets the videa client.
        /// </summary>
        private VideaClient VideaClient { get; set; }

        /// <summary>
        /// Occurs when the panel requests uncached previews.
        /// </summary>
        public event EventHandler RequestUncachedPreviews;

        /// <summary>
        /// Occurs when preview pages are updated.
        /// </summary>
        public event EventHandler PreviewPagesUpdated;

        /// <summary>
        /// Occurs when a preview has been clicked.
        /// </summary>
        public event EventHandler<ConnectorAssetPair> PreviewClick;

        /// <summary>
        /// Occurs when a preview has been double clicked.
        /// </summary>
        public event EventHandler<ConnectorAssetPair> PreviewDoubleClick;

        /// <summary>
        /// Occurs when the panel background is clicked.
        /// </summary>
        public event EventHandler BackgroundClick;

        #region Thumbnail Properties/Fields

        /// <summary>
        /// The image size used for thumbnails.
        /// </summary>
        private readonly Size _thumbImageSize = new Size(160, 120);

        /// <summary>
        /// The image size used for videa thumbnails.
        /// </summary>
        private readonly Size _videaThumbImageSize = new Size(160, 135);

        /// <summary>
        /// Contains a cache of thumbnail paint rectangles for the current page - used to hit test.
        /// </summary>
        private readonly Dictionary<ConnectorAssetPair, Rectangle> _thumbRectCache = new Dictionary<ConnectorAssetPair, Rectangle>();

        /// <summary>
        /// Contains a cache of thumbnail image paint rectangles for the current page - used to hit test.
        /// </summary>
        private readonly Dictionary<ConnectorAssetPair, RectangleF> _thumbImageRectCache = new Dictionary<ConnectorAssetPair, RectangleF>();

        /// <summary>
        /// The selected previews.
        /// </summary>
        private readonly List<ConnectorAssetPair> _selectedPreviews = new List<ConnectorAssetPair>();

        /// <summary>
        /// The border size for thumbnails.
        /// </summary>
        private readonly int _thumbBorderSize = 2;

        /// <summary>
        /// The height of the header area in a thumbnail.
        /// </summary>
        private readonly int _thumbHeaderHeight = 15;

        /// <summary>
        /// The height of the footer area in a thumbnail.
        /// </summary>
        private readonly int _thumbFooterHeight = 15;

        /// <summary>
        /// The spacing between thumbnails.
        /// </summary>
        private readonly Size _thumbSpacing = new Size(2, 4);

        /// <summary>
        /// The calculated number of thumbnails to paint on the x axis.
        /// </summary>
        private int _thumbsX;

        /// <summary>
        /// The calculated number of thumbnails to paint on the y axis.
        /// </summary>
        private int _thumbsY;

        /// <summary>
        /// The stacks of images when in modality view.
        /// </summary>
        private readonly List<Stack> _stacks = new List<Stack>();

        /// <summary>
        /// The connector and asset guid of the current thumbnail that the mouse has hovered over.
        /// </summary>
        private ConnectorAssetPair _thumbHoverPair = ConnectorAssetPair.Empty;

        /// <summary>
        /// The connector and asset guid of the thumbnail that was clicked.
        /// </summary>
        private ConnectorAssetPair _thumbClickPair = ConnectorAssetPair.Empty;

        /// <summary>
        /// The mouse click point.
        /// </summary>
        private Point _mouseClickPoint = Point.Empty;

        /// <summary>
        /// Gets the size of a thumbnail including the image, border and footer.
        /// </summary>
        /// <value>
        /// The size of the thumbnail.
        /// </value>
        private Size ThumbSize => new Size(_thumbImageSize.Width + _thumbBorderSize * 2, _thumbImageSize.Height + _thumbFooterHeight + _thumbBorderSize * 2);

        /// <summary>
        /// The thumbs per page.
        /// </summary>
        private int ThumbsPerPage => _thumbsX * _thumbsY;

        /// <summary>
        /// Gets or sets the preview page.
        /// </summary>
        /// <value>
        /// The preview page.
        /// </value>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int PreviewPage { get; set; }

        /// <summary>
        /// Gets the total pages.
        /// </summary>
        /// <value>
        /// The total pages.
        /// </value>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int TotalPages { get; private set; }

        #endregion

        #region Preview Filter Properties

        /// <summary>
        /// Gets or sets the filter categories.
        /// </summary>
        /// <value>
        /// The filter categories.
        /// </value>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public AssetCategory[] FilterCategories { get; set; } = {AssetCategory.IntraoralXray, AssetCategory.IntraoralColor, AssetCategory.ExtraoralXray, AssetCategory.ExtraoralColor, AssetCategory.ThreeDeeModel, AssetCategory.ThreeDeeVolume, AssetCategory.Other};

        /// <summary>
        /// Gets or sets the filter start date.
        /// </summary>
        /// <value>
        /// The filter start date.
        /// </value>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DateTime FilterStartDate { get; set; } = DateTime.MaxValue;

        /// <summary>
        /// Gets or sets the filter end date.
        /// </summary>
        /// <value>
        /// The filter end date.
        /// </value>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DateTime FilterEndDate { get; set; } = DateTime.MinValue;

        /// <summary>
        /// Gets or sets the filter connector.
        /// </summary>
        /// <value>
        /// The filter connector.
        /// </value>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string FilterConnector { get; set; }

        /// <summary>
        /// Gets or sets the AI filter.
        /// </summary>
        /// <value>
        /// The AI filter.
        /// </value>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool FilterAI { get; set; }

        /// <summary>
        /// Determines whether modality view is enabled and the filter is set to a valid mode to use modality view.
        /// </summary>
        /// <returns>
        ///   <c>true</c> if modality view should be used; otherwise, <c>false</c>.
        /// </returns>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsModalityViewFilter => UseModalityView && FilterCategories.Length == 1 && (FilterCategories[0] == AssetCategory.IntraoralXray || FilterCategories[0] == AssetCategory.IntraoralColor);

        /// <summary>
        /// Gets the metadata for previews filtered to the user selection.
        /// </summary>
        /// <value>
        /// The filtered metadata.
        /// </value>
        private ConnectorMetadata[] FilteredMetadata
        {
            get
            {
                if (ConnectorManager == null) return Array.Empty<ConnectorMetadata>();

                // Get the filtered metadata
                ConnectorMetadata[] filteredMetadata = ConnectorManager.ConnectorMetadata.Where(m => m.Categories.Intersect(FilterCategories).Any() && m.AcquisitionDate <= FilterStartDate && m.AcquisitionDate >= FilterEndDate)
                    .OrderByDescending(m => m.AcquisitionDate)
                    .ToArray();

                // Filter by connector
                if (!string.IsNullOrEmpty(FilterConnector))
                    filteredMetadata = filteredMetadata.Where(m => m.ConnectorGuid == FilterConnector).ToArray();

                // Filter by AI
                if (FilterAI && VideaClient != null)
                {
                    ConnectorMetadata[] aiMetadata = filteredMetadata.Where(m => VideaClient.HasCachedAnalysis(new ConnectorAssetPair(m.ConnectorGuid, m.Guid))).ToArray();
                    filteredMetadata = filteredMetadata.Where(m => aiMetadata.Contains(m) || m.IsAssetViewset && aiMetadata.Any(ai => m.ConnectorGuid == ai.ConnectorGuid && m.AssetGuids.Contains(ai.Guid))).ToArray();    // Retain viewsets
                }

                // For modality mode filter out viewsets - otherwise we will filter out assets in viewsets
                if (IsModalityViewFilter) return filteredMetadata.Where(m => m.IsAssetViewset == false).ToArray();

                // Collect a list of all asset pairs that are contained in viewsets
                List<ConnectorAssetPair> assetsInViewsets = new List<ConnectorAssetPair>();

                foreach (ConnectorMetadata metadata in filteredMetadata)
                    if (metadata.IsAssetViewset)
                        assetsInViewsets.AddRange(metadata.AssetGuids.Select(guid => new ConnectorAssetPair(metadata.ConnectorGuid, guid)));

                // Filter our array by removing any assets contained in a viewset
                return filteredMetadata.Where(m => !assetsInViewsets.Contains(new ConnectorAssetPair(m.ConnectorGuid, m.Guid))).ToArray();
            }
        }

        #endregion

        /// <summary>
        /// The refresh timer interval.
        /// </summary>
        private readonly int _refreshTimerInterval;

        /// <summary>
        /// The videa thumbnails.
        /// </summary>
        private VideaThumbnail[] _videaThumbnails = Array.Empty<VideaThumbnail>();

        /// <summary>
        /// Initializes a new instance of the <see cref="PreviewPanel"/> class.
        /// </summary>
        public PreviewPanel()
        {
            InitializeComponent();

            // Use reflection to set the DoubleBuffered property of the preview panel to true
            typeof(PreviewPanel).InvokeMember("DoubleBuffered", BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic, null, this, new object[] {true});

            timerClick.Interval = SystemInformation.DoubleClickTime; // Set the timer interval to the maximum amount of time allowed for a double click
            timerRefresh.Interval = _refreshTimerInterval = AutomatorSettings.PreviewRefreshTimeout; // Set the refresh timer interval from settings
        }

        /// <summary>
        /// Initializes the preview panel.
        /// </summary>
        /// <param name="licenseManager">The license manager.</param>
        /// <param name="connectorManager">The connector manager.</param>
        /// <param name="videaClient">The videa client.</param>
        public void InitializePreviewPanel(LicenseManager licenseManager, ConnectorManager connectorManager, VideaClient videaClient)
        {
            LicenseManager = licenseManager;
            ConnectorManager = connectorManager;
            VideaClient = videaClient;

            connectorManager.MetadataReady += ConnectorManager_MetadataReady;
            connectorManager.MetadataComplete += ConnectorManager_MetadataComplete;
            connectorManager.PreviewReady += ConnectorManager_PreviewReady;
            connectorManager.PreviewsComplete += ConnectorManager_PreviewsComplete;
        }

        /// <summary>
        /// Sets the videa thumbnails.
        /// </summary>
        /// <param name="videaThumbnails">The videa thumbnails.</param>
        public void SetVideaThumbnails(VideaThumbnail[] videaThumbnails)
        {
            if (AutomatorSettings.VideaShowThumbnails == false) return; // Not adding any Videa thumbnails

            _videaThumbnails = videaThumbnails;
            Refresh();  // Repaint
        }

        /// <summary>
        /// Deselects a preview.
        /// </summary>
        /// <param name="pair">The pair.</param>
        public void DeselectPreview(ConnectorAssetPair pair)
        {
            if (_selectedPreviews.Contains(pair)) _selectedPreviews.Remove(pair);
        }

        /// <summary>
        /// Selects a preview.
        /// </summary>
        /// <param name="pair">The pair.</param>
        public void SelectPreview(ConnectorAssetPair pair)
        {
            if (!_selectedPreviews.Contains(pair)) _selectedPreviews.Add(pair);
        }

        /// <summary>
        /// Clears the preview selection.
        /// </summary>
        public void ClearPreviewSelection()
        {
            _selectedPreviews.Clear();
        }

        #region Connector Code

        /// <summary>
        /// Handles the MetadataReady event of the _connectorManager control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="ConnectorMetadata"/> instance containing the event data.</param>
        private void ConnectorManager_MetadataReady(object sender, ConnectorMetadata e)
        {
            Invalidate();  // Show any loading messages, etc
        }

        /// <summary>
        /// Handles the MetadataComplete event of the _connectorManager control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">if set to <c>true</c> then the metadata has changed.</param>
        private void ConnectorManager_MetadataComplete(object sender, bool e)
        {
            if (e)
            {
                // Metadata has changed
                UpdatePreviewPages(); // Update the preview page count and invalidate the preview panel
                RequestUncachedPreviews?.Invoke(this, EventArgs.Empty);
                Update(); // Finish any painting
            }
            else
                Refresh(); // Repaint the panel (May go from Loading.. to No images., etc)
        }

        /// <summary>
        /// Handles the PreviewReady event of the _connectorManager control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="ConnectorPreview"/> instance containing the event data.</param>
        private void ConnectorManager_PreviewReady(object sender, ConnectorPreview e)
        {
            Invalidate(); // Invalidate the panel
        }

        /// <summary>
        /// Handles the PreviewsComplete event of the _connectorManager control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void ConnectorManager_PreviewsComplete(object sender, EventArgs e)
        {
            Refresh(); // Repaint the panel (May go from Loading.. to No images., etc)
        }

        #endregion

        /// <summary>
        /// Updates the number preview pages and invalidates the preview panel.
        /// </summary>
        public void UpdatePreviewPages()
        {
            ConnectorMetadata[] filteredMetadata = FilteredMetadata; // Get the filtered metadata

            _stacks.Clear();

            if (IsModalityViewFilter)
            {
                // Reset the page values
                _thumbsX = 0;
                _thumbsY = 0;
                PreviewPage = 0;
                TotalPages = 0;

                // Calculate stacks
                int[] threeAnterior = { 0, 125, 125, 125, 250, 250, 250, 410, 530, 530, 530, 720, 840, 840, 840, 840 };
                bool[] threeAnteriorOffset = { false, true, true, true, false, false, false, true, false, false, false, true, false, false, false, false };
                int[] fiveAnterior = { 0, 100, 100, 200, 200, 400, 400, 400, 625, 625, 625, 625, 875, 875, 875, 875 };
                bool[] fiveAnteriorOffset = { false, true, true, false, false, false, false, false, false, false, false, false, false, false, false, false };

                int[] positions = AutomatorSettings.UseFiveAnteriorPositioning ? fiveAnterior : threeAnterior;
                bool[] offsets = AutomatorSettings.UseFiveAnteriorPositioning ? fiveAnteriorOffset : threeAnteriorOffset;

                foreach (var metadata in filteredMetadata)
                {
                    // Convert teeth for the image into coordinates and determine the top left and bottom right
                    ToothUtility.TeethToCoordinates(metadata.ToothNumbers, out Point? topLeft, out Point? bottomRight, out _, out _);

                    // Calculate combined x,y position - x value indicates left or right of center (+ or -) or center (0) and what index to use, y indicates top/middle/bottom of mouth (clamped to -1,0,1)
                    Point position = bottomRight.HasValue && topLeft.HasValue ?
                        new Point(topLeft.Value.X + bottomRight.Value.X, Math.Max(-1, Math.Min(1, topLeft.Value.Y + bottomRight.Value.Y))) :
                        new Point(0, 0);   // Invalid/no teeth will be centered

                    // Update offset and position with percentage value for the x coordinate
                    bool offset = false;
                    if (position.X > 0)
                    {
                        offset = offsets[position.X - 1];
                        position.X = positions[position.X - 1];
                    }
                    else if (position.X < 0)
                    {
                        offset = offsets[-position.X - 1];
                        position.X = -positions[-position.X - 1];
                    }

                    // Update the stack
                    Stack stack = _stacks.FirstOrDefault(s => s.Position == position);
                    if (stack == null)
                    {
                        stack = new Stack {  Position = position, Offset = offset, SelectedIndex = 0, Metadata = new List<ConnectorMetadata> { metadata } };
                        _stacks.Add(stack);
                    }
                    else
                        stack.Metadata.Add(metadata);
                }

                // Find the stack with the selected preview and update it along with page information
                Stack selectedStack = UpdateStacksSelectedIndices();
                if(selectedStack != null)
                {
                    PreviewPage = selectedStack.SelectedIndex + 1;
                    TotalPages = selectedStack.Metadata.Count;
                }
            }
            else
            {
                int thumbnailCount = filteredMetadata.Length + _videaThumbnails.Length;

                if (thumbnailCount == 0)
                {
                    // Reset the page values
                    _thumbsX = 0;
                    _thumbsY = 0;
                    PreviewPage = 0;
                    TotalPages = 0;
                }
                else
                {
                    // Calculate the number of thumbnails per x and y axis with a minimum of one
                    _thumbsX = Math.Max(ClientSize.Width / ThumbSize.Width, 1);
                    if (ClientSize.Width < _thumbsX * ThumbSize.Width + (_thumbsX - 1) * _thumbSpacing.Width)
                        _thumbsX = Math.Max(_thumbsX - 1, 1); // Determine if the value will fit the ClientRectangle with spacing between the thumbnails

                    _thumbsY = Math.Max(ClientSize.Height / ThumbSize.Height, 1);
                    if (ClientSize.Height < _thumbsY * ThumbSize.Height + (_thumbsY - 1) * _thumbSpacing.Height)
                        _thumbsY = Math.Max(_thumbsY - 1, 1); // Determine if the value will fit the ClientRectangle with spacing between the thumbnails

                    // Reset the page values
                    PreviewPage = 1;
                    TotalPages = (int)Math.Ceiling((decimal)thumbnailCount / ThumbsPerPage);
                }
            }

            Invalidate(); // Paint the thumbnails

            PreviewPagesUpdated?.Invoke(this, EventArgs.Empty);
        }

        #region Thumbnail Paint Code

        /// <summary>
        /// Handles the Paint event of the PreviewPanel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="PaintEventArgs"/> instance containing the event data.</param>
        private void PreviewPanel_Paint(object sender, PaintEventArgs e)
        {
            if (LicenseManager == null || ConnectorManager == null) return; // Not initialized

            PaintUtility.SetHighQualityPaint(e.Graphics); // Set up the graphics object

            _thumbRectCache.Clear(); // Clear the rectangle caches
            _thumbImageRectCache.Clear();

            // Draw the panel
            if (!LicenseManager.IsUserLicensed && LicenseManager.IsValidating)
                PaintUtility.DrawTextInsideControl(e.Graphics, this, Resources.StringLicenseCheck); // Checking for license
            else if (!LicenseManager.IsUserLicensed)
                PaintUtility.DrawBitmapInsideRectangle(e.Graphics, Resources.SmartImageUnlicensed, Resources.SmartImageUnlicensedAlt, ClientRectangle); // No user license
            else if (!ConnectorManager.AreConnectorsLoaded && ConnectorManager.IsLoadingConnectors)
                PaintUtility.DrawTextInsideControl(e.Graphics, this, Resources.StringLoadingConnectors);    // Loading connectors
            else if (!ConnectorManager.AreConnectorsLoaded)
                PaintUtility.DrawBitmapInsideRectangle(e.Graphics, Resources.SmartImageNotice, Resources.SmartImageNoticeAlt, ClientRectangle); // No connectors loaded
            else if (Patient == null)
                PaintUtility.DrawTextInsideControl(e.Graphics, this, Resources.StringNoPatientSelected); // No patient selected
            else if (ConnectorManager.IsMetadataRequested && ConnectorManager.ConnectorMetadata.Length == 0)
                PaintUtility.DrawTextInsideControl(e.Graphics, this, Resources.StringLoadingPreviewData); // Loading metadata
            else if (ConnectorManager.ConnectorMetadata.Length == 0)
                PaintUtility.DrawTextInsideControl(e.Graphics, this, Resources.StringNoImages); // No Images
            else
            {
                if (IsModalityViewFilter)
                {
                    if (_stacks.Count == 0)
                        PaintUtility.DrawTextInsideControl(e.Graphics, this, Resources.StringNoFilteredImages); // No images match filter
                    else
                    {
                        // Draw stacks
                        const float maxAspect = 2.0F / 1.0F;
                        const float minAspect = 4.0F / 3.0F;

                        PointF thumbOffset = new PointF(2.0F, 4.0F);

                        // Clamp the layout area between aspect ratios
                        RectangleF modalityRect = new RectangleF(thumbOffset.X, thumbOffset.Y, ClientSize.Width - thumbOffset.X, ClientSize.Height - thumbOffset.Y);
                        if (modalityRect.Width / modalityRect.Height > maxAspect)
                            modalityRect.Width = modalityRect.Height * maxAspect;
                        else if (modalityRect.Width / modalityRect.Height < minAspect)
                            modalityRect.Height = modalityRect.Width / minAspect;

                        float maxThumbnailWidth = AutomatorSettings.UseFiveAnteriorPositioning ? modalityRect.Width * 0.11F : modalityRect.Width * 0.14F;

                        // Create a stack list sorted for z-order
                        List<Stack> sortedStacks = new List<Stack>();
                        Stack selectedStack = GetSelectedStack();

                        sortedStacks.AddRange(_stacks.Where(s => s.Offset && s != selectedStack));
                        sortedStacks.AddRange(_stacks.Where(s => !s.Offset && s != selectedStack));
                        if(selectedStack != null) sortedStacks.Add(selectedStack);

                        foreach (Stack stack in sortedStacks)
                        {
                            ConnectorMetadata metadata = stack.Metadata[stack.SelectedIndex];

                            // Calculate rectangle
                            float xCenter = modalityRect.X + modalityRect.Width / 2.0F;   // Start in the center
                            if (stack.Position.X != 0) xCenter += stack.Position.X / 1000F * (modalityRect.Width / 2.0F);

                            ConnectorAssetPair requestPair = new ConnectorAssetPair(metadata.ConnectorGuid, metadata.Guid);
                            ConnectorPreview preview = ConnectorManager.GetCachedPreview(requestPair); // Find the matching preview if it has been loaded

                            SizeF previewSize = preview?.PreviewImage?.Size ?? (Math.Abs(stack.Position.X) < 500 ? new Size(455, 640) : new Size(640, 455));

                            // Calculate the thumbnail rectangle
                            float ratio = previewSize.Width / previewSize.Height;
                            SizeF destSize = previewSize.Width > previewSize.Height ?
                                new SizeF(maxThumbnailWidth, maxThumbnailWidth / ratio) :
                                new SizeF(maxThumbnailWidth * ratio, maxThumbnailWidth);

                            destSize.Width += _thumbBorderSize * 2; // Add width for the border
                            destSize.Height += _thumbBorderSize * 2 + _thumbHeaderHeight;  // Add height for the border and header

                            PointF destLocation = new PointF(xCenter - destSize.Width / 2, modalityRect.Y); // Upper
                            if (stack.Position.Y > 0)
                                destLocation.Y += modalityRect.Height - destSize.Height; // Lower
                            else if (stack.Position.Y == 0)
                                destLocation.Y += modalityRect.Height / 2.0F - destSize.Height / 2.0F; // Center

                            if (stack.Offset)
                            {
                                if (stack.Position.Y < 0)
                                    destLocation.Y += _thumbHeaderHeight;   // Upper
                                else
                                    destLocation.Y -= _thumbHeaderHeight;   // Lower or Center
                            }

                            RectangleF destRect = new RectangleF(destLocation, destSize);

                            _thumbRectCache.Add(new ConnectorAssetPair(metadata.ConnectorGuid, metadata.Guid), Rectangle.Truncate(destRect)); // Add the rectangle to the cache and paint
                            DrawStackThumbInPreviewPanel(destRect, metadata, preview, stack.Metadata.Count, e.Graphics);
                        }
                    }
                }
                else
                {
                    ConnectorMetadata[] metadata = FilteredMetadata; // Get the filtered metadata

                    if (metadata.Length == 0)
                        PaintUtility.DrawTextInsideControl(e.Graphics, this, Resources.StringNoFilteredImages); // No images match filter
                    else
                    {
                        // Draw thumbnails!
                        SizeF thumbsOffset = new SizeF((ClientRectangle.Width - _thumbsX * ThumbSize.Width - (_thumbsX - 1) * _thumbSpacing.Width) / 2.0F, (ClientRectangle.Height - ThumbSize.Height * _thumbsY) / 2.0F);
                        PointF thumbTopLeft = new PointF(ClientRectangle.X + thumbsOffset.Width, ClientRectangle.Y + thumbsOffset.Height);

                        // Draw each thumbnail
                        for (int i = (PreviewPage - 1) * ThumbsPerPage; i < Math.Min(PreviewPage * ThumbsPerPage, metadata.Length + _videaThumbnails.Length); i++)
                        {
                            if (i < _videaThumbnails.Length)
                            {
                                _thumbRectCache.Add(new ConnectorAssetPair("VideaThumbnail", i.ToString(CultureInfo.InvariantCulture)), new Rectangle(Point.Truncate(thumbTopLeft), ThumbSize)); // Add the rectangle to the cache and paint
                                DrawThumbInPreviewPanel(thumbTopLeft, i, e.Graphics);
                            }
                            else
                            {
                                int metadataIndex = i - _videaThumbnails.Length;
                                ConnectorAssetPair requestPair = new ConnectorAssetPair(metadata[metadataIndex].ConnectorGuid, metadata[metadataIndex].Guid);
                                ConnectorPreview preview = ConnectorManager.GetCachedPreview(requestPair); // Find the matching preview if it has been loaded

                                _thumbRectCache.Add(new ConnectorAssetPair(metadata[metadataIndex].ConnectorGuid, metadata[metadataIndex].Guid), new Rectangle(Point.Truncate(thumbTopLeft), ThumbSize)); // Add the rectangle to the cache and paint
                                DrawThumbInPreviewPanel(thumbTopLeft, metadata[metadataIndex], preview, e.Graphics);
                            }

                            thumbTopLeft.X += ThumbSize.Width + _thumbSpacing.Width; // Increment the origin point x

                            // Check the origin point and if we are the end of the row reset the x and increment the y
                            if (thumbTopLeft.X >= ClientRectangle.X + _thumbsX * ThumbSize.Width + (_thumbsX - 1) * _thumbSpacing.Width)
                            {
                                thumbTopLeft.X = ClientRectangle.X + thumbsOffset.Width;
                                thumbTopLeft.Y += ThumbSize.Height + _thumbSpacing.Height;
                            }
                        }
                    }
                }
            }

            if (!_thumbRectCache.ContainsKey(_thumbHoverPair)) _thumbHoverPair = ConnectorAssetPair.Empty; // If the cache rect no longer contains the hover pair then reset it
        }

        /// <summary>
        /// Draws a thumbnail in the preview panel.
        /// </summary>
        /// <param name="pt">The thumbnail origin point.</param>
        /// <param name="videaThumbnailIndex">Index of the videa thumbnail.</param>
        /// <param name="g">The graphics object.</param>
        private void DrawThumbInPreviewPanel(PointF pt, int videaThumbnailIndex, Graphics g)
        {
            VideaThumbnail videaThumbnail = _videaThumbnails[videaThumbnailIndex];
            ConnectorAssetPair thumbPair = new ConnectorAssetPair("VideaThumbnail", videaThumbnailIndex.ToString(CultureInfo.InvariantCulture));

            // Draw the thumbnail
            float ratio = PaintUtility.CalculateZoomToFitRatio(videaThumbnail.Thumbnail.Size, _videaThumbImageSize);
            SizeF imageSize = new SizeF(videaThumbnail.Thumbnail.Width * ratio, videaThumbnail.Thumbnail.Height * ratio);

            RectangleF destRect = new RectangleF(pt.X + _thumbBorderSize + (_videaThumbImageSize.Width - imageSize.Width) / 2.0F,
                pt.Y + _thumbBorderSize + (_videaThumbImageSize.Height - imageSize.Height) / 2.0F,
                imageSize.Width, imageSize.Height);

            g.DrawImage(videaThumbnail.Thumbnail, destRect);

            // Draw the border
            bool hoverBorder = _thumbHoverPair != ConnectorAssetPair.Empty && _thumbHoverPair.ConnectorGuid == thumbPair.ConnectorGuid && _thumbHoverPair.AssetGuid == thumbPair.AssetGuid;
            bool selectedBorder = _selectedPreviews.Contains(thumbPair);

            Color borderColor = hoverBorder || selectedBorder ? Color.Gold : Color.FromArgb(68, 152, 216); // Determine if we are hovering over this thumbnail

            using (Pen p = new Pen(borderColor, _thumbBorderSize))
                g.DrawRectangle(p, pt.X, pt.Y, ThumbSize.Width - p.Width, ThumbSize.Height - p.Width);
        }

        /// <summary>
        /// Draws a thumbnail in the preview panel.
        /// </summary>
        /// <param name="pt">The thumbnail origin point.</param>
        /// <param name="metadata">The asset metadata.</param>
        /// <param name="preview">The preview data.</param>
        /// <param name="g">The graphics object.</param>
        private void DrawThumbInPreviewPanel(PointF pt, ConnectorMetadata metadata, ConnectorPreview preview, Graphics g)
        {
            ConnectorAssetPair thumbPair = new ConnectorAssetPair(metadata.ConnectorGuid, metadata.Guid);

            // Draw the footer
            DateTime acquisitionDate = metadata.AcquisitionDate.ToLocalTime();
            string footer;
            if(metadata.IsAssetViewset || metadata.ToothNumbers.Length == 0)
                footer = $"{acquisitionDate.ToShortDateString()} {acquisitionDate.ToShortTimeString()}";
            else
                footer = $"{acquisitionDate.ToShortDateString()} #{ToothUtility.GetStringForTeeth(metadata.ToothNumbers, AutomatorSettings.UseInternationalToothNotation)}";

            RectangleF strRect = new RectangleF(pt.X, pt.Y + _thumbBorderSize + _thumbImageSize.Height, ThumbSize.Width, _thumbFooterHeight);

            using (var strFormat = new StringFormat())
            {
                strFormat.Alignment = StringAlignment.Center;
                strFormat.LineAlignment = StringAlignment.Center;
                strFormat.Trimming = StringTrimming.EllipsisCharacter;

                g.DrawString(footer, Font, Brushes.White, strRect, strFormat);
            }

            if (preview?.PreviewImage == null)
            {
                // Draw either the loading string or could not load error
                string str = preview == null && !ConnectorManager.AreConnectorsIdle ? Resources.StringLoading : Resources.StringCouldNotLoadError;
                SizeF strSize = g.MeasureString(str, Font);

                g.DrawString(str,
                    Font,
                    Brushes.White,
                    pt.X + (ThumbSize.Width - strSize.Width) / 2.0F,
                    pt.Y + _thumbBorderSize + (_thumbImageSize.Height - strSize.Height) / 2.0F);
            }
            else
            {
                // Draw the thumbnail
                float ratio = PaintUtility.CalculateZoomToFitRatio(preview.PreviewImage.Size, _thumbImageSize);
                SizeF imageSize = new SizeF(preview.PreviewImage.Width * ratio, preview.PreviewImage.Height * ratio);

                RectangleF destRect = new RectangleF(pt.X + _thumbBorderSize + (_thumbImageSize.Width - imageSize.Width) / 2.0F,
                    pt.Y + _thumbBorderSize + (_thumbImageSize.Height - imageSize.Height) / 2.0F,
                    imageSize.Width, imageSize.Height);

                _thumbImageRectCache.Add(thumbPair, destRect);
                g.DrawImage(preview.PreviewImage, destRect);
            }

            // Draw the AI overlay
            if(VideaClient != null)
            {
                bool drawOverlay = false;
                int numFindings = 0;

                if (metadata.IsAssetViewset)
                {
                    foreach(string guid in metadata.AssetGuids)
                    {
                        var assetPair = new ConnectorAssetPair(metadata.ConnectorGuid, guid);
                        if (VideaClient.HasCachedAnalysis(assetPair))
                        {
                            drawOverlay = true;

                            AIAnalysisOnImage analysis = VideaClient.GetCachedAnalysis(assetPair);
                            numFindings += VideaHelper.GetFindingsCount(analysis);
                        }
                    }
                }
                else if(VideaClient.HasCachedAnalysis(thumbPair))
                {
                    drawOverlay = true;

                    AIAnalysisOnImage analysis = VideaClient.GetCachedAnalysis(thumbPair);
                    numFindings = VideaHelper.GetFindingsCount(analysis);
                }

                if (drawOverlay)
                {
                    string findingsString = numFindings > 0 ? $"{numFindings}" : string.Empty;
                    SizeF strSize = g.MeasureString(findingsString, Font);
                    
                    //RectangleF destRect = new RectangleF(pt.X + (ThumbSize.Width - Resources.VideaBlue.Width - strSize.Width) / 2.0F, pt.Y, Resources.VideaBlue.Width + strSize.Width, Resources.VideaBlue.Height);
                    RectangleF destRect = new RectangleF(pt.X + (ThumbSize.Width - Resources.VideaBlue.Width - 2), pt.Y + (ThumbSize.Height - Resources.VideaBlue.Height - 2), Resources.VideaBlue.Width, Resources.VideaBlue.Height);                    

                    using (Brush brush = new SolidBrush(Color.FromArgb(3, 73, 255))) g.FillRectangle(brush, destRect);
                    g.DrawImage(Resources.VideaBlue, destRect.Location);
                    g.DrawString(findingsString, Font, Brushes.White, destRect.X + Resources.VideaBlue.Width, destRect.Y + (Resources.VideaBlue.Height - strSize.Height) / 2.0F);
                }
            }

            // Draw the border
            bool hoverBorder = _thumbHoverPair != ConnectorAssetPair.Empty && _thumbHoverPair.ConnectorGuid == metadata.ConnectorGuid && _thumbHoverPair.AssetGuid == metadata.Guid;
            bool selectedBorder = _selectedPreviews.Contains(thumbPair);

            Color borderColor = hoverBorder || selectedBorder ? Color.Gold : Color.FromArgb(68, 152, 216); // Determine if we are hovering over this thumbnail

            using (Pen p = new Pen(borderColor, _thumbBorderSize))
                g.DrawRectangle(p, pt.X, pt.Y, ThumbSize.Width - p.Width, ThumbSize.Height - p.Width);
        }

        /// <summary>
        /// Draws a thumbnail in the preview panel.
        /// </summary>
        /// <param name="rect">The thumbnail rectangle.</param>
        /// <param name="metadata">The asset metadata.</param>
        /// <param name="preview">The preview data.</param>
        /// <param name="count">The count of images in the stack.</param>
        /// <param name="g">The graphics object.</param>
        private void DrawStackThumbInPreviewPanel(RectangleF rect, ConnectorMetadata metadata, ConnectorPreview preview, int count, Graphics g)
        {
            ConnectorAssetPair thumbPair = new ConnectorAssetPair(metadata.ConnectorGuid, metadata.Guid);

            // Fill the background to prevent overlap issues
            RectangleF destRect = new RectangleF(rect.X + _thumbBorderSize, rect.Y + _thumbBorderSize + _thumbHeaderHeight, rect.Width - _thumbBorderSize * 2, rect.Height - _thumbBorderSize * 2 - _thumbHeaderHeight);
            g.FillRectangle(Brushes.Black, rect);

            // Draw the header
            RectangleF headerRect = new RectangleF(rect.X + _thumbBorderSize, rect.Y + _thumbBorderSize, rect.Width - _thumbBorderSize * 2, _thumbHeaderHeight);

            if (metadata.ToothNumbers.Length != 0)
            {
                string toothHeader = string.Empty;
                ToothUtility.TeethToCoordinates(metadata.ToothNumbers, out _, out _, out int? topLeft, out int? bottomRight);

                if (topLeft.HasValue)
                {
                    toothHeader = ToothUtility.GetStringForTooth(topLeft.Value, AutomatorSettings.UseInternationalToothNotation);
                    if (bottomRight.HasValue && bottomRight.Value != topLeft.Value) toothHeader += "-" + ToothUtility.GetStringForTooth(bottomRight.Value, AutomatorSettings.UseInternationalToothNotation);
                }

                using (var strFormat = new StringFormat())
                {
                    strFormat.Alignment = StringAlignment.Far;
                    strFormat.LineAlignment = StringAlignment.Center;
                    strFormat.Trimming = StringTrimming.None;

                    g.DrawString(toothHeader, Font, Brushes.White, headerRect, strFormat);

                    // Measure the tooth range string and reduce the size of the header rectangle
                    SizeF strSize = g.MeasureString(toothHeader, Font, headerRect.Size, strFormat);
                    headerRect.Width -= strSize.Width;
                }
            }

            using (var strFormat = new StringFormat())
            {
                string dateHeader = metadata.AcquisitionDate.ToLocalTime().ToShortDateString();
                SizeF strSize = g.MeasureString(dateHeader, Font);

                if (strSize.Width >= headerRect.Width)
                {
                    // Get the pattern for short date and replace the four digit year value (if it exists) with a two digit year
                    string shortDatePattern = DateTimeFormatInfo.CurrentInfo.ShortDatePattern;
                    dateHeader = metadata.AcquisitionDate.ToLocalTime().ToString(shortDatePattern.Replace("yyyy", "yy"));
                }

                strFormat.Alignment = StringAlignment.Near;
                strFormat.LineAlignment = StringAlignment.Center;
                strFormat.Trimming = StringTrimming.Character;  // Allow trimming
                g.DrawString(dateHeader, Font, Brushes.White, headerRect, strFormat);
            }

            // Draw the thumbnail
            if (preview?.PreviewImage == null)
            {
                // Draw either the loading string or could not load error
                string str = preview == null && !ConnectorManager.AreConnectorsIdle ? Resources.StringLoading : Resources.StringCouldNotLoadError;

                using (var strFormat = new StringFormat())
                {
                    strFormat.Alignment = StringAlignment.Center;
                    strFormat.LineAlignment = StringAlignment.Center;
                    strFormat.Trimming = StringTrimming.EllipsisCharacter;

                    g.DrawString(str, Font, Brushes.White, destRect, strFormat);
                }
            }
            else
            {
                _thumbImageRectCache.Add(thumbPair, destRect);
                g.DrawImage(preview.PreviewImage, destRect);
            }

            // Draw the count indicator
            if(count > 1)
            {
                string countString =  $"{count}";
                SizeF strSize = g.MeasureString(countString, Font);

                destRect = new RectangleF(rect.X, rect.Bottom - _thumbBorderSize - strSize.Height, strSize.Width, strSize.Height);

                using (Brush brush = new SolidBrush(Color.Gold)) g.FillPolygon(brush, new[] { new PointF(destRect.Left, destRect.Bottom), new PointF(destRect.Right + destRect.Width, destRect.Bottom), new PointF(destRect.Left, destRect.Top - destRect.Height) });

                g.DrawString(countString, Font, Brushes.Black, destRect);
            }

            // Draw the AI overlay
            if (VideaClient != null && VideaClient.HasCachedAnalysis(thumbPair))
            {
                destRect = new RectangleF(rect.Right - _thumbBorderSize - Resources.VideaBlue.Width, rect.Bottom - _thumbBorderSize - Resources.VideaBlue.Height, Resources.VideaBlue.Width, Resources.VideaBlue.Height);
                g.DrawImage(Resources.VideaBlue, destRect.Location);
            }

            // Draw the border
            bool hoverBorder = _thumbHoverPair != ConnectorAssetPair.Empty && _thumbHoverPair.ConnectorGuid == metadata.ConnectorGuid && _thumbHoverPair.AssetGuid == metadata.Guid;
            bool selectedBorder = _selectedPreviews.Contains(thumbPair);

            Color borderColor = hoverBorder || selectedBorder ? Color.Gold : Color.Gray; // Determine if we are hovering over this thumbnail

            using (Pen p = new Pen(borderColor, _thumbBorderSize))
                g.DrawRectangle(p, rect.X, rect.Y, rect.Width - p.Width, rect.Height - p.Width);
        }

        /// <summary>
        /// Invalidates a thumbnail rectangle in the preview panel.
        /// </summary>
        /// <param name="rect">The rectangle.</param>
        private void InvalidatePreviewRect(Rectangle rect)
        {
            rect.Inflate(_thumbBorderSize / 2, _thumbBorderSize / 2);

            Invalidate(rect);
        }

        /// <summary>
        /// Handles the Resize event of the PreviewPanel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void PreviewPanel_Resize(object sender, EventArgs e)
        {
            UpdatePreviewPages();
            RequestUncachedPreviews?.Invoke(this, EventArgs.Empty);
        }

        #endregion

        #region Hit Test & Mouse Code

        /// <summary>
        /// Handles the MouseMove event of the PreviewPanel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="MouseEventArgs"/> instance containing the event data.</param>
        private void PreviewPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (_thumbRectCache.Any(t => t.Value.Contains(e.Location)))
            {
                // The cache has a rectangle that contains the cursor - get the pair for that rectangle
                ConnectorAssetPair newHoverPair = _thumbRectCache.Last(t => t.Value.Contains(e.Location)).Key;

                // Check to see if this guid is already the hover guid
                if (_thumbHoverPair != newHoverPair)
                {
                    if (_thumbHoverPair != ConnectorAssetPair.Empty && _thumbRectCache.ContainsKey(_thumbHoverPair)) InvalidatePreviewRect(_thumbRectCache[_thumbHoverPair]); // Invalidate the current thumbnail

                    _thumbHoverPair = newHoverPair;

                    if (_thumbHoverPair != ConnectorAssetPair.Empty && _thumbRectCache.ContainsKey(_thumbHoverPair)) InvalidatePreviewRect(_thumbRectCache[_thumbHoverPair]); // Invalidate the new thumbnail

                    Update(); // Repaint to clear the border
                }
            }
            else if (_thumbHoverPair != ConnectorAssetPair.Empty)
            {
                // The cache doesn't have a rectangle that contains the cursor but we do have a hover pair
                if(_thumbRectCache.ContainsKey(_thumbHoverPair)) InvalidatePreviewRect(_thumbRectCache[_thumbHoverPair]); // Invalidate the thumbnail
                _thumbHoverPair = ConnectorAssetPair.Empty; // Clear the selection

                Update(); // Repaint to clear the border
            }
        }

        /// <summary>
        /// Handles the MouseLeave event of the PreviewPanel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void PreviewPanel_MouseLeave(object sender, EventArgs e)
        {
            if (_thumbHoverPair == ConnectorAssetPair.Empty) return;

            if(_thumbRectCache.ContainsKey(_thumbHoverPair)) InvalidatePreviewRect(_thumbRectCache[_thumbHoverPair]); // Invalidate the thumbnail
            _thumbHoverPair = ConnectorAssetPair.Empty; // Clear the selection

            Update(); // Repaint to clear the border
        }

        /// <summary>
        /// Handles the MouseClick event of the PreviewPanel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="MouseEventArgs"/> instance containing the event data.</param>
        private void PreviewPanel_MouseClick(object sender, MouseEventArgs e)
        {
            if (ConnectorManager == null) return; // Not initialized

            // If no connectors are loaded we will launch the smart image website
            if (!ConnectorManager.AreConnectorsLoaded)
            {
                Process.Start(@"https://www.dentrix.com/smartimage");
                return;
            }

            // If the user is not using the left button then disregard
            if (e.Button != MouseButtons.Left) return;

            // If the user is not clicking a thumbnail then send the background click event
            if (!_thumbRectCache.Any(t => t.Value.Contains(e.Location)))
            {
                BackgroundClick?.Invoke(this, EventArgs.Empty);
                return;
            }

            _thumbClickPair = _thumbRectCache.Last(t => t.Value.Contains(e.Location)).Key; // Cache the pair

            // Add or remove the selection for non-modality view
            if (AllowPreviewSelection && !UseModalityView)
            {
                if (_selectedPreviews.Contains(_thumbClickPair))
                    _selectedPreviews.Remove(_thumbClickPair);
                else
                    _selectedPreviews.Add(_thumbClickPair);

                PreviewClick?.Invoke(this, _thumbClickPair);
                _thumbClickPair = ConnectorAssetPair.Empty;
            }
            else
            {
                _mouseClickPoint = e.Location;
                timerClick.Start(); // Start the timer - if the user does not click again in the allotted time then the operation is a single click
            }
        }

        /// <summary>
        /// Handles the MouseDoubleClick event of the PreviewPanel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="MouseEventArgs"/> instance containing the event data.</param>
        private void PreviewPanel_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (AllowPreviewSelection && !UseModalityView) return;   // No double click action if selection is allowed for non-modality view

            // If the user is not using the left button or is not clicking on a thumbnail then disregard
            if (e.Button != MouseButtons.Left || !_thumbRectCache.Any(t => t.Value.Contains(e.Location))) return;

            timerClick.Stop(); // The user has double clicked - stop the timer and perform the double click action

            if (AllowPreviewSelection && UseModalityView) SelectStack(_thumbClickPair); // Always select the stack on double click when in modality view

            if (_thumbClickPair.ConnectorGuid == "VideaThumbnail")
                StartHybridPanel(_thumbClickPair.AssetGuid);
            else
                PreviewDoubleClick?.Invoke(this, FindClickedAsset());   // Look for an asset inside of a viewset if available

            _thumbClickPair = ConnectorAssetPair.Empty;
        }

        /// <summary>
        /// Handles the Tick event of the timerClick control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void timerClick_Tick(object sender, EventArgs e)
        {
            timerClick.Stop(); // The user has clicked and not double clicked - stop the timer and perform the click action

            if(AllowPreviewSelection && UseModalityView && SelectStack(_thumbClickPair))
            {
                _thumbClickPair = ConnectorAssetPair.Empty;
                return; // First click action is just to select
            }

            if (_thumbClickPair.ConnectorGuid == "VideaThumbnail")
                StartHybridPanel(_thumbClickPair.AssetGuid);
            else
                PreviewClick?.Invoke(this, FindClickedAsset()); // Look for an asset inside of a viewset if available

            _thumbClickPair = ConnectorAssetPair.Empty;
        }

        /// <summary>
        /// Finds the clicked asset inside of a viewset if possible.
        /// </summary>
        /// <returns>The connector asset pair inside of a viewset or the clicked pair.</returns>
        private ConnectorAssetPair FindClickedAsset()
        {
            ConnectorAssetPair connectorAssetPair = _thumbClickPair;
            ConnectorMetadata metadata = ConnectorManager.ConnectorMetadata.FirstOrDefault(m => m.ConnectorGuid == connectorAssetPair.ConnectorGuid && m.Guid == connectorAssetPair.AssetGuid);
            ConnectorPreview preview = ConnectorManager.GetCachedPreview(_thumbClickPair); // Find the matching preview if it has been loaded

            if (metadata != null && preview?.AssetRects != null && _thumbImageRectCache.ContainsKey(_thumbClickPair))
            {
                Rectangle thumbRect = Rectangle.Round(_thumbImageRectCache[_thumbClickPair]);

                // Adjust the mouse click point to the preview viewset coordinate space
                float ratio = PaintUtility.CalculateZoomToFitRatio(thumbRect.Size, preview.ViewsetSize);
                float xOffset = (preview.ViewsetSize.Width - thumbRect.Width * ratio) / 2;
                float yOffset = (preview.ViewsetSize.Height - thumbRect.Height * ratio) / 2;

                Point location = Point.Round(new PointF((_mouseClickPoint.X - thumbRect.X) * ratio - xOffset, (_mouseClickPoint.Y - thumbRect.Y) * ratio - yOffset));

                // Hit test to find the clicked upon asset if any
                for(int i = 0; i < preview.AssetRects.Length; i++)
                    if (preview.AssetRects[i].Contains(location))
                    {
                        connectorAssetPair = new ConnectorAssetPair(metadata.ConnectorGuid, metadata.AssetGuids[i]);    // Use the clicked upon asset
                        break;
                    }
            }

            return connectorAssetPair;
        }

        /// <summary>
        /// Starts the hybrid panel.
        /// </summary>
        /// <param name="index">The index.</param>
        private void StartHybridPanel(string index)
        { 
            int videaThumbnailIndex = int.Parse(index);
            VideaThumbnail videaThumbnail = _videaThumbnails[videaThumbnailIndex];

            if (videaThumbnail.IsMarketingThumbnail)
                VideaClient.SubmitMarketingClick(videaThumbnail.ExternalImageId);
            else if (string.IsNullOrEmpty(videaThumbnail.ExternalImageId))
                VideaClient.SubmitUsageMetric("ADV_THUMBNAIL", "ADV_THUMBNAIL_CLICKED", "EXTERNAL_WINDOW", string.Empty, "SMART_IMAGE");
            else
                VideaClient.SubmitUsageMetric(videaThumbnail.ExternalImageId, "OPP_THUMBNAIL_CLICKED", "IMAGE_VIEWED_EMBEDDED", "VIEW_IN_EMBEDDED_WINDOW", "SMART_IMAGE");

            VideaClient.StartHybridPanel(videaThumbnail.ClickUrl);
        }

        #endregion

        #region Stack Helpers

        /// <summary>
        /// Updates the stack selected index and selected asset to match the preview page.
        /// </summary>
        public void UpdateStackSelectedAsset()
        {
            // Find the stack with the current selected preview and update it along with the new selected preview
            Stack selectedStack = GetSelectedStack();
            if (selectedStack == null) return;

            selectedStack.SelectedIndex = PreviewPage - 1;  // Update the selected index to match the preview page
            
            var selectedMetadata = selectedStack.Metadata[selectedStack.SelectedIndex];
            _selectedPreviews[0] = new ConnectorAssetPair(selectedMetadata.ConnectorGuid, selectedMetadata.Guid); // Update the selected preview
        }

        /// <summary>
        /// Updates the stacks selected indices after new stack creation.
        /// </summary>
        /// <returns>The selected stack.</returns>
        private Stack UpdateStacksSelectedIndices()
        {
            foreach (Stack stack in _stacks) stack.SelectedIndex = 0;   // Reset all stack indices

            if (_selectedPreviews.Count == 0) return null;  // No selected stack

            ConnectorAssetPair selectedPair = _selectedPreviews[0];
            Stack selectedStack = _stacks.FirstOrDefault(s => s.Metadata.Any(m => m.ConnectorGuid == selectedPair.ConnectorGuid && m.Guid == selectedPair.AssetGuid));
            if (selectedStack == null)
                _selectedPreviews.Clear();  // Stacks no longer contain the selected preview
            else
            {
                int selectedIndex = selectedStack.Metadata.FindIndex(m => m.ConnectorGuid == selectedPair.ConnectorGuid && m.Guid == selectedPair.AssetGuid);
                selectedStack.SelectedIndex = selectedIndex;    // Update the selected stack index
            }

            return selectedStack;
        }

        /// <summary>
        /// Selects the stack - for use after clicking.
        /// </summary>
        /// <param name="pair">The connector asset pair.</param>
        /// <returns>True if a new stack was selected.</returns>
        private bool SelectStack(ConnectorAssetPair pair)
        {
            if (_selectedPreviews.Contains(pair)) return false;

            if (_selectedPreviews.Count != 0)
            {
                ConnectorAssetPair selectedPair = _selectedPreviews[0];
                if (_thumbRectCache.TryGetValue(selectedPair, out var selectedPairRect)) InvalidatePreviewRect(selectedPairRect);
                _selectedPreviews.Clear();  // Only allow single selection for modality view
            }

            if (_thumbRectCache.TryGetValue(pair, out var pairRect)) InvalidatePreviewRect(pairRect);
            _selectedPreviews.Add(pair);

            Update();   // Repaint to clear the border

            // Update the preview pages
            Stack selectedStack = GetSelectedStack();
            if (selectedStack != null)
            {
                PreviewPage = selectedStack.SelectedIndex + 1;
                TotalPages = selectedStack.Metadata.Count;

                PreviewPagesUpdated?.Invoke(this, EventArgs.Empty);
            }

            return true;
        }

        /// <summary>
        /// Gets the selected stack.
        /// </summary>
        /// <returns>The selected stack or null if none are selected.</returns>
        private Stack GetSelectedStack()
        {
            if (_selectedPreviews.Count == 0) return null;

            ConnectorAssetPair selectedPair = _selectedPreviews[0];
            return _stacks.FirstOrDefault(s => s.Metadata.Any(m => m.ConnectorGuid == selectedPair.ConnectorGuid && m.Guid == selectedPair.AssetGuid));
        }

        #endregion

        /// <summary>
        /// Handles the Tick event of the timerRefresh control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void timerRefresh_Tick(object sender, EventArgs e)
        {
            if (ConnectorManager == null) return; // Not initialized

            bool isAIAvailable = VideaClient != null && VideaClient.IsAIAvailable;  // We want to pull in new images when AI is available even if the panel is not visible

            if ((!Visible && !isAIAvailable) || !User32.IsApplicationActivated())
            {
                if (timerRefresh.Interval != 2000) timerRefresh.Interval = 2000; // Switch to a short interval so we update quicker when the application or panel is back to being used
                return;
            }

            if (timerRefresh.Interval != _refreshTimerInterval) timerRefresh.Interval = _refreshTimerInterval; // Reset the interval if needed

            if (Patient == null || ConnectorManager.AreConnectorsIdle == false) return; // Don't refresh if there is not patient or any connector is busy

            ConnectorManager.RequestMetadata(); // Request metadata from the connector helper
        }

        /// <summary>
        /// A stack of images.
        /// </summary>
        private class Stack
        {
            /// <summary>
            /// The position of the image. X corresponds to the percentage from the center of the layout. The number needs to be divided by 1000 to create a percentage. Y is -1, 0, 1 to indicate top, bottom or both in the mouth.
            /// </summary>
            public Point Position;

            /// <summary>
            /// True to indicate that this stack should be offset on the Y axis. Used for in-between stacks.
            /// </summary>
            public bool Offset;

            /// <summary>
            /// The index of the image selected in the stack.
            /// </summary>
            public int SelectedIndex;

            /// <summary>
            /// The list of images in the stack.
            /// </summary>
            public List<ConnectorMetadata> Metadata;
        }
    }
}